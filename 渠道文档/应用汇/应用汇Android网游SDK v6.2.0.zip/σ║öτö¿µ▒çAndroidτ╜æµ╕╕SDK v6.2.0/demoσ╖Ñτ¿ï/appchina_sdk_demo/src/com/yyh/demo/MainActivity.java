package com.yyh.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.appchina.model.ErrorMsg;
import com.appchina.usersdk.Account;
import com.yyh.sdk.AccountCallback;
import com.yyh.sdk.CPInfo;
import com.yyh.sdk.InitCallback;
import com.yyh.sdk.LoginCallback;
import com.yyh.sdk.YYHSDKAPI;

public class MainActivity extends Activity implements OnClickListener {

	private Activity mActivity;
	private CPInfo cpInfo;
	private Button loginBtn, accountBtn, payBtn;

	/**
	 * 初始化回调
	 */
	private InitCallback mInitCallback = new InitCallback() {

		@Override
		public void onFinish() {
			// 初始化完成
			initViews();
			
			if (YYHSDKAPI.isLogined(mActivity)) {
				YYHSDKAPI.showToolbar(true);
			}
		}

		@Override
		public void onError(String errorMsg) {
			// 初始化失败
			Toast.makeText(mActivity, errorMsg, Toast.LENGTH_SHORT).show();
		}
	};

	/**
	 * 关于帐号的相关回调
	 */
	private AccountCallback mAccountCallback = new AccountCallback() {

		@Override
		public void onLogout() {
			// 退出登录
			Toast.makeText(mActivity, "退出登录", Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onSwitchAccount(Account preAccount, Account crtAccount) {
			// 切换帐号
			Toast.makeText(mActivity, "帐号切换", Toast.LENGTH_SHORT).show();

		}
	};

	/**
	 * 获取CP信息
	 * 
	 * @return
	 */
	private CPInfo getCPInfo() {
		CPInfo cpinfo = new CPInfo();
		cpinfo.loginId = 1;
		cpinfo.loginKey = "3c480af8";
		cpinfo.appid = "10029900000001100299";
		cpinfo.appkey = "QjQ5Q0VERDZCREI0NUEzMDAxRThFNjIyRDgzODdDMzlBMTdDQjA3M01USTJNVE0xT1RJM01qa3dPVEV4TlRjME16a3JNVFExTmpnM05UQXdPRFU0TURneE5qUTROVFl4T0RNek5Ua3lPVGsyTkRFek9EZzJNVGt6";
		cpinfo.orientation = CPInfo.LANDSCAPE; // 横竖屏设置
		return cpinfo;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 设置全屏
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		mActivity = this;

		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				// 确保是在UI线程中进行初始化
				cpInfo = getCPInfo();
				YYHSDKAPI.initSDKAPI(mActivity, cpInfo, mInitCallback, mAccountCallback);
			}
		});
	}

	private void initViews() {
		setContentView(R.layout.activity_main);
		
		// 设置横竖屏
		setRequestedOrientation(cpInfo.orientation);
		
		loginBtn = (Button) findViewById(R.id.login);
		loginBtn.setOnClickListener(this);
		accountBtn = (Button) findViewById(R.id.account_center);
		accountBtn.setOnClickListener(this);
		payBtn = (Button) findViewById(R.id.pay_center);
		payBtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.login:
			// 登录
			YYHSDKAPI.login(mActivity, new LoginCallback() {
				
				@Override
				public void onLoginError(Activity activity, ErrorMsg error) {
					// 登录失败
				}
				@Override
				public void onLoginCancel() {
					// 取消登录, 当自动登录和快速登录时是不支持取消的
				}

				@Override
				public void onLoginSuccess(Activity activity, Account account) {
					// 登录成功
					// 展示悬浮框
					YYHSDKAPI.showToolbar(true);
				}
			});
			break;
		case R.id.account_center:
			// 进入个人中心
			YYHSDKAPI.openAccountCenter(mActivity);
			break;
		case R.id.pay_center:
			// 进入支付测试页面
			Intent intent = new Intent(mActivity, PayActivity.class);
			intent.putExtra("orientation", cpInfo.orientation);
			startActivity(intent);
			break;
		}
	}
}
