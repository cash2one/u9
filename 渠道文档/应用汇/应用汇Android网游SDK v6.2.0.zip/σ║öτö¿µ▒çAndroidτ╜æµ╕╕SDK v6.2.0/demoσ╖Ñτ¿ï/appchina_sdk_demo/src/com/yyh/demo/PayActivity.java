package com.yyh.demo;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.yyh.sdk.CPInfo;
import com.yyh.sdk.PayCallback;
import com.yyh.sdk.PayParam;
import com.yyh.sdk.YYHSDKAPI;

public class PayActivity extends Activity {

	private Activity mActivity;
	private EditText etQuantity;

	private int getQuantity() {
		String etQuantityStr = etQuantity.getText().toString();
		int quantity = 1;
		try {
			quantity = Integer.parseInt(etQuantityStr);
			return quantity > 0 ? quantity : 1;
		} catch (Exception e) {
			return 1;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 设置全屏
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_pay);
		
		if (getIntent() != null) {
			setRequestedOrientation(getIntent().getIntExtra("orientation", CPInfo.PORTRAIT));
		}

		mActivity = this;
		etQuantity = (EditText) findViewById(R.id.et_quantity);

		findViewById(R.id.pay_anci).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				// 按次收费
				YYHSDKAPI.stratPay(mActivity, new PayParam(1, 100,
						getQuantity(), "", "test00001", ""), new PayCallback() {

					@Override
					public void onPaySuccess(int arg0, String arg1, String arg2) {
					}

					@Override
					public void onPayFaild(int arg0, String arg1) {
					}
				});
			}
		});

		findViewById(R.id.pay_baocishu).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// 包次数收费
						YYHSDKAPI.stratPay(mActivity, new PayParam(4, 10,
								getQuantity(), "", "test00001", ""),
								new PayCallback() {

									@Override
									public void onPaySuccess(int arg0,
											String arg1, String arg2) {
									}

									@Override
									public void onPayFaild(int arg0, String arg1) {
									}
								});
					}
				});

		findViewById(R.id.pay_baozhangqi).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// 包账期收费
						YYHSDKAPI.stratPay(mActivity, new PayParam(5, 10,
								getQuantity(), "", "test00001", ""),
								new PayCallback() {

									@Override
									public void onPaySuccess(int arg0,
											String arg1, String arg2) {
									}

									@Override
									public void onPayFaild(int arg0, String arg1) {
									}
								});
					}
				});

		final EditText etPrice = (EditText) findViewById(R.id.et_price);
		final Button pkaifangjiage = (Button) findViewById(R.id.pay_kaifangjiage);
		pkaifangjiage.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String price = etPrice.getText().toString().trim();
				if (TextUtils.isEmpty(price)) {
					Toast.makeText(mActivity, "请输入收费金额", Toast.LENGTH_SHORT)
							.show();
					etPrice.requestFocus();
				} else if (Integer.parseInt(price) < 1) {
					Toast.makeText(mActivity, "收费金额应大于0", Toast.LENGTH_SHORT)
							.show();
					etPrice.requestFocus();

				} else {
					// 开放价格
					YYHSDKAPI.stratPay(mActivity,
							new PayParam(7, Integer.parseInt(price),
									getQuantity(), "", "test00006", ""),
							new PayCallback() {

								@Override
								public void onPaySuccess(int arg0, String arg1,
										String arg2) {
								}

								@Override
								public void onPayFaild(int arg0, String arg1) {
								}
							});
				}

			}
		});

	}
}
