﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IApppay.Class
{
    public class TransData
    {
        public string exorderno { get; set; }
        public string transid { get; set; }
        public string appid { get; set; }
        public int waresid { get; set; }
        public int feetype { get; set; }
        public int money { get; set; }
        public int count { get; set; }
        public int result { get; set; }
        public int transtype { get; set; }
        public string transtime { get; set; }
        public string cpprivate { get; set; }
    }
}