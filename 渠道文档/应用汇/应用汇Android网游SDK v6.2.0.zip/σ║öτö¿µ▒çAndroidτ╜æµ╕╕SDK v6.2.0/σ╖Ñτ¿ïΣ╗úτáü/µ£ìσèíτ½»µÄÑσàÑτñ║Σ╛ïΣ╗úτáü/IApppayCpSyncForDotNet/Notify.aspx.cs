﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;
using System.IO;

using System.Web.Script.Serialization;


using IApppay.Class;

/// <summary>
/// 功能：安全支付服务器异步通知页面
/// 版本：1.0
/// 日期：2011-09-15
/// 说明：
/// 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
/// 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
/// 
/// ///////////////////页面功能说明///////////////////
/// 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
/// 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
/// TRADE_FINISHED(表示交易已经成功结束);
/// </summary>

namespace IApppayCpSync
{
    public partial class Notify : System.Web.UI.Page
    {

        //String json_date = "{\"exorderno\":\"10004200000001100042\",\"transid\":\"02113013118562300203\",\"waresid\":1,\"appid\":\"20004600000001200046\",\"feetype\":0,\"money\":3000,\"count\":1,\"result\":0,\"transtype\":0,\"transtime\":\"2013-01-31 18:57:27\",\"cpprivate\":\"123456\"}";
        //String json_sing = "28adee792782d2f723e17ee1ef877e7 166bc3119507f43b06977786376c0434 633cabdb9ee80044bc8108d2e9b3c86e";
        String key = "MjhERTEwQkFBRDJBRTRERDhDM0FBNkZBMzNFQ0RFMTFCQTBCQzE3QU1UUTRPRFV6TkRjeU16UTVNRFUyTnpnek9ETXJNVE15T1RRME9EZzROVGsyTVRreU1ETXdNRE0zTnpjd01EazNNekV5T1RJek1qUXlNemN4";

        public static bool validSign(String transdata, String sign, String key)
        {
            try
            {

                MD5 md5 = new MD5CryptoServiceProvider();
                byte[] output = md5.ComputeHash(Encoding.UTF8.GetBytes(transdata));
                String md5str = BitConverter.ToString(output).Replace("-", "");

                String decodeBaseStr = Base64.DecodeBase64(key);

                String[] decodeBaseVec = decodeBaseStr.Replace('+', '#').Split('#');

                String privateKey = decodeBaseVec[0];
                String modkey = decodeBaseVec[1];

                String reqMd5 = RSAUtil.decrypt(sign, new BigInteger(privateKey),
                        new BigInteger(modkey));

                if ((md5str.ToLower()).Equals(reqMd5.ToLower()))
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception e)
            {

            }

            return false;

        }

 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string jsonStr = "", line;
                string transdata, sign;
                try
                {

                    Stream streamResponse = Request.InputStream;
                    StreamReader streamRead = new StreamReader(streamResponse, Encoding.Default);

                    while ((line = streamRead.ReadLine()) != null)
                    {
                        jsonStr += line;
                    }
                    streamResponse.Close();
                    streamRead.Close();

                    string[] content = jsonStr.Split('&');
                    if(content.Length != 2)
                    {
                        Response.Write("FAILD");
                        return;
                    }


                    transdata = content[0].Replace("transdata=", "");
                    sign = content[1].Replace("sign=","");

                }
                catch (Exception ex)
                {
                    Response.Write("FAILD");
                    return;
                }


                if (!validSign(transdata, sign, key))
                {
                    Response.Write("FAILD");
                }
                else
                {

                   JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                   TransData transdata_obj = jsonSerializer.Deserialize<TransData>(transdata);

                   Response.Write("SUCCESS");
                   Response.Write(transdata);
                }
            }
        }
    }
}