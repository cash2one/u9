﻿demo-src是示例源码。

libs是虫虫支付SDK。

other包含UI设计及对接测试规范。

ccpaytest.apk示例可执行文件。

sdk_info是标识SDK版本。