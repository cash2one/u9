﻿ccPay_demo是示例源码。

ccPayLibrary是虫虫支付SDK。

ccplay_Other包含UI设计及对接测试规范。

CCPAY_DEMO.apk示例可执行文件。

http://developer.ccplay.cc/help/ccpay