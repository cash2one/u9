
package com.example.niuSDKDemo;

import java.util.UUID;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.niuwan.gamecenter.sdk.entry.NiuOrderInfo;
import com.niuwan.gamecenter.sdk.entry.NiuSDKConstant;
import com.niuwan.gamesdk.NiuSDKManager;
import com.niuwan.gamesdk.sdkinterface.ILoginCallbackListener;
import com.niuwan.gamesdk.sdkinterface.IPayCallbackListener;

public class MainActivity extends Activity
{

    private Button mLoginBtn;
    private Button mPayBtn;

    private TextView mLoginResult;
    private TextView mOrderResult;

    private final static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLoginBtn = (Button) findViewById(R.id.login_btn);
        mLoginBtn.setOnClickListener(loginBtnListener);

        mPayBtn = (Button) findViewById(R.id.pay_btn);
        mPayBtn.setOnClickListener(payBtnListener);

        mLoginResult = (TextView) findViewById(R.id.login_info);
        mOrderResult = (TextView) findViewById(R.id.order_info);

        // 初始化SDK，SDK只需要初始化一次
        NiuSDKManager sdk = NiuSDKManager.init(MainActivity.this);
        // 设置应用信息 appId appKey
        sdk.initialAppInfo(100001, "cda9f1e133df1a0306059c82d6fa8f62");
    }

    private final OnClickListener loginBtnListener = new OnClickListener()
    {

        @Override
        public void onClick(View v)
        {
            // 登录
            NiuSDKManager sdk = NiuSDKManager.getInstance();
            sdk.niuLogin(MainActivity.this, new SDKLoginCallBack());
        }
    };

    private final OnClickListener payBtnListener = new OnClickListener()
    {

        @Override
        public void onClick(View v)
        {
            // 新建一个平台的支付订单
            NiuOrderInfo orderInfo = new NiuOrderInfo();
            // 设置购买物品名称,如"宝石"
            orderInfo.setItemName("宝石");
            // 设置购买物品在平台服务器登记的物品IDCode，如无，可以填空
            orderInfo.setItemCode("");
            // 设置购买物品的数量
            orderInfo.setItemCount(10);
            // 设置购买物品的价值，以Zen币为单位，1RMB=10Zen币
            orderInfo.setValue(15);
            
            EditText numberText = (EditText)findViewById(R.id.editText1);
            String valus = numberText.getText().toString();
            if (valus != null && valus.length() > 0) {
                orderInfo.setValue(Integer.valueOf(valus));
            }
            
            // 设置cp端的订单号，用于游戏与cp业务服务器对账
            orderInfo.setCpOrderId(UUID.randomUUID().toString());
            // 设置附加信息，供游戏使用的透传参数，平台服务器透传给cp业务服务器，并在订单完成后由SDK返回
            // 如果使用demo中的测试appId=100001&appKey=8f51f2a26083ad5d0a3c1bb8fa8fcbd9进行消费测试请更改此参数值，
            //更换参数值的格式如“callbackurl=你方提供的消费测试回调地址”，即用你方提供的消费回调地址替换http://niuwan.vicp.cc:8061,
            // 如未修改此参数值，测试消费过程中不进行回调
            orderInfo.setExInfo("callbackurl=http://niuwan.vicp.cc:8061");

            // 设置回调后，调用SDK
            NiuSDKManager sdk = NiuSDKManager.getInstance();
            sdk.niuPay(MainActivity.this, orderInfo, new SDKPayCallBack());
        }
    };

    private class SDKLoginCallBack implements ILoginCallbackListener
    {

        @Override
        // 登录失败
        public void onNiuLoginFail(int errorCode)
        {
            switch (errorCode)
            {
                case NiuSDKConstant.SDK_PSF_NOT_INSTALL:
                    // CSGameCenter.apk没有安装
                    break;
                case NiuSDKConstant.SDK_NOT_INITIALED:
                    // 在调用SDK前没有初始化，既没有调用init
                    break;
                case NiuSDKConstant.SDK_APPINFO_NOT_INITIALED:
                    // 之前没有调用initialAppInfo
                    break;
                case NiuSDKConstant.SDK_USER_CANCEL:
                    Log.e("APP Sample", "SDK_USER_CANCEL" + errorCode);
                    break;

                default:
                    break;
            }
            Log.e("APP Sample", "onNiuLoginFail errorCode:" + errorCode);
            // 出错处理
            sendMsg("onNiuLoginFail errorCode:" + errorCode, MSG_LOGIN_INFO);
        }

        @Override
        // 登录成功
        public void onNiuLoginSuccess()
        {
            // 获取玩家登录后的的roleId，用于唯一标识用户
            String roleId = NiuSDKManager.getInstance().getLoginRoleId();
            // 获取玩家登录的token用于游戏后台与闪现后台验证登录有效性。
            String roleToken = NiuSDKManager.getInstance().getLoginRoleToken();
            // 返回处理
            Log.e("APP Sample", "onNiuLoginSuccess roleId:" + roleId
                    + ",roleToken:" + roleToken);
            sendMsg("onNiuLoginSuccess roleId:" + roleId + ",roleToken:"
                    + roleToken, MSG_LOGIN_INFO);
        }

    }

    private class SDKPayCallBack implements IPayCallbackListener
    {
        @Override
        // 购买成功
        public void onNiuPaySuccess(NiuOrderInfo orderInfo)
        {
            Log.e(TAG, "调用支付成功");
            // 获得cpOrderId,与调用时设置的相同，用于游戏发到cp业务服务器进行对账
            String cpOrderId = orderInfo.getCpOrderId();

            // 获得购买物品的名称，与调用时设置的相同
            String itemName = orderInfo.getItemName();

            // 获得购买物品的价值，与调用时设置的相同，以Zen币为单位，1RMB=10Zen币
            int itemValue = orderInfo.getValue();

            // 获得购买物品的数量，与调用时设置的相同
            int itemCount = orderInfo.getItemCount();

            // 获得购买物品的IDCode，与调用时设置的相同
            String itemCode = orderInfo.getItemCode();

            // 获得购买物品的附加信息，与调用时设置的相同
            String exInfo = orderInfo.getExInfo();

            // 获得平台服务器生成的OrderId，与cpOrderId一起，用于游戏发到cp业务服务器进行对账
            String niuOrderId = orderInfo.getNiuOrderId();

            // 消费成功后获取对应信息处理、对账
            Log.e("APP Sample", "onNiuPaySuccess orderInfo:" + orderInfo);
            sendMsg("onNiuPaySuccess orderInfo:" + orderInfo, MSG_ORDER_INFO);
        }

        @Override
        // 购买失败
        public void onNiuPayFail(int errorCode)
        {
            switch (errorCode)
            {
                case NiuSDKConstant.SDK_PSF_NOT_INSTALL:
                    // padaServiceFramework没有安装
                    break;
                case NiuSDKConstant.SDK_NOT_INITIALED:
                    // 在调用SDK前没有初始化，既没有调用init
                    break;
                case NiuSDKConstant.SDK_APPINFO_NOT_INITIALED:
                    // 之前没有调用initialAppInfo
                    break;
                case NiuSDKConstant.SDK_ORDER_NOT_INITIALED:
                    // 没有设置NiuOrderInfo
                    break;
                case NiuSDKConstant.SDK_USER_CANCEL:
                    // 用户取消
                    break;
                case NiuSDKConstant.SDK_ROLE_TOKEN_FAIL:
                    // 角色token失效,当前情况下，游戏可以正常进行，但如需消费需重新角色登录。
                    break;
                default:
                    // 支付失败
                    break;
            }
            Log.e("APP Sample", "onNiuPayFail errorCode:" + errorCode);
            sendMsg("onNiuPayFail errorCode:" + errorCode, MSG_ORDER_INFO);
        }
    }

    private void sendMsg(String msgStr, int what)
    {
        Message msg = mHandler.obtainMessage(what);
        Bundle bundle = new Bundle();
        bundle.putString("msg", msgStr);
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    private final int MSG_LOGIN_INFO = 1001;
    private final int MSG_ORDER_INFO = 1002;

    private final Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            int what = msg.what;
            switch (what)
            {
                case MSG_LOGIN_INFO:
                    mLoginResult.setText(msg.getData().getString("msg"));
                    break;
                case MSG_ORDER_INFO:
                    mOrderResult.setText(msg.getData().getString("msg"));
                    break;
            }
        }
    };

}
