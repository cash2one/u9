package com.demo.util;

import org.apache.commons.lang3.StringEscapeUtils;

public class App {

	public static void main(String[] args) {
		String input = "<script>alert('xss')</script>";
		System.out.println(StringEscapeUtils.escapeHtml4(input));
	}

}
