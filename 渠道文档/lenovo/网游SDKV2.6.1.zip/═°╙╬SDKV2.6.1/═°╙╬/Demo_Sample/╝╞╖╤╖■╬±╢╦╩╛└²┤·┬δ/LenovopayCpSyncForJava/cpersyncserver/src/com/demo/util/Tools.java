package com.demo.util;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

public class Tools {
	/**	https://<UserService对第三方服务server >:<port>/interserver/authen/1.2/getaccountid	*/
	private static final String authUrl = "https://passport.lenovo.com/interserver/authen/1.2/getaccountid?";
	/** 密钥	*/
	public static final String KEY = "";
	
	public static HttpResponseResult auth(String lpsust,String appId){
		HttpResponseResult responseResult = HttpUtil.sendGetHttps(authUrl+"lpsust="+lpsust+"&realm="+appId);
		System.out.println("httpCode:"+responseResult.getHttpCode());
		System.out.println("message:"+responseResult.getMessage());
		return responseResult;
	}
	
	/**
	 * 生成订单号
	 * @return
	 */
	public static String generateOrderNo() {
		StringBuffer orderBufferStr = new StringBuffer();
		//15位年月日时分秒毫秒
		orderBufferStr.append(getCurrentDate("yyMMddHHmmssSSS"));
		return orderBufferStr.toString();
	}
	
	/**
	 * 获得指定格式的日期字符串
	 * 
	 * @return
	 */
	public static String getCurrentDate(String format) {
		String dateString = "";
		try {
			java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat(format);
			java.util.Date currentTime_1 = new java.util.Date();
			dateString = formatter.format(currentTime_1);
		} catch (Exception e) {
		}
		return dateString;
	}
	
	public static String toJson(Object object) {
		ObjectMapper mapper = getMapper();
		try {
			return mapper.writeValueAsString(object);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static ObjectMapper getMapper() {
		return new ObjectMapper();
	}
	
	public static Map<String,Object> getIdMap(String orderId) {
		Map<String, Object> ret = new HashMap<String, Object>();
		ret.put("orderId", orderId);
		return ret;
	}
	
	public static Map<String,Object> getErrorMap(Integer type) {
		Map<String, Object> ret = new HashMap<String, Object>();
		ret.put("error", type);
		return ret;
	}
	/**
	 *  将JSON字符串转换为对象
	 * @param json
	 * @param clazz
	 * @return
	 */
	public static <T> T toObject(String json, Class<T> clazz) {
		ObjectMapper mapper = getMapper();
		try {
			return mapper.readValue(json, clazz);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @param resp
	 * @param content
	 */
	public static void sendJson( HttpServletResponse resp,String content,int status) {
		resp.setContentType("application/json;charset=UTF-8;");
		resp.setHeader("Cache-Control", "no-cache");
		resp.setStatus(status);
		PrintWriter pw = null;
		try {
			pw = resp.getWriter();
			pw.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pw != null) {
				pw.flush();
				pw.close();
			}
		}
	}
	
	/**
	 * 
	 * @param resp
	 * @param content
	 */
	public static void sendString( HttpServletResponse resp,String content,int status) {
		resp.setContentType("text/html;charset=UTF-8;");
		resp.setHeader("Cache-Control", "no-cache");
		resp.setStatus(status);
		PrintWriter pw = null;
		try {
			pw = resp.getWriter();
			pw.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pw != null) {
				pw.flush();
				pw.close();
			}
		}
	}
	
	public static void main(String[] args) {
//		String lpsust = "ZAgAAAAAAAaaGE9MTAwMDE1OTUwNzYmYj0yJmM9NCZkPTEyMjAzJmU9RjdDMEE4MDg4QTcyQzlDRjg0OUFDNkI3ODZCMDExNEMxJmg9MTQxNTU4OTcwMTAxNSZpPTQzMjAwJmo9MCZvPUExMDAwMDM4QzY4Q0VDJnA9aW1laSZxPTAmdXNlcm5hbWU9MTg5MTE3NzkwNTgmbHQ9MSZpbD1jbuwPkagiX-jrUA2SzKCytHo";
//		String appId = "cashier.lenovomm.com";
//		HttpResponseResult responseResult = auth(lpsust, appId);
	}
}
