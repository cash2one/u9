package com.demo.util;

public class HttpResponseResult {
	private int httpCode;
	private String message;

	public int getHttpCode() {
		return this.httpCode;
	}

	public void setHttpCode(int httpCode) {
		this.httpCode = httpCode;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
