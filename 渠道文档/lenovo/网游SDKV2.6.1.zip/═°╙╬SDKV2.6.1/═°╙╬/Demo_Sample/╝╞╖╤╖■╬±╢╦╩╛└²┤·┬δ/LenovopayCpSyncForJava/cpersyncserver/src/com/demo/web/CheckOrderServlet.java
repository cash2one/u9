package com.demo.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.util.Tools;

/**
 * 轮询查询订单是否支付成功
 */
public class CheckOrderServlet extends HttpServlet {
       
	private static final long serialVersionUID = -3464584946521319128L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOrderServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//TODO 可注释掉
		convertRespToMap(request);
		//获取参数
		String exorderno = request.getParameter("exorderno");
		String waresid = request.getParameter("waresid");
		String money = request.getParameter("money");
		/*
		 * 这里的逻辑是收到回调接口createOrderServlet后。更新订单状态，
		 * 根据上传的exorderno，查找订单，判断订单状态，
		 * 需要cp自己实现
		 */
		int status = HttpServletResponse.SC_OK;
		Tools.sendString(response, "", status);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
	
	/**
	 * 把参数封装到map里
	 * 
	 * @return
	 */
	public Map<String, String> convertRespToMap(HttpServletRequest request) {
		Map<String, String> params = new HashMap<String, String>();
		Map<String, String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter
				.hasNext();) {
			String name = (String) iter.next();
			String[] values = requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			params.put(name, valueStr);
			System.out.println("["+this.getClass().getSimpleName()+"] key:"+name+" value:"+valueStr);
		}
		return params;
	}

}
