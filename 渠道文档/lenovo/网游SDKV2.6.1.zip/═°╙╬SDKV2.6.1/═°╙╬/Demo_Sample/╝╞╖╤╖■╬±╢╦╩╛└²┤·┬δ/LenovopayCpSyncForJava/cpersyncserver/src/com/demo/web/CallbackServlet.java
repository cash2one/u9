package com.demo.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.demo.util.Tools;
import com.lenovo.pay.sign.CpTransSyncSignValid;

/**
 * 回调接口
 */
public class CallbackServlet extends HttpServlet {
       
	private static final long serialVersionUID = 6835837359437375900L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public CallbackServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//TODO 可注释掉
		convertRespToMap(request);
		String transdata = request.getParameter("transdata");
		String sign = request.getParameter("sign");
		String ret = "FAILTURE";
		int status = HttpServletResponse.SC_OK;
		if (StringUtils.isBlank(transdata) || StringUtils.isBlank(sign)) {
			Tools.sendString(response, ret, status);
			return ;
		}
		
		Boolean isOk = CpTransSyncSignValid.validSign(transdata, sign, Tools.KEY);
		//TODO isOk 
		if (true) {
			/*
			 * 如果签名通过，代表是从支付平台发来的消息。再根据参数更新订单
			 */
//			JSONArray transdataJson = JSONArray.fromObject(transdata);
//			JSONObject transdataObj = (JSONObject)transdataJson.get(0);
//			//获取参数
//			String orderId = (String) transdataObj.get("exorderno");
//			int waresid = (Integer) transdataObj.get("waresid");
//			int money = (Integer) transdataObj.get("money");
//			String transid=(String) transdataObj.get("transid");
//			String appid=(String) transdataObj.get("appid");
//			int feetype=(Integer) transdataObj.get("feetype");
//			int count=(Integer) transdataObj.get("count");
//			int result=(Integer) transdataObj.get("result");
//			int transtype=(Integer) transdataObj.get("transtype");
//			String transtime=(String) transdataObj.get("transtime");
//			String cpprivate=(String) transdataObj.get("cpprivate");
//			int paytype=(Integer) transdataObj.get("paytype");
			// TODO 更新cp订单，需要自己实现更新逻辑等
			
			ret = "SUCCESS";
			Tools.sendString(response, ret, status);
		} else {
			Tools.sendString(response, ret, status);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
	
	/**
	 * 把参数封装到map里
	 * 
	 * @return
	 */
	public Map<String, String> convertRespToMap(HttpServletRequest request) {
		Map<String, String> params = new HashMap<String, String>();
		Map<String, String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter
				.hasNext();) {
			String name = (String) iter.next();
			String[] values = requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			params.put(name, valueStr);
			System.out.println("["+this.getClass().getSimpleName()+"] key:"+name+" value:"+valueStr);
		}
		return params;
	}

}
