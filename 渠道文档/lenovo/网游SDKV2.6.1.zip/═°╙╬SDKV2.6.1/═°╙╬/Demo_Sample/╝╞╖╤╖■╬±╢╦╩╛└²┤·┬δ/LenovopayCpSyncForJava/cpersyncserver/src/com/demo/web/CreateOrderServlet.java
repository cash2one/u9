package com.demo.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.demo.util.HttpResponseResult;
import com.demo.util.Tools;

/**
 * 生成订单接口
 */
public class CreateOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 9049037706248587738L;
	private static final int RETCODE = 200;
	
	/**
     * @see HttpServlet#HttpServlet()
     */
    public CreateOrderServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//TODO 可注释掉
		convertRespToMap(request);
		//获取参数
		String appid = request.getParameter("appid");
		String lpsust = request.getParameter("lpsust");
		String waresid = request.getParameter("waresid");
		String money = request.getParameter("money");
		//TODO	支付系统的计费点，需要自己去同步，下面的是waresid_cp样例
		String waresid_cp = waresid;//"101";
		HttpResponseResult httpResponseResult = Tools.auth(lpsust, appid);
		Map<String, Object> retMap = null;
		int status = HttpServletResponse.SC_OK;

		/*
		 * type = 1 认证失败（lpsust无效）、 type = 2 无效的支付点 、type = 3 必填参数为空，或者格式错误
		 * 以下代码仅供参考，具体逻辑需要自己实现
		 */
		if (StringUtils.isBlank(appid) || StringUtils.isBlank(lpsust) || StringUtils.isBlank(waresid) || StringUtils.isBlank(money) ) {
			retMap = Tools.getErrorMap(3);
			status = HttpServletResponse.SC_BAD_REQUEST;
		} else if (httpResponseResult.getHttpCode() != RETCODE) {
			retMap = Tools.getErrorMap(1);
			status = HttpServletResponse.SC_BAD_REQUEST;
		} else if (!waresid.equals(waresid_cp)) {
			retMap = Tools.getErrorMap(2);
			status = HttpServletResponse.SC_BAD_REQUEST;
		} else {
			String orderId = Tools.generateOrderNo();
			retMap = Tools.getIdMap(orderId);
		}

		String json = Tools.toJson(retMap);
		Tools.sendJson(response, json, status);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

	/**
	 * 把参数封装到map里
	 * 
	 * @return
	 */
	public Map<String, String> convertRespToMap(HttpServletRequest request) {
		Map<String, String> params = new HashMap<String, String>();
		Map<String, String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter
				.hasNext();) {
			String name = (String) iter.next();
			String[] values = requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			params.put(name, valueStr);
			System.out.println("["+this.getClass().getSimpleName()+"] key:"+name+" value:"+valueStr);
		}
		return params;
	}

}
