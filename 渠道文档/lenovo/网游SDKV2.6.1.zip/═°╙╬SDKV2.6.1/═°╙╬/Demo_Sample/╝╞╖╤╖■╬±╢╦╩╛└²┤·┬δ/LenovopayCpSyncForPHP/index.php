<?php
	$action = $_GET['action'];
	require_once("$action.php");
?>