/** Automatically generated file. DO NOT MODIFY */
package com.lenovo.lsf.account.res;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}