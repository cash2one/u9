/** Automatically generated file. DO NOT MODIFY */
package com.pay.sample.lenovo;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}