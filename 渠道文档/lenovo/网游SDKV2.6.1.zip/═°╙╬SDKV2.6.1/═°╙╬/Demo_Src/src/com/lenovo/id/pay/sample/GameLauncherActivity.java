package com.lenovo.id.pay.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;



import com.lenovo.id.pay.sample.data.Config;
import com.lenovo.lsf.gamesdk.IAuthResult;
import com.lenovo.lsf.gamesdk.LenovoGameApi;
import com.lenovo.lsf.gamesdk.IQuitCallback;
import com.pay.sample.lenovo.R;

public class GameLauncherActivity extends Activity {
	private static final int MSG_LOGIN_AUTO_ONEKEY = 2;
	private AlertDialog.Builder alertDialogBuilder;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		initViews();
	}

	/**
	 * UI初始化
	 */
	private void initViews() {

		/**
		 * 加载游戏资源:在此处建议您将加载游戏资源的代码模块放到这里，这样做的好处是因为下面getTokenByQuickLogin()这个方法是个异步方法，可以做到
		 * 边加载资源一边进行后台快速登录
		 */
		setContentView(R.layout.load_resource);

		//SDK初始化
		LenovoGameApi.doInit(GameLauncherActivity.this,Config.appid);
		
		// 调用快速登录接口
		/**
	       * 什么是快速登录：
	       * 如果用户已经在系统中登录，则本接口会通过SSO机制直接返回登录结果;
	       * 如果用户尚未在系统中登录，则本接口会通过后台短信方式进行自动登录尝试，通常需要10~20s左右时间;
		   * 由于自动登录需要发短信，因此请使用装有SIM卡的手机进行开发测试;
	       * 登录期间，会弹出一个提示框，提示用户正在尝试自动登录;
	       * 如果自动登录失败，会提示用户重试，以及引导用户使用其他方式登录。
	       */
		getTokenByQuickLogin();

		// 退出游戏
		alertDialogBuilder = new AlertDialog.Builder(this)
				.setMessage("是否确定退出？").setCancelable(true)
				.setPositiveButton("是", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						GameLauncherActivity.this.finish();
					}
				})
				.setNegativeButton("否", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
	}

	private void showView(final String lpsust) {

		// 进入商城按钮
		final Button buyBtn = (Button) findViewById(R.id.pay_into);
		buyBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// 发起进入商城
				Intent intent = new Intent(GameLauncherActivity.this,GoodsListActivity.class);
				intent.putExtra("lpsust", lpsust);
				startActivity(intent);
				finish();
			}
		});

	}

	/**
	 * 后台快捷登录
	 */
	private void getTokenByQuickLogin() {

		//请不要在回调函数里进行UI操作，如需进行UI操作请使用handler将UI操作抛到主线程
		LenovoGameApi.doAutoLogin(this, new IAuthResult() {

			@Override
			public void onFinished(boolean ret, String data) {
				final Message msg = new Message();
				msg.what = MSG_LOGIN_AUTO_ONEKEY;
				msg.obj = data;
				if (ret) {
					myHandler.sendMessage(msg);

				} else {
					//后台快速登录失败(失败原因开启飞行模式、 网络不通等)
					Log.i(Config.TAG, "login fail");
				}
			}
		});

	}

	/**
	 * 功能： 该方法的作用是Handler对传递过来的不同消息，进行不同的处理。 当传递过来的消息是MSG_LOGIN时，则对登录进行相应的处理；
	 */
	private Handler myHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MSG_LOGIN_AUTO_ONEKEY:
				// 登录成功
				setContentView(R.layout.game_main);
				showView((String)msg.obj);
				break;
			default:
				break;
			}
		};
	};

	/**
	 * 返回键
	 */
	@Override
	public void onBackPressed() {
		//alertDialogBuilder.show();
		LenovoGameApi.doQuit(GameLauncherActivity.this,  new IQuitCallback() {

			@Override
			public void onFinished(String data) {
				GameLauncherActivity.this.finish();
				 System.exit(0);
			}

		});
	}
}
