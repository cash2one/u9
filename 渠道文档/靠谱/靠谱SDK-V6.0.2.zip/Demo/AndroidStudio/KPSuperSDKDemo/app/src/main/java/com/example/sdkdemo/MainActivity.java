package com.example.sdkdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cyjh.pay.constants.PayConstants;
import com.cyjh.pay.model.ScreenType;
import com.cyjh.pay.util.LogUtil;
import com.kaopu.supersdk.api.KPSuperSDK;
import com.kaopu.supersdk.callback.KPAuthCallBack;
import com.kaopu.supersdk.callback.KPGetCheckUrlCallBack;
import com.kaopu.supersdk.callback.KPLoginCallBack;
import com.kaopu.supersdk.callback.KPLogoutCallBack;
import com.kaopu.supersdk.callback.KPPayCallBack;
import com.kaopu.supersdk.model.UserInfo;
import com.kaopu.supersdk.model.params.PayParams;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;


public class MainActivity extends Activity {

    private Button pay_bt;
    private Button login_bt;
    private Button auth_bt;
    private Button collect_bt;
    private Button logOut_bt;

    private TextView textView1;

    private boolean fullScreen = false;
    private int screentype = 2;
    private String channelKey = "kaopu";
    private boolean isCanClickLogin = true;

    private KPLoginCallBack kpLoginCallBack = new KPLoginCallBack() {
        @Override
        public void onLoginSuccess(UserInfo info) {
            login_bt.setEnabled(false);
            KPSuperSDK.getCheckUrl();
        }

        @Override
        public void onLoginFailed() {
            isCanClickLogin = true;
            Toast.makeText(MainActivity.this, "登录失败！", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onLoginCanceled() {
            isCanClickLogin = true;
            Toast.makeText(MainActivity.this, "登录取消！", Toast.LENGTH_LONG).show();
        }
    };

    private KPLogoutCallBack kpLogoutCallBack = new KPLogoutCallBack() {
        @Override
        public void onSwitch() {
            // 在这里实现切换账号的逻辑
            login_bt.setEnabled(true);
        }

        @Override
        public void onLogout() {
            // 在这里实现注销账号的逻辑
            isCanClickLogin = true;
            login_bt.setEnabled(true);
            login_bt.performClick();
        }
    };

    private KPGetCheckUrlCallBack kpGetCheckUrlCallBack = new KPGetCheckUrlCallBack() {
        @Override
        public void onGetCheckUrlSuccess(String url) {
            System.out.println("登录验证URL为：" + url);
        }

        @Override
        public void onGetCheckUrlFailed() {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        JSONObject jsonObject = null;

        try {
            InputStream is = getAssets().open("kaopu_game_config.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String jsonStr =new String(buffer, "UTF-8");
            jsonObject = new JSONObject(jsonStr);
            fullScreen = jsonObject.getBoolean("fullScreen");
            screentype = jsonObject.getInt("screenType");
            channelKey = jsonObject.getString("ChannelKey");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 模拟当前游戏是否为全屏展示
        if (fullScreen) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        setContentView(R.layout.activity_main);

        // 模拟当前游戏是横屏还是竖屏
        if (screentype == ScreenType.SCREEN_LAND) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);// 横屏
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);// 竖屏
        }

        textView1 = (TextView) findViewById(R.id.textView_channel);
        auth_bt = (Button) findViewById(R.id.button_auth);
        login_bt = (Button) findViewById(R.id.button_login);
        pay_bt = (Button) findViewById(R.id.button_pay);
        collect_bt = (Button) findViewById(R.id.button_collect);
        logOut_bt = (Button) findViewById(R.id.button_logout);

        showVersion();

        // 判断是否MUI, 启动开启浮窗引导页
        KPSuperSDK.startGuide(this);

        // 设置获取登录验证URL 的回调对象
        KPSuperSDK.setGetCheckUrlCallBack(kpGetCheckUrlCallBack);

        // 授权
        auth_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // 对应用进行授权,若无授权或者是授权失败,将导致无法使用本支付SDK
                // 无特殊需要，第二个参数(configData)直接传 null 即可
                KPSuperSDK.auth(MainActivity.this, null, new KPAuthCallBack() {
                    @Override
                    public void onAuthSuccess() {
                        LogUtil.out("授权成功");

                        auth_bt.setEnabled(false);

                        // 注册注销账号时的回调,在授权成功之后，用户注销账号前调用都可以
                        KPSuperSDK.registerLogoutCallBack(kpLogoutCallBack);
                    }

                    @Override
                    public void onAuthFailed() {
                    }
                });
            }
        });

        // 登录
        login_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(auth_bt.isEnabled()) {
                    Toast.makeText(MainActivity.this, "请先授权", Toast.LENGTH_LONG).show();
                    return;
                }
                if(!isCanClickLogin) {
                    return;
                }
                isCanClickLogin = false;

                KPSuperSDK.login(MainActivity.this, kpLoginCallBack);
            }
        });

        // 支付
        pay_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(!KPSuperSDK.isLogin()) {
                    Toast.makeText(MainActivity.this, "请先登录", Toast.LENGTH_LONG).show();
                    return;
                }

                final EditText editText = new EditText(MainActivity.this);
                editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                editText.setHint("请输入充值金额");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("支付");
                builder.setPositiveButton("确认支付",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                // 创建订单信息
                                if (TextUtils.isEmpty(editText.getText().toString().replace(".", ""))) {
                                    Toast.makeText(MainActivity.this, "请输入正确的充值金额", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                double price = Double.parseDouble(editText.getText().toString());
                                PayParams payParams = new PayParams();
                                payParams.setAmount(price); // 充值金额
                                payParams.setGamename(KPSuperSDK.getGameName()); // 充值游戏
                                payParams.setGameserver(1 + ""); // 充值游戏服务器
                                payParams.setRolename("superSdkDemo测试"); // 充值角色名称
                                payParams.setOrderid(System.currentTimeMillis() + ""); // 唯一订单号

                                // 创建订单配置
                                payParams.setCurrencyname("钻石"); // 虚拟货币名称
                                payParams.setProportion(10); // RMB和虚拟货币的比,例:10表示比例为1RMB:10虚拟货币
                                payParams.setCustomPrice(false);// 这个设置为true， setCustomText才会生效
                                payParams.setCustomText("0.01元兑换500钻石");
                                /**
                                 * 支付接口,需要同时提供支付和登录的回调接口,若用户没用登录,将直接跳转至登录界面 如果不使用回调,传null即可
                                 */
                                KPSuperSDK.pay(MainActivity.this, payParams, new KPPayCallBack() {
                                    @Override
                                    public void onPaySuccess() {
                                        Toast.makeText(MainActivity.this, "支付成功", Toast.LENGTH_SHORT).show();
                                        System.out.println("支付成功");
                                    }

                                    @Override
                                    public void onPayFailed() {
                                        Toast.makeText(MainActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
                                        System.out.println("支付失败");
                                    }

                                    @Override
                                    public void onPayCancle() {
                                        Toast.makeText(MainActivity.this, "退出支付", Toast.LENGTH_SHORT).show();
                                        System.out.println("退出支付");
                                    }
                                });
                            }
                        });

                builder.setView(editText);
                builder.show();
            }
        });

        // 数据采集
        collect_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (KPSuperSDK.isLogin()) {
                    int roleLevel = 22;// 角色等级
                    String serviceName = "神战之地"; // 服务器名称
                    String roleName = "张三"; // 角色名称
                    String id = "10000331";// 游戏方对外用户 ID，即：cp自身用户的userid（不可为空）
                    KPSuperSDK.setUserGameRole(MainActivity.this, serviceName, roleName, id, roleLevel);
                } else {
                    Toast.makeText(MainActivity.this, "请先登录", Toast.LENGTH_LONG).show();
                }
            }
        });

        logOut_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (KPSuperSDK.isLogin()) {
                    KPSuperSDK.logoutAccount();
                } else {
                    Toast.makeText(MainActivity.this, "请先登录", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void showVersion() {
        ApplicationInfo appInfo = null;
        try {
            appInfo = this.getPackageManager().getApplicationInfo(this.getPackageName(), PackageManager.GET_META_DATA);
            String appkey = appInfo.metaData.get("KAOPU_APPKEY").toString(); // 获取APPKEY
            String appsecret = appInfo.metaData.get("KAOPU_SECRETKEY").toString(); // 获取APPSECRET
            String appVersion = appInfo.metaData.get("KAOPU_APPVERSION").toString(); // 获取APPVERSION
            String appId = appInfo.metaData.get("KAOPU_APPID").toString(); // 获取APPID


            textView1.setText("SDK版本:  " + PayConstants.JAR_VERSION + "\nappkey:  " + appkey + "\n应用版本号:  " + appVersion + "\nappId:  " + appId
                    + "\n渠道:  " + channelKey + "\nappsecret:  " + appsecret);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        KPSuperSDK.closeFloatView(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        KPSuperSDK.showFloatView(this);
    }

    @Override
    protected void onDestroy() {
        KPSuperSDK.release();
        super.onDestroy();
    }


}
