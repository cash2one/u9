package com.example.kpsupersdk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cyjh.pay.constants.PayConstants;
import com.cyjh.pay.model.ScreenType;
import com.cyjh.pay.util.LogUtil;
import com.kaopu.supersdk.api.KPSuperSDK;
import com.kaopu.supersdk.callback.KPAuthCallBack;
import com.kaopu.supersdk.callback.KPGetCheckUrlCallBack;
import com.kaopu.supersdk.callback.KPLoginCallBack;
import com.kaopu.supersdk.callback.KPLogoutCallBack;
import com.kaopu.supersdk.callback.KPPayCallBack;
import com.kaopu.supersdk.model.UserInfo;
import com.kaopu.supersdk.model.params.PayParams;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;


public class MainActivity extends Activity {

    private Button pay_bt;
    private Button login_bt;
    private Button auth_bt;
    private Button collect_bt;
    private Button logOut_bt;

    private TextView textView1;

    private boolean fullScreen = false;
    private int screentype = 2;
    private String channelKey = "kaopu";
    private boolean isCanClickLogin = true;

    private KPLoginCallBack kpLoginCallBack = new KPLoginCallBack() {
        @Override
        public void onLoginSuccess(UserInfo info) {
            login_bt.setEnabled(false);
            KPSuperSDK.getCheckUrl();
        }

        @Override
        public void onLoginFailed() {
            isCanClickLogin = true;
            Toast.makeText(MainActivity.this, "��¼ʧ�ܣ�", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onLoginCanceled() {
            isCanClickLogin = true;
            Toast.makeText(MainActivity.this, "��¼ȡ����", Toast.LENGTH_LONG).show();
        }
    };

    private KPLogoutCallBack kpLogoutCallBack = new KPLogoutCallBack() {
        @Override
        public void onSwitch() {
            // ������ʵ���л��˺ŵ��߼�
            login_bt.setEnabled(true);
        }

        @Override
        public void onLogout() {
            // ������ʵ��ע���˺ŵ��߼�
            isCanClickLogin = true;
            login_bt.setEnabled(true);
            login_bt.performClick();
        }
    };

    private KPGetCheckUrlCallBack kpGetCheckUrlCallBack = new KPGetCheckUrlCallBack() {
        @Override
        public void onGetCheckUrlSuccess(String url) {
            System.out.println("��¼��֤URLΪ��" + url);
        }

        @Override
        public void onGetCheckUrlFailed() {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        JSONObject jsonObject = null;

        try {
            InputStream is = getAssets().open("kaopu_game_config.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String jsonStr =new String(buffer, "UTF-8");
            jsonObject = new JSONObject(jsonStr);
            fullScreen = jsonObject.getBoolean("fullScreen");
            screentype = jsonObject.getInt("screenType");
            channelKey = jsonObject.getString("ChannelKey");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ģ�⵱ǰ��Ϸ�Ƿ�Ϊȫ��չʾ
        if (fullScreen) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        setContentView(R.layout.activity_main);

        // ģ�⵱ǰ��Ϸ�Ǻ�����������
        if (screentype == ScreenType.SCREEN_LAND) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);// ����
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);// ����
        }

        textView1 = (TextView) findViewById(R.id.textView_channel);
        auth_bt = (Button) findViewById(R.id.button_auth);
        login_bt = (Button) findViewById(R.id.button_login);
        pay_bt = (Button) findViewById(R.id.button_pay);
        collect_bt = (Button) findViewById(R.id.button_collect);
        logOut_bt = (Button) findViewById(R.id.button_logout);

        showVersion();

        // �ж��Ƿ�MUI, ����������������ҳ
        KPSuperSDK.startGuide(this);

        // ���û�ȡ��¼��֤URL �Ļص�����
        KPSuperSDK.setGetCheckUrlCallBack(kpGetCheckUrlCallBack);

        // ��Ȩ
        auth_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // ��Ӧ�ý�����Ȩ,������Ȩ��������Ȩʧ��,�������޷�ʹ�ñ�֧��SDK
                // ��������Ҫ���ڶ�������(configData)ֱ�Ӵ� null ����
                KPSuperSDK.auth(MainActivity.this, null, new KPAuthCallBack() {
                    @Override
                    public void onAuthSuccess() {
                        LogUtil.out("��Ȩ�ɹ�");

                        auth_bt.setEnabled(false);

                        // ע��ע���˺�ʱ�Ļص�,����Ȩ�ɹ�֮���û�ע���˺�ǰ���ö�����
                        KPSuperSDK.registerLogoutCallBack(kpLogoutCallBack);
                    }

                    @Override
                    public void onAuthFailed() {
                    }
                });
            }
        });

        // ��¼
        login_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(auth_bt.isEnabled()) {
                    Toast.makeText(MainActivity.this, "������Ȩ", Toast.LENGTH_LONG).show();
                    return;
                }
                if(!isCanClickLogin) {
                    return;
                }
                isCanClickLogin = false;

                KPSuperSDK.login(MainActivity.this, kpLoginCallBack);
            }
        });

        // ֧��
        pay_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(!KPSuperSDK.isLogin()) {
                    Toast.makeText(MainActivity.this, "���ȵ�¼", Toast.LENGTH_LONG).show();
                    return;
                }

                final EditText editText = new EditText(MainActivity.this);
                editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                editText.setHint("�������ֵ���");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("֧��");
                builder.setPositiveButton("ȷ��֧��",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                // ����������Ϣ
                                if (TextUtils.isEmpty(editText.getText().toString().replace(".", ""))) {
                                    Toast.makeText(MainActivity.this, "��������ȷ�ĳ�ֵ���", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                double price = Double.parseDouble(editText.getText().toString());
                                PayParams payParams = new PayParams();
                                payParams.setAmount(price); // ��ֵ���
                                payParams.setGamename(KPSuperSDK.getGameName()); // ��ֵ��Ϸ
                                payParams.setGameserver(1 + ""); // ��ֵ��Ϸ������
                                payParams.setRolename("superSdkDemo����"); // ��ֵ��ɫ����
                                payParams.setOrderid(System.currentTimeMillis() + ""); // Ψһ������

                                // ������������
                                payParams.setCurrencyname("��ʯ"); // �����������
                                payParams.setProportion(10); // RMB��������ҵı�,��:10��ʾ����Ϊ1RMB:10�������
                                payParams.setCustomPrice(false);// �������Ϊtrue�� setCustomText�Ż���Ч
                                payParams.setCustomText("0.01Ԫ�һ�500��ʯ");
                                /**
                                 * ֧���ӿ�,��Ҫͬʱ�ṩ֧���͵�¼�Ļص��ӿ�,���û�û�õ�¼,��ֱ����ת����¼���� �����ʹ�ûص�,��null����
                                 */
                                KPSuperSDK.pay(MainActivity.this, payParams, new KPPayCallBack() {
                                    @Override
                                    public void onPaySuccess() {
                                        Toast.makeText(MainActivity.this, "֧���ɹ�", Toast.LENGTH_SHORT).show();
                                        System.out.println("֧���ɹ�");
                                    }

                                    @Override
                                    public void onPayFailed() {
                                        Toast.makeText(MainActivity.this, "֧��ʧ��", Toast.LENGTH_SHORT).show();
                                        System.out.println("֧��ʧ��");
                                    }

                                    @Override
                                    public void onPayCancle() {
                                        Toast.makeText(MainActivity.this, "�˳�֧��", Toast.LENGTH_SHORT).show();
                                        System.out.println("�˳�֧��");
                                    }
                                });
                            }
                        });

                builder.setView(editText);
                builder.show();
            }
        });

        // ���ݲɼ�
        collect_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (KPSuperSDK.isLogin()) {
                    int roleLevel = 22;// ��ɫ�ȼ�
                    String serviceName = "��ս֮��"; // ����������
                    String roleName = "����"; // ��ɫ����
                    String id = "10000331";// ��Ϸ�������û� ID������cp�����û���userid������Ϊ�գ�
                    KPSuperSDK.setUserGameRole(MainActivity.this, serviceName, roleName, id, roleLevel);
                } else {
                    Toast.makeText(MainActivity.this, "���ȵ�¼", Toast.LENGTH_LONG).show();
                }
            }
        });

        logOut_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (KPSuperSDK.isLogin()) {
                    KPSuperSDK.logoutAccount();
                } else {
                    Toast.makeText(MainActivity.this, "���ȵ�¼", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void showVersion() {
        ApplicationInfo appInfo = null;
        try {
            appInfo = this.getPackageManager().getApplicationInfo(this.getPackageName(), PackageManager.GET_META_DATA);
            String appkey = appInfo.metaData.get("KAOPU_APPKEY").toString(); // ��ȡAPPKEY
            String appsecret = appInfo.metaData.get("KAOPU_SECRETKEY").toString(); // ��ȡAPPSECRET
            String appVersion = appInfo.metaData.get("KAOPU_APPVERSION").toString(); // ��ȡAPPVERSION
            String appId = appInfo.metaData.get("KAOPU_APPID").toString(); // ��ȡAPPID


            textView1.setText("SDK�汾:  " + PayConstants.JAR_VERSION + "\nappkey:  " + appkey + "\nӦ�ð汾��:  " + appVersion + "\nappId:  " + appId
                    + "\n����:  " + channelKey + "\nappsecret:  " + appsecret);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        KPSuperSDK.closeFloatView(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        KPSuperSDK.showFloatView(this);
    }

    @Override
    protected void onDestroy() {
        KPSuperSDK.release();
        super.onDestroy();
    }


}
