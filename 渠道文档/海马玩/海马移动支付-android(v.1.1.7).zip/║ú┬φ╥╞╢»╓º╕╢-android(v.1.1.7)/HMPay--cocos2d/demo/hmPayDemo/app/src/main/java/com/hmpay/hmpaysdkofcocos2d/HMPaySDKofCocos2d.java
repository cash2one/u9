package com.hmpay.hmpaysdkofcocos2d;

import android.os.Bundle;

import com.haima.plugin.cocos2d.HMPay;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

public class HMPaySDKofCocos2d extends Cocos2dxActivity {

    private static final String APP_ID = "4243df6fb1eaf8427507df80c1bbb391";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //这里APP ID 传入null 表示从manifest中获取
        HMPay.init(this, true, APP_ID);
    }

    @Override
    protected void onResume() {
        super.onResume();
        HMPay.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        HMPay.onPause();
    }

    public Cocos2dxGLSurfaceView onCreateView() {
        Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
        glSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);
        return glSurfaceView;
    }

    static {
        System.loadLibrary("cocos2dcpp");
    }

}
