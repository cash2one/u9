#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "HMcallback.h"

class HelloWorld :  public HMcallback,public cocos2d::CCLayer
{
public:
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();  

    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::CCScene* scene();
    
    // a selector callback
    void menuCloseCallback(CCObject* pSender);

	void menuBtnCallback(CCObject* pSender);

	virtual void HMLogOut();

	virtual void HMPaySuccess(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam);

	virtual void HMPayFailed(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam,int code,const char *msg);

	virtual void HMCheckOrderSuccess(const char *orderId,float money,int status);

	virtual void HMCheckOrderFailed(const char *orderId,int code,const char *msg);

	virtual void HMLoginSuccess(const char *userName,const char *UserId,const char *loginToken);

	virtual void HMLoginFailed(int code,const char *msg);

	virtual void HMCheckUpdateSuccess(bool isNeedUpdate,bool isForceUpdate, bool isTestMode);

	virtual void HMCheckUpdateFailed(int code,const char *msg,int ifErrorType);

	virtual void HMCheckTokenSuccess(bool isTokenLegal);

	virtual void HMCheckTokenFailed(int code,const char *msg);

	virtual void HMLoginCancel();

	virtual void HMPayCancel();

	virtual void HMRegistCancel();

    // implement the "static node()" method manually
    CREATE_FUNC(HelloWorld);
};

#endif // __HELLOWORLD_SCENE_H__
