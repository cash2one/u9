#ifndef CALLBACK_HM_H
#define CALLBACK_HM_H
class HMcallback
{
public:
	/**
	 * 登录成功回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonLoginSuccess会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 *
	 * @param userName 用户账号
	 * @param userId用户ID,客户端请求根据新老用户下发 CPID或者用户ID（新用户：CPID，老用户：用户ID），
     * 					仅仅适用于客户端请求或者拿到客户端userName的服务器端请
	 * @param loginToken 游戏服务器向sdk服务器验证登陆用的token,
     *                   此处游戏开发者可以直接访问游戏服务器获取玩家游戏资料，对于游戏账户安全要求高德也可以由游戏服务器将海马的appid、
     *                   登录token以post方式发送给海马服务器进行登录验证
     */
	virtual void HMLoginSuccess(const char *userName,const char *UserId,const char *loginToken){}
	
	/**
	 * 登录失败回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonLoginFailed会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 * 
	 * @param code 错误码
	 * @param msg 错误信息
     */
	virtual void HMLoginFailed(int code,const char *msg){}	

	/**
	 * 注销成功回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonLogOut会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 */
	virtual void HMLogOut(){}	

	/**
	 * 支付成功回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonPaySuccess会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
 	 *
	 * @param orderId 订单号(不能为空),长度保证在255之内
	 * @param puductName 商品名称(不能为空)
	 * @param gameName 游戏名称（不能为空）
	 * @param price 消费金额(单位元，保留两位小数), 必须大于等于0
	 * @param userParam 用户自定义参数(可以为空),在支付成功后海马服务器会在回调中返回此参数
	 */
	virtual void HMPaySuccess(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam){}

	/**
	 * 支付失败回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonPaySuccess会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC 
	 *
	 * @param orderId 订单号(不能为空),长度保证在255之内
	 * @param puductName 商品名称(不能为空)
	 * @param gameName 游戏名称（不能为空）
	 * @param price 消费金额(单位元，保留两位小数), 必须大于等于0
	 * @param userParam 用户自定义参数(可以为空),在支付成功后海马服务器会在回调中返回此参数
	 * @param code 错误码
	 * @param msg 错误信息
	 */
	virtual void HMPayFailed(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam,int code,const char *msg){}

	/**
	 * 查询订单成功回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonCheckOrderSuccess会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 * 
	 * @param orderId 订单号(不能为空),长度保证在255之内
	 * @param money 金额(RMB元)
	 * @param status 订单状态(0:未支付;1:支付成功)
	 */
	virtual void HMCheckOrderSuccess(const char *orderId,float money,int status){}

	/**
	 * 查询订单失败回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonCheckOrderFailed会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 *
	 * @param orderId 订单号(不能为空),长度保证在255之内
	 * @param code 错误码
	 * @param msg 错误信息
	 */
	virtual void HMCheckOrderFailed(const char *orderId,int code,const char *msg){}

	/**
	 * 检查更新成功回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonCheckUpdateSuccess会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC 
	 *
	 * @param isNeedUpdate 是否需要更新
	 * @param isForceUpdate 是否是强制更新
	 * @param isTestMode 是否是测试模式
	 */
	virtual void HMCheckUpdateSuccess(bool isNeedUpdate, bool isForceUpdate, bool isTestMode){}

	/**
	 * 检查更新成功失败回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonCheckUpdateFailed会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC 
	 *
	 * @param code 错误码
     * @param msg 错误信息
	 * @param ifErrorType 检查更新失败，需要显示的界面 初始化时填入的值
	 * 
	 */
	virtual void HMCheckUpdateFailed(int code,const char *msg,int ifErrorType){}

	/**
     * 取消登录回调
     * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonLoginCancel会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
     */
    virtual void HMLoginCancel(){}

    /**
	 * 取消注册回调
	 * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonRegistCancel会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
	 */
    virtual void HMRegistCancel(){}

    /**
     * 取消支付回调
     * 当发生回调时，com.haima.plugin.cocos2d.HMPay.jonPayCancel会通知此方法接收回调
	 * 具体的回调触发点可参见海马提供的JAVA DOC
     */
    virtual void HMPayCancel(){}

	/**
	 * 检查token成功回调(已废弃)
	 * 
	 * @param isTokenLega token是否可用
	 */
	virtual void HMCheckTokenSuccess(bool isTokenLegal){}

	/**
	 * 检查token失败回调(已废弃)
	 * 
	 * @param code 错误码
	 * @param msg 错误信息
	 */
	virtual void HMCheckTokenFailed(int code,const char *msg){}	

};
#endif