#include "tools.h"

#ifdef WIN32
#include "iconv.h"
#else
#include "../../libiconv/include/iconv.h"
#endif

int Tools::GBKToUTF8(std::string &gbkStr,const char* toCode,const char* formCode)
{
	iconv_t iconvH;
	iconvH = iconv_open(formCode,toCode);
	if(iconvH == 0)
	{
		return -1;
	}

	//const char* strChar = gbkStr.c_str();
	//const char** pin = &strChar;

	char *strChar = const_cast<char*>(gbkStr.c_str());
	char** pin = &strChar;

	size_t strLength = gbkStr.length();
	char* outbuf = (char*)malloc(strLength*4);
	char* pBuff = outbuf;
	memset(outbuf,0,strLength*4);
	size_t outLength = strLength*4;
	if(-1 == iconv(iconvH,pin,&strLength,&outbuf,&outLength))
	{
		iconv_close(iconvH);
		return -1;
	}

	gbkStr = pBuff;
	iconv_close(iconvH);
	return 0;
}

const char* Tools::GBKToUTF(std::string &gbkStr)
{
	GBKToUTF8(gbkStr,"gbk","utf-8");

	return gbkStr.c_str();
}

const char* Tools::getOrderNum()
{
	time_t timer;
	struct tm *tblock;
	timer=time(NULL);
	tblock=localtime(&timer);

	char timeString[15]={0};
	sprintf(timeString, "%d%02d%02d%02d%02d%02d",tblock->tm_year+1900,tblock->tm_mon+1,tblock->tm_mday,tblock->tm_hour,tblock->tm_min,tblock->tm_sec);
	CCLOG("%s",timeString);
	return timeString;
}