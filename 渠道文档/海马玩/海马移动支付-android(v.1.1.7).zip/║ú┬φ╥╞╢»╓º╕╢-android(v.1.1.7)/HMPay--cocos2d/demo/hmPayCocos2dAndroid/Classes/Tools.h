#ifndef _TOOLS_H_
#define _TOOLS_H_

#include "cocos2d.h"
#ifdef WIN32
#include "iconv.h"
#else
#include "../../libiconv/include/iconv.h"
#endif

class Tools{
public:
	static const char* GBKToUTF(std::string &gbkStr);
	static const char* getOrderNum();
	static int GBKToUTF8(std::string &gbkStr,const char* toCode,const char* formCode);
};
#endif