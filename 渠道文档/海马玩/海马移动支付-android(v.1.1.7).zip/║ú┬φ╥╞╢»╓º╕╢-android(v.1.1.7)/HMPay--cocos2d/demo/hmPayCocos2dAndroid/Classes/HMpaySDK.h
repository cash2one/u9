#ifndef __HMPaySDK__HMpaySDK__
#define __HMPaySDK__HMpaySDK__
#include "HMcallback.h"
using namespace std;

class HMpaySDK {

private:
	HMcallback *myHMCallback;

public:

	enum ifErrorType {
        /**
         * 检查更新失败后，不显示弹框界面
         */
		CHECKUPDATE_FAILED_SHOW_NONE = 1,
        /**
         * 检查更新失败后，显示弹框界面，且界面只有确定按钮，点击确定会继续重试更新逻辑
         */
		CHECKUPDATE_FAILED_SHOW_SURE = 2,
        /**
         * 检查更新失败后，显示弹框界面，且界面有取消和确定按钮，点击确定会继续重试更新逻辑，点击取消则不会
         */
		CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE = 3,
	};

    /**
     * 获取唯一实例
     */
	static HMpaySDK* getInstance();

    /**
     * 获取回调对象
     *
     * @return 回调对象
     */
    HMcallback* getCallback() { return myHMCallback; }
    
    /**
     * 设置委托代理接收回调,设置后才可收到登录支付相关回调
     *
     * @param hmCallback 回调对象
     */
    void setDelegate(HMcallback* hmCallback) { myHMCallback = hmCallback; }

	/**
     * 初始化,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.initCocos2d()
	 * @param isTestMode 是否是测试模式
	 * @param ifErrorType 如果检查更新失败,需要的提示
	 *        参见
	 *        CHECKUPDATE_FAILED_SHOW_NONE
	 *        CHECKUPDATE_FAILED_SHOW_SURE
	 *        CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE
	 */
	void init(bool isTestMode,int ifErrorType);

	/**
	 * 登录,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.login()
	 */
    void login();

	/**
	 * 用户是否登录,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.isLogined()
     *
     * @return 是或者否
	 */
	bool isLogined();

	/**
	 * 注销,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.logOut()
     * 
     * @return 是否成功
	 */
	bool logOut();

	/**
	 * 切换用户,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.switchAccount()
	 */
	void switchAccount();

	/**
	 * 打开用户中心,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.startUserCenter()
     * 
     * @return 未登录或有其他界面正在显示，将返回false. 成功返回true
	 */
	bool startUserCenter();

	/**
	 * 获取当前用户账户,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.getUserInfo()
     *
     * @return 用户账户
	 */
	const char* getUserInfo();

	/**
	 * 查询订单状态信息,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.checkOrder()   
     *
     * @param orderId 订单号(长度保证在255之内)
	 */
	void checkOrder(const char* orderId);

	/**
	 * 支付,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.pay()
     *
	 * @param orderNo 订单号(由游戏服务器生成,长度保证在255之内)
	 * @param puductName 商品名称
	 * @param gameName 游戏名称
	 * @param price 商品价格（RMB元）
	 * @param userParam 用户自定义参数(可以为空),在支付成功后海马服务器会在回调中返回此参数
	**/
	void pay(const char *orderNo,const char *puductName,const char *gameName,float price,const char *userParam);

	/**
	 * 日志开关,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.setLogEnable()  
     * 
     * @param enable 是否开启日志
	 */
	 void setLogEnable(bool enable);

    /**
	 * 检查更新,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.checkUpdate()
	 * @param isTestMode 是否是测试模式
	 * @param ifErrorType 检查更新失败，需要显示的界面 初始化时填入的值
	 *        参见
	 *        CHECKUPDATE_FAILED_SHOW_NONE
	 *        CHECKUPDATE_FAILED_SHOW_SURE
	 *        CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE
	 */
	void checkUpdate(bool isTestMode,int ifErrorType);

	/**
     * 注册取消登录时的回调,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.registerLoginCancelListener()
     */
    void registerLoginCancelListener();

	/**
     * 注册取消注册时的回调,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.registerRegistCancelListener()
     */
    void registerRegistCancelListener();

    /**
     * 注册取消支付时的回调,对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.registerPayCancelListener()
     */
    void registerPayCancelListener();

    /**
     * 移除取消登录时的回调(请在页面销毁时调用),对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.removeLoginCancelListener()
     */
    void removeLoginCancelListener();

    /**
	 * 移除取消注册时的回调(请在页面销毁时调用),对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.removeRegistCancelListener()
	 */
	void removeRegistCancelListener();

    /**
     * 移除取消支付时的回调(请在页面销毁时调用),对应的JNI方法可参见JAVA DOC的com.haima.plugin.cocos2d.HMPay.removePayCancelListener()
     */
    void removePayCancelListener();

    /**
	 * 检查token合法性(已废弃)
	 */
	void checkTokenLegal();
};

#endif

