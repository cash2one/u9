#include "HelloWorldScene.h"
#include "HMpaySDK.h"
#include "Tools.h"


USING_NS_CC;

HMpaySDK *hmpay;
CCLabelTTF *pLabel;
CCMenuItemFont *pLoginItem;
CCMenuItemFont *pGetUserItem;
CCMenuItemFont *pIsLoginedItem;
CCMenuItemFont *pLogOutItem;
CCMenuItemFont *pSwitchAccountItem;
CCMenuItemFont *pUserCenterItem;
CCMenuItemFont *pSearchOrderItem;
CCMenuItemFont *pPayItem;
CCMenuItemFont *pLogOpenItem;
CCMenuItemFont *pLogCloseItem;
CCMenuItemFont *pCheckUpdateItem;
CCMenuItemFont *pCheckTokenLegal;
char orderId[15]={0};//当前订单号


CCScene* HelloWorld::scene() {
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
	
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();

	CCLOG("%f,%f,%f,%f",visibleSize.width,visibleSize.height,origin.x,origin.y);

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object




    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback));
    
	pCloseItem->setPosition(ccp(origin.x + visibleSize.width - pCloseItem->getContentSize().width/2 ,
                                origin.y + pCloseItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    CCMenu*  mExit = CCMenu::create(pCloseItem, NULL);
	
    mExit->setPosition(CCPointZero);
    this->addChild(mExit, 1);


	//获取实例
	hmpay=HMpaySDK::getInstance();
	//设置回调代理
	hmpay->setDelegate(this);

	
	//初始化
	hmpay->init(true,hmpay->CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE);

	/** 在cocos2d-x中使用中文 1**/
	std::string china="登录"; 
    const char* title=Tools::GBKToUTF(china);
    pLabel = CCLabelTTF::create(title, "Arial", 12);
    
    // position the label on the center of the screen
    pLabel->setPosition(ccp(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height - pLabel->getContentSize().height));

    // add the label as a child to this layer
    this->addChild(pLabel, 1);
	CCLOG("%x",pLabel);

	CCLOG("%f,%f",visibleSize.width/2,visibleSize.height/2);

	/** 在cocos2d-x中使用中文 2**/
	//利用CCDictionary来读取xml
	CCDictionary *strings = CCDictionary::createWithContentsOfFile("string.xml");
	//读取Hello键中的值 objectForKey根据key，获取对应的string
	const char *login = ((CCString*)strings->objectForKey("login"))->m_sString.c_str();
	const char *getUser = ((CCString*)strings->objectForKey("getUser"))->m_sString.c_str();
	const char *isLogined = ((CCString*)strings->objectForKey("isLogined"))->m_sString.c_str();
	const char *logout = ((CCString*)strings->objectForKey("logout"))->m_sString.c_str();
	const char *switchaccount = ((CCString*)strings->objectForKey("switchaccount"))->m_sString.c_str();
	const char *usercenter = ((CCString*)strings->objectForKey("usercenter"))->m_sString.c_str();
	const char *searchOrder = ((CCString*)strings->objectForKey("searchOrder"))->m_sString.c_str();
	const char *pay = ((CCString*)strings->objectForKey("pay"))->m_sString.c_str();
	const char *debugOpen = ((CCString*)strings->objectForKey("debugOpen"))->m_sString.c_str();
	const char *debugClose = ((CCString*)strings->objectForKey("debugClose"))->m_sString.c_str();

	//登录按钮
	pLoginItem = CCMenuItemFont::create(login,this,menu_selector(HelloWorld::menuBtnCallback));
	pLoginItem->setPosition(ccp(visibleSize.width/6,visibleSize.height/4*3));
	pLoginItem->setFontSizeObj(12);
	pLoginItem->setTag(101);

	CCMenu*  mLogin = CCMenu::create(pLoginItem, NULL);
	mLogin->setPosition(CCPointZero);
	this->addChild(mLogin, 1);

	//获取用户信息按钮
	pGetUserItem = CCMenuItemFont::create(getUser,this,menu_selector(HelloWorld::menuBtnCallback));
	pGetUserItem->setPosition(ccp(visibleSize.width/6*2,visibleSize.height/4*3));
	pGetUserItem->setFontSizeObj(12);
	pGetUserItem->setTag(102);

	CCMenu*  mGetUser= CCMenu::create(pGetUserItem, NULL);
	mGetUser->setPosition(CCPointZero);
	this->addChild(mGetUser, 1);

	//是否登陆按钮
	pIsLoginedItem = CCMenuItemFont::create(isLogined,this,menu_selector(HelloWorld::menuBtnCallback));
	pIsLoginedItem->setPosition(ccp(visibleSize.width/6*3 ,visibleSize.height/4*3));
	pIsLoginedItem->setFontSizeObj(12);
	pIsLoginedItem->setTag(103);

	CCMenu*  mIsLogin = CCMenu::create(pIsLoginedItem, NULL);
	mIsLogin->setPosition(CCPointZero);
	this->addChild(mIsLogin, 1);

	//登出按钮
	pLogOutItem = CCMenuItemFont::create(logout,this,menu_selector(HelloWorld::menuBtnCallback));
	pLogOutItem->setPosition(ccp(visibleSize.width/6*4 ,visibleSize.height/4*3));
	pLogOutItem->setFontSizeObj(12);
	pLogOutItem->setTag(104);

	CCMenu*  mLogOut = CCMenu::create(pLogOutItem, NULL);
	mLogOut->setPosition(CCPointZero);
	this->addChild(mLogOut, 1);

	//切换用户按钮
	pSwitchAccountItem = CCMenuItemFont::create(switchaccount,this,menu_selector(HelloWorld::menuBtnCallback));
	pSwitchAccountItem->setPosition(ccp(visibleSize.width/6*5 ,visibleSize.height/4*3));
	pSwitchAccountItem->setFontSizeObj(12);
	pSwitchAccountItem->setTag(105);

	CCMenu*  mSwitchAccount = CCMenu::create(pSwitchAccountItem, NULL);
	mSwitchAccount->setPosition(CCPointZero);
	this->addChild(mSwitchAccount, 1);

	//用户中心按钮
	pUserCenterItem = CCMenuItemFont::create(usercenter,this,menu_selector(HelloWorld::menuBtnCallback));
	pUserCenterItem->setPosition(ccp(visibleSize.width/6 ,visibleSize.height/4*2));
	pUserCenterItem->setFontSizeObj(12);
	pUserCenterItem->setTag(106);

	CCMenu*  mUserCenter = CCMenu::create(pUserCenterItem, NULL);
	mUserCenter->setPosition(CCPointZero);
	this->addChild(mUserCenter, 1);

	//订单查询按钮
	pSearchOrderItem = CCMenuItemFont::create(searchOrder,this,menu_selector(HelloWorld::menuBtnCallback));
	pSearchOrderItem->setPosition(ccp(visibleSize.width/6*2,visibleSize.height/4*2));
	pSearchOrderItem->setFontSizeObj(12);
	pSearchOrderItem->setTag(107);

	CCMenu*  mSearchOrder = CCMenu::create(pSearchOrderItem, NULL);
	mSearchOrder->setPosition(CCPointZero);
	this->addChild(mSearchOrder, 1);

	//支付按钮
	pPayItem = CCMenuItemFont::create(pay,this,menu_selector(HelloWorld::menuBtnCallback));
	pPayItem->setPosition(ccp(visibleSize.width/6*3,visibleSize.height/4*2));
	pPayItem->setFontSizeObj(12);
	pPayItem->setTag(108);

	CCMenu*  mPay = CCMenu::create(pPayItem, NULL);
	mPay->setPosition(CCPointZero);
	this->addChild(mPay, 1);

	//打印日志按钮
	pLogOpenItem = CCMenuItemFont::create(debugOpen,this,menu_selector(HelloWorld::menuBtnCallback));
	pLogOpenItem->setPosition(ccp(visibleSize.width/6*4,visibleSize.height/4*2));
	pLogOpenItem->setFontSizeObj(12);
	pLogOpenItem->setTag(109);

	CCMenu*  mLogOpen = CCMenu::create(pLogOpenItem, NULL);
	mLogOpen->setPosition(CCPointZero);
	this->addChild(mLogOpen, 1);

	//关闭日志按钮
	pLogCloseItem = CCMenuItemFont::create(debugClose,this,menu_selector(HelloWorld::menuBtnCallback));
	pLogCloseItem->setPosition(ccp(visibleSize.width/6*5 ,visibleSize.height/4*2));
	pLogCloseItem->setFontSizeObj(12);
	pLogCloseItem->setTag(110);

	CCMenu*  mLogClose = CCMenu::create(pLogCloseItem, NULL);
	mLogClose->setPosition(CCPointZero);
	this->addChild(mLogClose, 1);

	//检查更新按钮
	pCheckUpdateItem = CCMenuItemFont::create("C update",this,menu_selector(HelloWorld::menuBtnCallback));
	pCheckUpdateItem->setPosition(ccp(visibleSize.width/6 ,visibleSize.height/4));
	pCheckUpdateItem->setFontSizeObj(12);
	pCheckUpdateItem->setTag(111);

	CCMenu*  mCheckUpdate = CCMenu::create(pCheckUpdateItem, NULL);
	mCheckUpdate->setPosition(CCPointZero);
	this->addChild(mCheckUpdate, 1);

	//检查token按钮(已废弃)
	pCheckTokenLegal = CCMenuItemFont::create("C token",this,menu_selector(HelloWorld::menuBtnCallback));
	pCheckTokenLegal->setPosition(ccp(visibleSize.width/6*2 ,visibleSize.height/4));
	pCheckTokenLegal->setFontSizeObj(12);
	pCheckTokenLegal->setTag(112);

	CCMenu*  mCheckTokenLegal = CCMenu::create(pCheckTokenLegal, NULL);
	mCheckTokenLegal->setPosition(CCPointZero);
	this->addChild(mCheckTokenLegal, 1);

    return true;
}

 //登录成功回调
 void HelloWorld::HMLoginSuccess(const char *userName,const char *userId,const char *loginToken)
 {
	 //userName用户账户，userId用户纯数字id标示，loginToken登陆验证token
	 // 此处游戏开发者可以直接访问游戏服务器获取玩家游戏资料，对于游戏账户安全要求高的也可以由游戏服务器将海马appid，登陆token以post形式发送给海马服务器进行登陆验证(需要将游戏服务器的ip告诉海马开发人员以便验证安全性)
	 // 验证地址http://api.haimawan.com/index.php?m=api&a=validate_token
	 CCLOG("login success!!!");
	 char log[255];
	 sprintf(log, "login success!!!userId:%s,userName:%s",userId,userName);
	 string logstring=log;
	 CCLOG("%s",log);
	 pLabel->setString(Tools::GBKToUTF(logstring));
 }

 //登录失败回调
 void HelloWorld::HMLoginFailed(int code,const char *msg)
 {
	pLabel->setString(msg);
 }
 //注销回调
 void HelloWorld:: HMLogOut()
 {
	pLabel->setString("log out"); 
 }

 //支付成功回调
 void HelloWorld::HMPaySuccess(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam)
 {
	 CCLOG("pay success!!!");
	 char log[255];
	 sprintf(log, "pay success!!!orderId:%s,puductName:%s,gameName:%s,\n price:%.2f,userParam:%s",orderId,puductName,gameName,price,userParam);
	 string logstring=log;
	 CCLOG("%s",log);
	 pLabel->setString(Tools::GBKToUTF(logstring));
 }

 //支付失败回调
 void HelloWorld::HMPayFailed(const char *orderId,const char *puductName,const char *gameName,float price,const char *userParam,int code,const char *msg)
 {
	 CCLOG("pay failed!!!");
	// string puductNameString=puductName+"购买失败！ "+msg;
	// pLabel->setString(Tools::GBKToUTF(puductNameString));
 }

 //查询订单状态成功回调
  void HelloWorld::HMCheckOrderSuccess(const char *orderId,float money,int status)
  {
	 CCLOG("checkorder success!!!");
	 char log[255];
	 sprintf(log, "checkorder success!!!orderId:%s , price:%10.2f , status:%d",orderId,money,status);
	 pLabel->setString(log);
  }

  //查询订单状态失败回调
  void HelloWorld::HMCheckOrderFailed(const char *orderId,int code,const char *msg)
  {
	    CCLOG("checkorder failed!!!");
		char log[255];
		sprintf(log, "checkorder failed!!!orderId:%s,code:%d,msg:%s",orderId,code,msg);
		string logstring=log;
		pLabel->setString(Tools::GBKToUTF(logstring));
   }

  //检查更新成功回调
  void HelloWorld::HMCheckUpdateSuccess(bool isNeedUpdate, bool isForceUpdate, bool isTestMode)
  {
	  CCLOG("checkUpdate success!!!");
	  pLabel->setString( "checkUpdate success!!!");
	  //此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
      if (isForceUpdate) {
            //强制更新
            //回调逻辑建议:如果是强制更新(且用户本地版本小于服务器版本，即用户必须更新)，用户必须更新CP的应用后，才可以进入CP的后续界面
            if (!isNeedUpdate) {
                //用户无需更新
                //回调逻辑建议:用户不需要更新，可以直接进入CP的后续界面
            } else {
                //用户必须更新
                //回调逻辑建议:用户必须更新，当点击确认后，会自动打开浏览器进入下载
            }
        } else {
            if (isNeedUpdate) {
                //用户需要更新
                //回调逻辑建议:如果是非强制更新，则允许用户选择确认更新或者取消
                //当用户点击确认后，会自动打开浏览器进入下载，点击取消则不会下载
            } else {
                //用户无需更新
            }
        }
  }

  //检查更新失败回调
  void HelloWorld::HMCheckUpdateFailed(int code,const char *msg,int ifErrorType)
  {
	  CCLOG("checkUpdate failed!!!");
	  char log[255];
	  sprintf(log, "checkUpdate failed!!!msg:%s",msg);
	  string logstring=log;
	  pLabel->setString(Tools::GBKToUTF(logstring));
  }

  //检查token成功回调(已废弃)
  void HelloWorld::HMCheckTokenSuccess(bool isTokenLegal)
  {
	 CCLOG("checkToken success!!!");
	 if (isTokenLegal)
	 {
		  pLabel->setString("token is Legal");
	 }
	 else{
		  pLabel->setString("token is Illegal");
	 }
	 
  }

  //检查token失败回调(已废弃)
  void HelloWorld::HMCheckTokenFailed(int code,const char *msg){
	  CCLOG("checkToken failed!!!");
	  char log[255];
	  sprintf(log, "checkToken failed!!!msg:%s",msg);
	  string logstring=log;
	  pLabel->setString(Tools::GBKToUTF(logstring));
  }

  //取消登录回调
  void HelloWorld::HMLoginCancel(){
  	pLabel->setString("login cancel call back");
  }

  //取消注册回调
  void HelloWorld::HMRegistCancel(){
  	pLabel->setString("Regist cancel call back");
  }

  //取消支付回调
  void HelloWorld::HMPayCancel(){
  	pLabel->setString("pay cancel call back");
  }

  void HelloWorld::menuCloseCallback(CCObject* pSender){
	hmpay->removeLoginCancelListener();
	hmpay->removePayCancelListener();
	hmpay->removeRegistCancelListener();
	CCDirector::sharedDirector()->end();
}

void HelloWorld::menuBtnCallback(CCObject* pSender){
	CCMenuItemImage *menu=(CCMenuItemImage *)pSender;
	int tag=menu->getTag();
	std::string notLogin="用户未登陆";
	hmpay->registerLoginCancelListener();
	hmpay->registerRegistCancelListener();
	hmpay->registerPayCancelListener();
	//点击登陆按钮
	if (tag==pLoginItem->getTag()){
		hmpay->login();
	}
	//点击获取用户信息按钮
	else if(tag==pGetUserItem->getTag()){
		string log = hmpay->getUserInfo();
		if (string(log)==string(""))
			pLabel->setString(Tools::GBKToUTF(notLogin));
		else
			pLabel->setString(Tools::GBKToUTF(log));
	}
	//点击是否登陆按钮
	else if(tag==pIsLoginedItem->getTag()){
		if (hmpay->isLogined()){
			std::string log = "用户已登陆"; 
			pLabel->setString(Tools::GBKToUTF(log));
		}
		else{
			pLabel->setString(Tools::GBKToUTF(notLogin));
		}
	}
	//点击登出按钮
	else if (tag==pLogOutItem->getTag()){
		std::string log="用户已注销";
		if(hmpay->logOut()){
			pLabel->setString(Tools::GBKToUTF(log));
		}
		else{
			pLabel->setString(Tools::GBKToUTF(notLogin));
		}
	}
	//点击切换用户按钮
	else if (tag==pSwitchAccountItem->getTag()){
		if (hmpay->isLogined()){
			hmpay->switchAccount();
		}
		else {
			pLabel->setString(Tools::GBKToUTF(notLogin));
		}
	}
	//点击个人中心按钮
	else if (tag==pUserCenterItem->getTag()){
		if (!hmpay->startUserCenter())
		{
			pLabel->setString(Tools::GBKToUTF(notLogin));
		}
	}
	//点击支付按钮
	else if (tag==pPayItem->getTag()){
		//游戏服务器生成的订单号(此处为demo模拟生成订单号)
		time_t timer;
		struct tm *tblock;
		timer=time(NULL);
		tblock=localtime(&timer);
		sprintf(orderId, "%d%02d%02d%02d%02d%02d",tblock->tm_year+1900,tblock->tm_mon+1,tblock->tm_mday,tblock->tm_hour,tblock->tm_min,tblock->tm_sec);

		std::string puductName="铜锣烧";
		std::string gameName="大掌门";
		float price=0.1;
		std::string userParm="需要的支付后返回的内容";
		hmpay->pay(orderId,Tools::GBKToUTF(puductName),Tools::GBKToUTF(gameName),price,Tools::GBKToUTF(userParm));
	}
	//查询订单按钮
	else if (tag==pSearchOrderItem->getTag()){
		if (hmpay->isLogined()){
			if (strlen(orderId)){
				hmpay->checkOrder(orderId);
			}else{
				std::string verfiyOrderMsg="没有可检查的订单号";
				pLabel->setString(Tools::GBKToUTF(verfiyOrderMsg));
			}
		}else{
			pLabel->setString(Tools::GBKToUTF(notLogin));
		}
	}
	//打印错误日志开
	else if (tag==pLogOpenItem->getTag()){
		hmpay->setLogEnable(true);
		pLabel->setString("log open");
	}
	//打印错误日志关闭
	else if (tag==pLogCloseItem->getTag()){
		hmpay->setLogEnable(false);
		pLabel->setString("log close");
	}
	//检查更新
	else if (tag==pCheckUpdateItem->getTag()){
		hmpay->checkUpdate(true,hmpay->CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE);
	}
	//检测token合法性
	else if (tag==pCheckTokenLegal->getTag()){
		hmpay->checkTokenLegal();
	}
}