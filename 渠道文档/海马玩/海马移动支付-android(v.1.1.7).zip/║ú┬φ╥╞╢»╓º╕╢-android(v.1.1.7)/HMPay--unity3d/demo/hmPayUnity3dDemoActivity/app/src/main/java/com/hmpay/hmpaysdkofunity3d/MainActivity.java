package com.hmpay.hmpaysdkofunity3d;

import android.os.Bundle;

import com.haima.plugin.unity3d.HMPay;
import com.unity3d.player.UnityPlayerActivity;

public class MainActivity extends UnityPlayerActivity {

    String appid = "cf105bdab64664072194ed77b1d8915e";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 参数二为屏幕方向是否横屏，参数三为appid
        HMPay.init(this, false, appid);
    }

    @Override
    protected void onResume() {
        super.onResume();
        HMPay.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        HMPay.onPause();
    }

}
