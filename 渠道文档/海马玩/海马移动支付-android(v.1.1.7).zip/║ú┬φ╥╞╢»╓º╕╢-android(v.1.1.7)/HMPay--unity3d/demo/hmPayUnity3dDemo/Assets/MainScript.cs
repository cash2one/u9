﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MainScript : MonoBehaviour {

	AndroidJavaClass jc;
	string message="欢迎使用海马支付sdk";
    string orderNo = "";
	
	void Start()
	{
		AndroidJNIHelper.debug = true;
		jc = new AndroidJavaClass("com.haima.plugin.unity3d.HMPay");
        //执行初始化，具体参数含义参见海马的JAVA DOC
		jc.CallStatic("initUnity",this.gameObject.name, true,3);
	}
	
	void OnGUI()
	{
        GUI.Label(new Rect(Screen.width / 2 - 100, Screen.height /8-40, 200, 80), message);
        //注册取消登录回调，具体参数含义参见海马的JAVA DOC
		jc.CallStatic("registerLoginCancelListener", this.gameObject.name);
        //注册取消支付回调，具体参数含义参见海马的JAVA DOC
        jc.CallStatic("registerPayCancelListener", this.gameObject.name);
        //注册取消登录回调，具体参数含义参见海马的JAVA DOC
        jc.CallStatic("registerRegistCancelListener", this.gameObject.name);
		
		if (GUI.Button(new Rect(Screen.width/3-75, Screen.height/8*2-40,150, 80), "登录"))
		{
            //登录，具体参数含义参见海马的JAVA DOC
			jc.CallStatic("login", this.gameObject.name);	
		}
        if (GUI.Button(new Rect(Screen.width / 3 * 2 - 75, Screen.height / 8 * 2 - 40, 150, 80), "获取用户信息"))
		{
            //获取用户信息，具体参数含义参见海马的JAVA DOC
            string userName = jc.CallStatic<string>("getUserInfo");
            if (userName.Equals(""))
			{
                message = "用户未登录";
			}
            else
            {
                message = userName;
            }
			
		}
        if (GUI.Button(new Rect(Screen.width / 3 - 75, Screen.height / 8 * 3 - 40, 150, 80), "是否已经登录"))
        {
            //判断用户是否登录，具体参数含义参见海马的JAVA DOC
            if (jc.CallStatic<bool>("isLogined"))
            {
                message = "用户已登录";
            }
            else
            {
                message = "用户未登录";
            }
        }
        if (GUI.Button(new Rect(Screen.width / 3 * 2 - 75, Screen.height / 8* 3 - 40, 150, 80), "注销"))
        {
            //注销用户，具体参数含义参见海马的JAVA DOC
            if (jc.CallStatic<bool>("logOut"))
            {
                message = "注销成功"; 
            }
            else
            {
                message = "用户未登录";          
            }
        }
        if (GUI.Button(new Rect(Screen.width / 3 - 75, Screen.height / 8 * 4 - 40, 150, 80), "切换用户"))
        {
            //切换用户，具体参数含义参见海马的JAVA DOC
            jc.CallStatic("switchAccount");
        }

        if (GUI.Button(new Rect(Screen.width / 3 * 2 - 75, Screen.height / 8 * 4 - 40, 150, 80), "个人中心"))
        {
            //打开用户中心，具体参数含义参见海马的JAVA DOC
            if (!jc.CallStatic<bool>("startUserCenter"))
            {
                message = "用户未登录";
            }
        }

        if (GUI.Button(new Rect(Screen.width / 3 - 75, Screen.height /8 * 5 - 40, 150, 80), "订单查询"))
        {
            //查询订单状态，具体参数含义参见海马的JAVA DOC
            jc.CallStatic("checkOrder", this.gameObject.name,orderNo);
        }
        if (GUI.Button(new Rect(Screen.width / 3 * 2 - 75, Screen.height /8 * 5 - 40, 150, 80), "支付"))
        {
            //订单号应由游戏服务器生成（这里只是模拟）
            orderNo = System.DateTime.Now.Year.ToString() + System.DateTime.Now.Month.ToString() + System.DateTime.Now.Day.ToString() + System.DateTime.Now.Hour.ToString() + System.DateTime.Now.Minute.ToString() + System.DateTime.Now.Second.ToString();
            //支付，具体参数含义参见海马的JAVA DOC
            jc.CallStatic("pay", this.gameObject.name, orderNo, "铜锣烧", "unity游戏", (float)0.01, "我得参数");
        }
        if (GUI.Button(new Rect(Screen.width / 3 - 75, Screen.height / 8 * 6 - 40, 150, 80), "打印日志"))
        {
            //开启海马SDK日志，具体参数含义参见海马的JAVA DOC
            jc.CallStatic("setLogEnable",true);
            message = "打印海马sdk日志";
        }
        if (GUI.Button(new Rect(Screen.width / 3 * 2 - 75, Screen.height / 8 * 6 - 40, 150, 80), "取消打印"))
        {
            //关闭海马SDK日志，具体参数含义参见海马的JAVA DOC
            jc.CallStatic("setLogEnable", false);
            message = "不打印海马sdk日志";
        }
		if (GUI.Button(new Rect(Screen.width / 3  - 75, Screen.height / 8 * 7 - 40, 150, 80), "检查更新"))
		{
            //检查更新，具体参数含义参见海马的JAVA DOC
			jc.CallStatic("checkUpdate",this.gameObject.name, true,3);
			message = "手动检查更新";
		}
	}

    //登录成功后的回调，具体参数含义参见海马的JAVA DOC
    void onLoginSuccess(string result)
    {
		List<string> resultList = SplitWithString(result, "$|.");
		//用户纯数字id标示
		string userId = resultList[0];
		//用户账号
		string userName = resultList[1];	
		// 此处游戏开发者可以直接访问游戏服务器获取玩家游戏资料，对于游戏账户安全要求高的也可以由游戏服务器将海马appid，登陆token以post形式发送给海马服务器进行登陆验证(需要将游戏服务器的ip告诉海马开发人员以便验证安全性)
		// 验证地址http://api.haimawan.com/index.php?m=api&a=validate_token
		string loginToken = resultList[2];
		message ="登录成功，用户名："+ userName+",用户id"+userId+",token"+loginToken;
    }

    //登录失败后的回调，具体参数含义参见海马的JAVA DOC
	void onLoginFailed(string result)
	{
        List<string> resultList = SplitWithString(result, "$|.");
        string errorCode = resultList[0];
        string errorMsg = resultList[1];	
		message = "登录失败，error："+errorCode+",errorMsg："+errorMsg;
	}

    //注销后的回调，具体参数含义参见海马的JAVA DOC
    void onLogOut(string errMsg)
    {
        message = "注销成功";
    }

    //支付成功后的回调，具体参数含义参见海马的JAVA DOC
	void onPaySuccess(string result)
	{
		List<string> resultList=SplitWithString(result,"$|.");
		string orderNo = resultList[0];
		string goodName = resultList[1];	
		string gameName = resultList[2];
        float money = float.Parse(resultList[3]);
        string userParam = resultList[4];
        message = "购买 "+goodName+" 成功";
        //message = orderNo + goodName + gameName + money + userParam;
	}

    //支付失败后的回调，具体参数含义参见海马的JAVA DOC
    void onPayFailed(string result)
    {
        List<string> resultList = SplitWithString(result, "$|.");
        string orderNo = resultList[0];
        string goodName = resultList[1];
        string gameName = resultList[2];
        float money = float.Parse(resultList[3]);
        string userParam = resultList[4];
        string errorCode = resultList[5];
        string errorMsg= resultList[6];
        message = "购买 " + goodName + " 失败！errorCode："+errorCode+",errorMsg："+errorMsg;
    }

    //查询订单状态成功后的回调，具体参数含义参见海马的JAVA DOC
    void onCheckOrderSuccess(string result)
    {
        List<string> resultList = SplitWithString(result, "$|.");
        //订单号
        string orderNo = resultList[0];
        //金额
        string money = resultList[1];
		//状态 0：未支付，1：已支付
        string status = resultList[2];
        message = "查询 " + orderNo + " 成功！金额："+money+",状态："+status;
    }

    //查询订单状态失败后的回调，具体参数含义参见海马的JAVA DOC
    void onCheckOrderFailed(string result)
    {
        List<string> resultList = SplitWithString(result, "$|.");
        //订单号
        string orderNo = resultList[0];
        //错误码
        string errorCode = resultList[1];
        //错误详情
        string errorMsg = resultList[2];
        message = "查询 " + orderNo + " 失败！errorCode：" + errorCode + ",errorMsg：" + errorMsg;
    }

    //检查更新成功后的回调，具体参数含义参见海马的JAVA DOC
	void onCheckUpdateSuccess(string result)
	{     
        List<string> resultList = SplitWithString(result, "$|.");
        string isNeedUpdate = resultList[0];
        string isForceUpdate = resultList[1];
        string isTestMode = resultList[2];
        message = "需要更新:" + isNeedUpdate + ",强制更新:" + isForceUpdate + ",测试模式:" + isTestMode;
        //此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //检查更新成功
        if (isForceUpdate.Equals("true")) {
            //强制更新
            //回调逻辑建议:如果是强制更新(且用户本地版本小于服务器版本，即用户必须更新)，用户必须更新CP的应用后，才可以进入CP的后续界面
            if (!isNeedUpdate.Equals("true")) {
                //用户无需更新
                //回调逻辑建议:用户不需要更新，可以直接进入CP的后续界面
            } else {
                //用户必须更新
                //回调逻辑建议:用户必须更新，当点击确认后，会自动打开浏览器进入下载
            }
        } else {
            //非强制更新
            if (isNeedUpdate.Equals("true")) {
                //用户需要更新
                //回调逻辑建议:如果是非强制更新，则允许用户选择确认更新或者取消
                //当用户点击确认后，会自动打开浏览器进入下载，点击取消则不会下载
            } else {
                //用户无需更新
            }
        }
	}

    //检查更新失败后的回调，具体参数含义参见海马的JAVA DOC
	void onCheckUpdateFailed(string result) 
	{
		List<string> resultList = SplitWithString(result, "$|.");
		//错误码
		string errorCode = resultList[0];
		//错误详情
		string errorMsg = resultList[1];
		//检查更新时填入的参数
		string ifErrorType = resultList[2];
		message = "检查更新失败！errorCode：" + errorCode + ",errorMsg：" + errorMsg;
        //此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //建议CP根据自己逻辑进行处理
	}

    //取消登录的回调，具体参数含义参见海马的JAVA DOC
    void onLoginCancel(string result){
        message = "login cancel";
    }

    //取消登录的回调，具体参数含义参见海马的JAVA DOC
    void onRegistCancel(string result){
        message = "regist cancel";
    }

    //取消支付的回调，具体参数含义参见海马的JAVA DOC
    void onPayCancel(){
        message = "pay cancel";
    }

	void OnDestroy(){
        //请一定移除注册的回调监听
        jc.CallStatic("removeLoginCancelListener");
        jc.CallStatic("removePayCancelListener");
        jc.CallStatic("removeRegistCancelListener");
        message = "OnDestroy";
    }

	void Update()
	{
		if (Input.GetKey(KeyCode.Escape))
		{
			Application.Quit();
		}
	}

    //字符串分割
	public List<string> SplitWithString(string sourceString, string splitString){
		
		List<string> arrayList = new List<string>();
		string s = string.Empty;
		while (sourceString.IndexOf(splitString) > -1)
		{
			s = sourceString.Substring(0, sourceString.IndexOf(splitString));
			sourceString = sourceString.Substring(sourceString.IndexOf(splitString) + splitString.Length);
			arrayList.Add(s);
		}
		arrayList.Add(sourceString);
		return arrayList;
	}

}
