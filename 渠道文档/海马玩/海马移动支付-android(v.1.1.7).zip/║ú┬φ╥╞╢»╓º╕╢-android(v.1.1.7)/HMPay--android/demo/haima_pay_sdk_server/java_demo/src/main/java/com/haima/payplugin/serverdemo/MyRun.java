package com.haima.payplugin.serverdemo;

import java.util.HashMap;
import java.util.Map;

/**
 * SDK登录验证的DEMO
 */
public class MyRun {

    /**
     * SDK服务器登录验证URL
     */
    private static final String POST_URL = "http://api.haimawan.com/index.php?m=api&a=validate_token";
    /**
     * 应用的APP ID
     */
    private static final String APP_ID = "海马玩联运后台分配给您应用的APP ID";
    /**
     * 登录验证的token
     */
    private static final String LOGIN_TOKEN = "客户端登录成功回调中的token字段";

    /**
     * 用户ID
     */
    private static final String UID = "用户CP ID，为cpd开头";

    public static void main(String[] args) throws Exception {
        Map<String, String> params = new HashMap<String, String>(3);
        params.put("appid", APP_ID);
        params.put("t", LOGIN_TOKEN);
        params.put("uid", UID);
        String result = HttpClientUtil.doPostHttpClient(POST_URL, null, params);
        //返回值情况
        //失败情况
        //1.请使用post方式发送appid和t两个参数
        //2.appid或token为空
        //3.请前往联运后台添加白名单ip

        //成功情况
        //success&用户的CP ID
        System.out.println("登录验证结果:" + result);
    }

}
