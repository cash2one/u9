<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 15/7/27
 * Time: 14:55
 */

/**
 * 获取当前毫秒
 */
function getMillisecond()
{
    list($t1, $t2) = explode(' ', microtime());
    return (float)sprintf('%.0f', (floatval($t1) + floatval($t2)) * 1000);
}

//登录验证服务器URL
$url = "http://api.haimawan.com/index.php?m=api&a=validate_token";
//登录验证POST的参数
$post_data = array(
    "appid" => "海马玩联运后台分配给您应用的APP ID",
    "t" => "客户端登录成功回调中的token字段",
    "uid" => '用户CP ID，为cpd开头');
$start_time = getMillisecond();
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 1);
$output = curl_exec($ch);
curl_close($ch);

//返回值情况
//失败情况
//1.请使用post方式发送appid和t两个参数
//2.appid或token为空
//3.请前往联运后台添加白名单ip

//成功情况
//success&用户的CP ID
print_r("执行时间" . (getMillisecond() - $start_time) . "ms,执行结果:" . $output);