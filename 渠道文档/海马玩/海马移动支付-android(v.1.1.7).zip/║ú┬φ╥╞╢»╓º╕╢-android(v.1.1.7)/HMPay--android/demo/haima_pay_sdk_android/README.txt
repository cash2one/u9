1.编译环境介绍
2.1 编译环境
项目采用google官方的gradle编译，请自行下载gradle(http://gradle.org/downloads/),demo全部在gradle2.2.1版本下编译，推荐下载此版本。

2.2 运行APK打包任务
下载并配置好gradle后，请在命令行运行gradle build进行apk的打包，出包地址在app/build/outputs/apk下

2.3 推荐的IDE（不必须）
如果需要把demo导入IDE中查看，我们推荐使用google官方推荐的Android Studio(https://developer.android.com/sdk/index.html)，对gradle支持非常好