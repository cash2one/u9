package com.hmpaysdkexample;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.haima.loginplugin.ZHErrorInfo;
import com.haima.loginplugin.ZHPayUserInfo;
import com.haima.loginplugin.callback.OnCheckUpdateListener;
import com.haima.loginplugin.callback.OnLoginCancelListener;
import com.haima.loginplugin.callback.OnLoginListener;
import com.haima.loginplugin.callback.OnRegistCancelListener;
import com.haima.payPlugin.callback.OnCheckOrderListener;
import com.haima.payPlugin.callback.OnPayCancelListener;
import com.haima.payPlugin.callback.OnPayListener;
import com.haima.payPlugin.infos.ZHPayOrderInfo;
import com.haima.plugin.haima.HMPay;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends Activity implements OnLoginListener,
        OnCheckOrderListener, OnPayListener, OnCheckUpdateListener,
        OnLoginCancelListener, OnPayCancelListener, OnRegistCancelListener {

    private SimpleAdapter adapter;
    private GridView gridview;
    /**
     * 显示sdk日志
     */
    private TextView tvSDKLog;
    /**
     * 订单号(CP)，长度保证在255之内
     */
    private String orderNum;
    /**
     * 模拟支付金额
     */
    private static final float MONEY = (float) 1.01;
    /**
     * 模拟支付商品
     */
    private static final String GOOD_NAME = "铜锣烧";
    /**
     * 模拟支付游戏名称
     */
    private static final String GAME_NAME = "大掌门";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        if (getIntent().getBooleanExtra("isLandscape", true)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            gridview.setNumColumns(5);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            gridview.setNumColumns(2);
        }
        gridview.setAdapter(adapter);
        gridview.setOnItemClickListener(new ItemClickListener());
        // 设置登录监听
        HMPay.setLoginListener(this);
        // 设置取消登录监听
        HMPay.setLoginCancelListener(this);
        // 设置取消注册监听
        HMPay.setRegistCancelListener(this);
        // 设置取消支付监听
        HMPay.setPayCancelListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        HMPay.onResume(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //移除登录的监听，请一定在销毁时移除
        HMPay.removeLoginListener(this);
        //移除取消登录的监听，请一定在销毁时移除
        HMPay.removeLoginCancelListener(this);
        //移除取消注册的监听，请一定在销毁时移除
        HMPay.removeRegistCancelListener(this);
        //移除取消支付的监听，请一定在销毁时移除
        HMPay.removePayCancelListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        HMPay.onPause();
    }

    private void initView() {
        gridview = (GridView) findViewById(R.id.gridview);
        tvSDKLog = (TextView) findViewById(R.id.tv_sdk_log);
    }

    private void initData() {
        ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();

        HashMap<String, Object> map1 = new HashMap<String, Object>();
        map1.put("ItemImage", R.drawable.example_loginin);
        map1.put("ItemText", "登录");
        lstImageItem.add(map1);

        HashMap<String, Object> map2 = new HashMap<String, Object>();
        map2.put("ItemImage", R.drawable.example_user_sign);
        map2.put("ItemText", "获取用户信息");
        lstImageItem.add(map2);

        HashMap<String, Object> map3 = new HashMap<String, Object>();
        map3.put("ItemImage", R.drawable.example_check_login);
        map3.put("ItemText", "是否已经登录");
        lstImageItem.add(map3);

        HashMap<String, Object> map4 = new HashMap<String, Object>();
        map4.put("ItemImage", R.drawable.example_loginout);
        map4.put("ItemText", "注销");
        lstImageItem.add(map4);

        HashMap<String, Object> map5 = new HashMap<String, Object>();
        map5.put("ItemImage", R.drawable.example_switch_account);
        map5.put("ItemText", "切换用户");
        lstImageItem.add(map5);

        HashMap<String, Object> map6 = new HashMap<String, Object>();
        map6.put("ItemImage", R.drawable.example_user_space);
        map6.put("ItemText", "个人中心");
        lstImageItem.add(map6);

        HashMap<String, Object> map7 = new HashMap<String, Object>();
        map7.put("ItemImage", R.drawable.example_search);
        map7.put("ItemText", "订单查询");
        lstImageItem.add(map7);

        HashMap<String, Object> map8 = new HashMap<String, Object>();
        map8.put("ItemImage", R.drawable.example_payment);
        map8.put("ItemText", "支付");
        lstImageItem.add(map8);

        HashMap<String, Object> map9 = new HashMap<String, Object>();
        map9.put("ItemImage", R.drawable.example_debug);
        map9.put("ItemText", "打印日志");
        lstImageItem.add(map9);

        HashMap<String, Object> map10 = new HashMap<String, Object>();
        map10.put("ItemImage", R.drawable.example_debug);
        map10.put("ItemText", "取消打印");
        lstImageItem.add(map10);

        adapter = new SimpleAdapter(this, lstImageItem, R.layout.grid_item,
                new String[]{"ItemImage", "ItemText"}, new int[]{
                R.id.ItemImage, R.id.ItemText});
    }

    @Override
    public void onRegistCancel() {
        tvSDKLog.setText("取消注册!");
    }

    @SuppressWarnings("unchecked")
    class ItemClickListener implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                long arg3) {
            HashMap<String, Object> item = (HashMap<String, Object>) arg0
                    .getItemAtPosition(arg2);
            setTitle((String) item.get("ItemText"));
            tvSDKLog.setText("");
            if (arg2 == 0) {
                // 登录
                HMPay.login(MainActivity.this, MainActivity.this);
            } else if (arg2 == 1) {
                // 获取登录的用户信息
                if (HMPay.getUserInfo() != null) {
                    tvSDKLog.setText(HMPay.getUserInfo().getUserName());
                } else {
                    tvSDKLog.setText("用户未登录");
                }
            } else if (arg2 == 2) {
                // 获取用户是否登录
                if (HMPay.isLogined())
                    tvSDKLog.setText("用户已登录");
                else
                    tvSDKLog.setText("用户未登录");
            } else if (arg2 == 3) {
                // 登出操作
                if (HMPay.logOut())
                    tvSDKLog.setText("用户已注销");
                else
                    tvSDKLog.setText("用户未登录");
            } else if (arg2 == 4) {
                // 切换用户
                if (!HMPay.isLogined())
                    tvSDKLog.setText("用户未登录");
                else
                    HMPay.switchAccount(MainActivity.this);
            } else if (arg2 == 5) {
                // 用户中心
                if (!HMPay.startUserCenter(MainActivity.this)) {
                    tvSDKLog.setText("用户未登录");
                }
            } else if (arg2 == 6) {
                // 查询订单
                HMPay.checkOrder(orderNum, MainActivity.this);
            } else if (arg2 == 7) {
                if (!HMPay.isLogined())
                    tvSDKLog.setText("用户未登录");
                else {
                    if (HttpGetUtil.isNetworkConnected(MainActivity.this)) {
                        //TODO 这里请CP自己调用自己服务器生成游戏订单号，这里使我们自己模拟的
                        orderNum = new GetRandomOrder().getOrder();
                        ZHPayOrderInfo orderInfo = new ZHPayOrderInfo();
                        // 商品名称
                        orderInfo.goodName = GOOD_NAME;
                        // 游戏名称
                        orderInfo.gameName = GAME_NAME;
                        // 商品价格
                        orderInfo.goodPrice = MONEY;
                        // 订单号
                        orderInfo.orderNo = orderNum;
                        orderInfo.userParam = "1002,10002,14525666555";
                        HMPay.pay(orderInfo, MainActivity.this, MainActivity.this);
                    } else {
                        Toast.makeText(MainActivity.this, "无网络连接", Toast.LENGTH_SHORT).show();
                    }
                }
            } else if (arg2 == 8) {
                HMPay.setLogEnable(true);
                tvSDKLog.setText("打印日志开启");
            } else if (arg2 == 9) {
                // 取消打印日志
                HMPay.setLogEnable(false);
                tvSDKLog.setText("打印日志关闭");
            } else if (arg2 == 10) {
                HMPay.checkUpdate(MainActivity.this, MainActivity.this, true,
                        HMPay.CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE);
            }
        }
    }

    @Override
    public void onLoginSuccess(ZHPayUserInfo payUserInfo) {
        tvSDKLog.setText("登录成功");
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 登录成功后对于游戏账户安全要求高的也可以做服务器的登录验证，详情请见文档
        //TODO POST appid和t参数到文档中的登录验证的URL进行验证
        //TODO appid是您申请的应用APP ID，t是登录成功后ZHPayUserInfo中的token参数
    }

    @Override
    public void onLoginFailed(ZHErrorInfo errorInfo) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 做自己服务器登录失败后的逻辑处理
        tvSDKLog.setText("登录失败：" + errorInfo.desc);
    }

    @Override
    public void onLogOut() {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 做自己服务器注销后的逻辑处理
        tvSDKLog.setText("用户已经注销");
    }

    @Override
    public void onCheckOrderFailed(String orderId, ZHErrorInfo errorInfo) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 做自己服务器的检查订单号失败后的逻辑处理
        tvSDKLog.setText(errorInfo.desc);
    }

    @Override
    public void onCheckOrderSuccess(String orderId, float money, int status) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 做自己服务器的检查订单号成功后的逻辑处理
        tvSDKLog.setText("查询订单'" + orderId + "'成功~" + " 金额：" + money + " 状态：" + status);
    }

    @Override
    public void onPaySuccess(ZHPayOrderInfo orderInfo) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 支付成功后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("购买 " + orderInfo.goodName + " 成功!");
    }

    @Override
    public void onPayFailed(ZHPayOrderInfo orderInfo, ZHErrorInfo errInfo) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 支付失败后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("购买 " + orderInfo.goodName + " 失败!" + errInfo.desc);
    }

    @Override
    public void onCheckUpdateSuccess(boolean isNeedUpdate, boolean isForceUpdate, boolean isTestMode) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 检查更新成功后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("检查更新成功");
    }

    @Override
    public void onCheckUpdateFailed(ZHErrorInfo errorInfo, int ifErrorType) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 检查更新失败后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("检查更新失败");
    }

    @Override
    public void onLoginCancel() {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 取消登录后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("取消登录");
    }

    @Override
    public void onPayCancel() {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 取消支付后的逻辑处理，可以做一些自己的逻辑
        tvSDKLog.setText("取消支付");
    }
}
