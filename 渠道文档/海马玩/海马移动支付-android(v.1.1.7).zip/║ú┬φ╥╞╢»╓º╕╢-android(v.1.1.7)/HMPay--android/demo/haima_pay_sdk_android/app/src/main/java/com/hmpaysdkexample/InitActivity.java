package com.hmpaysdkexample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.haima.loginplugin.ZHErrorInfo;
import com.haima.loginplugin.callback.OnCheckUpdateListener;
import com.haima.plugin.haima.HMPay;

public class InitActivity extends Activity implements OnClickListener, OnCheckUpdateListener {

    private Intent intent;
    public static final String APP_ID = "e5dc65b49905df4b3e618d7eac2117ea";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_init);
        Button btn_landscape = (Button) findViewById(R.id.btn_landscape);
        Button btn_portrait = (Button) findViewById(R.id.btn_portrait);
        btn_landscape.setOnClickListener(this);
        btn_portrait.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        // 下面的init方法传入的都是isTestMode=true，即测试模式，如果CP在isTestMode=true时
        // 有检查更新的弹框，即为加入了更新逻辑
        intent = new Intent(InitActivity.this, MainActivity.class);
        if (view.getId() == R.id.btn_landscape) {
            if (!HMPay.init(InitActivity.this, true, APP_ID, InitActivity.this,
                    false, HMPay.CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE)) {
                Toast.makeText(InitActivity.this, "初始化失败，参数不正确",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            intent.putExtra("isLandscape", true);
        } else if (view.getId() == R.id.btn_portrait) {
            // 下面的init方法，如果app id填null 则需要在manifest中配置HMKey，程序会自动用manifest中的HMKey
            if (!HMPay.init(InitActivity.this, false, null, InitActivity.this,
                    true, HMPay.CHECKUPDATE_FAILED_SHOW_CANCLEANDSURE)) {
                Toast.makeText(InitActivity.this, "初始化失败，参数不正确",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            intent.putExtra("isLandscape", false);
        }
    }

    @Override
    public void onCheckUpdateSuccess(boolean isNeedUpdate, boolean isForceUpdate, boolean isTestMode) {
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //检查更新成功
        if (isForceUpdate) {
            //强制更新
            //回调逻辑建议:如果是强制更新(且用户本地版本小于服务器版本，即用户必须更新)，用户必须更新CP的应用后，才可以进入CP的后续界面
            if (!isNeedUpdate) {
                //用户无需更新
                //回调逻辑建议:用户不需要更新，可以直接进入CP的后续界面
                startActivity(intent);
            } else {
                //用户必须更新
                //回调逻辑建议:用户必须更新，当点击确认后，会自动打开浏览器进入下载
            }
        } else {
            //非强制更新
            if (isNeedUpdate) {
                //用户需要更新
                //回调逻辑建议:如果是非强制更新，则允许用户选择确认更新或者取消
                //当用户点击确认后，会自动打开浏览器进入下载，点击取消则不会下载
            } else {
                //用户无需更新
            }
            //这里为了DEMO可以跑通，全都进入了DEMO主界面
            startActivity(intent);
        }
    }

    @Override
    public void onCheckUpdateFailed(ZHErrorInfo errorInfo, int ifErrorType) {
        //检查更新失败
        Toast.makeText(InitActivity.this, "检查更新失败", Toast.LENGTH_SHORT).show();
        //TODO 此回调在什么情况时发生，请参看海马SDK提供的JAVA DOC
        //TODO 这里DEMO为了跑通，不管什么情况都进入了DEMO的主界面，建议CP根据自己逻辑进行处理
        startActivity(intent);
    }

}