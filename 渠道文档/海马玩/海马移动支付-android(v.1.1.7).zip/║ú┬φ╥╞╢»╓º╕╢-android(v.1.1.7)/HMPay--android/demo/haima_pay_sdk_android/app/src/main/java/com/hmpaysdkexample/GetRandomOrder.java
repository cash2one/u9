package com.hmpaysdkexample;

import java.util.Calendar;
import java.util.Random;

public class GetRandomOrder {

    /**
     * 生成随机订单(demo用，订单请从游戏服务器生成获取)
     */
    public String getOrder() {
        Calendar ca = Calendar.getInstance();
        int year = ca.get(Calendar.YEAR);
        int month = ca.get(Calendar.MONTH) + 1;
        int day = ca.get(Calendar.DATE);
        int minute = ca.get(Calendar.MINUTE);
        int hour = ca.get(Calendar.HOUR_OF_DAY);
        int second = ca.get(Calendar.SECOND);
        return getRandomLetter() + getRandomLetter()
                + String.valueOf(year).substring(2, 4) + getString(month)
                + getString(day) + getString(hour) + getString(minute)
                + getString(second);
    }

    private String getRandomLetter() {
        Random r = new Random();
        String str = "abcdefjhigklmnopqrstuvwxyz";
        int num = r.nextInt(str.length());
        char c = str.charAt(num);
        return String.valueOf(c);
    }

    private String getString(int num) {
        String s = null;
        if (num < 10) {
            s = "0" + num;
        } else {
            s = String.valueOf(num);
        }
        return s;
    }
}
