package com.zhuoyou.pay.sdkclient;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zhuoyou.pay.sdk.ZYGameManager;
import com.zhuoyou.pay.sdk.account.UserInfo;
import com.zhuoyou.pay.sdk.entity.PayParams;
import com.zhuoyou.pay.sdk.listener.IZYLoginCheckListener;
import com.zhuoyou.pay.sdk.listener.ZYInitListener;
import com.zhuoyou.pay.sdk.listener.ZYRechargeListener;

public class MainActivity extends Activity implements OnClickListener {

	protected String password;
	private String shareInfo;
	private EditText count;
	protected boolean isNetworkAvailable;
	private int mCount = 1;
	private Button mBegin, mLoginCheckBtn, mPayBtn;
	private UserInfo mUserInfo = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		count = (EditText) findViewById(R.id.count);
		count.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (TextUtils.isEmpty(MainActivity.this.count.getText().toString())) {
					mCount = 1;
				} else {
					try {
						mCount = Integer.parseInt(MainActivity.this.count.getText().toString());
					} catch (Exception e) {
						mCount = 1;
						MainActivity.this.count.setText("1");
					}
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
		mPayBtn = (Button) findViewById(R.id.recharge);
		mPayBtn.setOnClickListener(this);
		mBegin = (Button) findViewById(R.id.begin);
		mBegin.setOnClickListener(this);
		mLoginCheckBtn = (Button) findViewById(R.id.longin_check);
		mLoginCheckBtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {

		case R.id.recharge:
			startRechargeActivity();
			break;

		case R.id.begin:
			ZYGameManager.init(this, new ZYInitListener() {

				@Override
				public void iniSuccess(UserInfo userInfo) {
					Toast.makeText(
							getApplicationContext(),
							"初始化成功 : \n id :" + userInfo.getOpenId() + "\n nickName :" + userInfo.getNickName()
									+ "\n accessToken :" + userInfo.getAccessToken(), Toast.LENGTH_SHORT).show();
					mBegin.setVisibility(View.INVISIBLE);
					userInfo.getOpenId();
					mUserInfo = userInfo;
				}

				@Override
				public void iniFail(String msg) {
					Toast.makeText(MainActivity.this, "初始化失败 " + msg, 1000).show();
				}

				@Override
				public void accountLogout() {
					Toast.makeText(MainActivity.this, "帐号已登出，游戏回到主界面！！！！", 1000).show();
					mBegin.setVisibility(View.VISIBLE);
					mLoginCheckBtn.setVisibility(View.VISIBLE);
				}
			});
			break;

		case R.id.longin_check:
			if (null != mUserInfo) {
				ZYGameManager.loginCheck(MainActivity.this, mUserInfo.getOpenId(), mUserInfo.getAccessToken(),
						new IZYLoginCheckListener() {

							@Override
							public void checkResult(String code, String message) {
								Toast.makeText(MainActivity.this,
										"登录验证结果 code ： " + code + " ,\n Message : " + message, 1000).show();
								if (code.equals("0")) {
									// 登录验证通过，进入游戏。。。。。
									mLoginCheckBtn.setVisibility(View.GONE);
									mPayBtn.setVisibility(View.VISIBLE);
								}
							}
						});
			} else {
				Toast.makeText(MainActivity.this, "请先初始化登录  ！！！", 1000).show();
			}

			break;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		initViews();
	}

	private void initViews() {
		if (!TextUtils.isEmpty(shareInfo)) {
			Toast.makeText(getApplicationContext(), shareInfo, Toast.LENGTH_SHORT).show();
		}
	}

	private void startRechargeActivity() {
		PayParams params = new PayParams();
		params.setAmount(mCount);
		params.setPropsName("Q币");
		params.setOrderId("00001");
		params.setExtraParam("extra");

		ZYGameManager.pay(params, MainActivity.this, new ZYRechargeListener() {

			@Override
			public void success(PayParams params, String zyOrderId) {
				Toast.makeText(MainActivity.this, "QAQ支付成功 - " + zyOrderId, 1).show();
			}

			@Override
			public void fail(PayParams params, String erroMsg) {
				Toast.makeText(MainActivity.this, "QAQ支付失败" + erroMsg, 1).show();

			}

		});

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		ZYGameManager.onConfigurationChanged(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		ZYGameManager.onDestroy(this);
	}

}
