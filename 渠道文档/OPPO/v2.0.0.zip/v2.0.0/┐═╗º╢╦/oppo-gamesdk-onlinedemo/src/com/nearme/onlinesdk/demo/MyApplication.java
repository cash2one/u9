package com.nearme.onlinesdk.demo;

import com.nearme.game.sdk.GameCenterSDK;
import com.nearme.game.sdk.common.model.biz.GameCenterSettings;
import com.nearme.game.sdk.common.util.AppUtil;

import android.app.Application;

public class MyApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		// 因为sdk插件中service activity跑在独立进程，这里只需要在主进程做一次初始化操作。
		if (getApplicationInfo().packageName.equals(AppUtil
				.getCurrentProcessName(this))) {
			String appKey = "c5217trjnrmU6gO5jG8VvUFU0";
			String appSecret = "e2eCa732422245E8891F6555e999878B";
			GameCenterSettings gameCenterSettings = new GameCenterSettings(
					false, // 网游固定为false
					appKey, appSecret, true, // 调试开关 true 打印log，false
												// 关闭log，正式上线请设置为false
					false); // 将游戏横竖屏状态传递给sdk， true为竖屏 false为横屏
			GameCenterSDK.init(gameCenterSettings, this);
		}
	}
}
