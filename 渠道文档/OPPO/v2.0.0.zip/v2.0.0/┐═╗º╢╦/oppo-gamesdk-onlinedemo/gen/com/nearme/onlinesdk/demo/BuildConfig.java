/** Automatically generated file. DO NOT MODIFY */
package com.nearme.onlinesdk.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}