package com.example.tester;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import sy07073.mobile.game.sdk.SDKCallBack;
import sy07073.mobile.game.sdk.SY07073API;
import sy07073.mobile.game.sdk.lib.view.FloatWindow;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ShowToast")
public class MainActivity extends Activity {
	private Activity activity;
	private boolean  isInit = false;
	private String username="";
	private String token="";

	@SuppressLint("ShowToast")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		activity=this;
		Button initBtn=(Button)findViewById(R.id.initbtn);	
		Button loginbtn=(Button)findViewById(R.id.loginbtn);
		Button payBtn = (Button)findViewById(R.id.bt_pay);
		Button switchBtn	= (Button)findViewById(R.id.bt_switch);
		Button logoutBtn = (Button)findViewById(R.id.bt_logout);
		final TextView tvWelcome = (TextView)findViewById(R.id.tv_welcome);
		final EditText etPayTotal =(EditText)findViewById(R.id.et_payTotal);
		
		
	//��ʼ��
		initBtn.setOnClickListener(new OnClickListener(){
			@SuppressLint("ShowToast")
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(isInit){
					Toast.makeText(activity, "�Ѿ���ʼ����", 0).show();
					return;
				}	
				SY07073API.getInstance().init(activity,125,115,new SDKCallBack(){
					@Override
					public void callback(String param) {
						// TODO Auto-generated method stub
						Toast.makeText(activity, param, Toast.LENGTH_LONG).show();
						try {
							JSONObject jsonObject = new JSONObject(param);
							int code	= jsonObject.getInt("state");
							String msg = jsonObject.getString("msg");	    
			        		if(code == 1){ //�ɹ�
			        			isInit = true;
			        			
			    				if(username.length()>=6 && token.length()>0){
			    					tvWelcome.setText("Welcome,"+username);
			    				}
			    				
			        			Toast.makeText(activity, "��ʼ���ɹ�", 0).show();
			        		}else{ // ʧ��
			        			Toast.makeText(activity, msg, 0).show();
			        		}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							Toast.makeText(activity, "��ʼ��ʧ��", 0).show();
							
						} 	    
					}										
				});
				
			}
			
		});
		
		
	//��¼
		loginbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub	
				if(isInit){			
					if(username.length()>=6 && token.length()>0){
						Toast.makeText(activity, "�Ѿ���½�ɹ���"+username, 0).show();
						return;
					}
					SY07073API.getInstance().login(activity, new SDKCallBack(){
						@SuppressLint("ShowToast")
						@Override
						public void callback(String s) {
							//Toast.makeText(activity, s, 0).show();
							try{
								JSONObject jsonObject = new JSONObject(s);
								int code	= jsonObject.getInt("state");
								String msg = jsonObject.getString("msg");				 		    
				        		if(code == 1){ //�ɹ�
				        			JSONObject returnData = jsonObject.getJSONObject("data");
					        		String s_username = returnData.getString("username");
					        		String s_token = returnData.getString("token");	
				        			//Editor editor = sp.edit();  
				        	        //editor.putString("username", username);
				        	        username= s_username;
				        	        //editor.putString("token", token);
				        	        //editor.commit(); 
				        	        token= s_token;
				        	        tvWelcome.setText("Welcome,"+username);			        	    
				        		}else{ // ʧ��
				        			Toast.makeText(activity, msg, 0).show();
				        		}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								Toast.makeText(activity, "��¼ʧ�ܣ������ԣ�", 0).show();
							} 	    
						}
					});									
				}else{
					Toast.makeText(activity, "���ȳ�ʼ����", 0).show();
				}										
			}
		});
		
		//֧��
		payBtn.setOnClickListener(new OnClickListener() {
			@SuppressLint("WorldReadableFiles")
			@Override
			public void onClick(View v) {
				if(username ==null || username.length() <= 0){
					Toast.makeText(activity, "���ȵ�¼", 0).show();
					return;
				}
				float payTotal;
				try{
					payTotal = Float.parseFloat(etPayTotal.getText().toString());
				}catch(Exception e){
					e.printStackTrace();
					payTotal = 0;
				}
				if(payTotal <= 0){
					Toast.makeText(activity, "����д���", 0).show();
					return;
				}
				// TODO Auto-generated method stub						
				try {
					SY07073API.getInstance().pay(activity,new SDKCallBack(){
						@Override
						public void callback(String param) {
							// TODO Auto-generated method stub
							Toast.makeText(activity, "The result:"+param, Toast.LENGTH_LONG).show();
						}
					},username,token,2,payTotal,URLEncoder.encode("311_1797|����|shu-you", "utf-8"));
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
								
			}
		});
		
		switchBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(username ==null || username.length() <= 0){
					Toast.makeText(activity, "δ��¼���޷��л��˺�", 0).show();
					return;
				}
				username="";
				token="";
				tvWelcome.setText("δ��¼");
				SY07073API.getInstance().switchAccount(activity, new SDKCallBack(){
					@Override
					public void callback(String param) {
						// TODO Auto-generated method stub
						//Toast.makeText(activity, param, 0).show();
						try {
							JSONObject jsonObject = new JSONObject(param);
							int code	= jsonObject.getInt("state");
							String msg = jsonObject.getString("msg");			    		    
			        		if(code == 1){ //�ɹ�
			        			JSONObject returnData = jsonObject.getJSONObject("data");
				        		String s_username = returnData.getString("username");
				        		String s_token = returnData.getString("token");	
			        			username= s_username;
			        	        token= s_token;
			        	        tvWelcome.setText("Welcome,"+username);	
			        		}else{ // ʧ��
			        			Toast.makeText(activity, msg, 0).show();
			        		}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							Toast.makeText(activity, "��¼ʧ�ܣ������ԣ�", 0).show();
						} 	    
					}}, username, token);
			   }			
		});
		
		logoutBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SY07073API.getInstance().exitSDK(activity, new SDKCallBack(){
					@Override
					public void callback(String s) {
						// TODO Auto-generated method stub
						Toast.makeText(activity, s, 0).show();
						if(s.equals("CY_EXIT")){
							//System.exit(0);
							//FloatWindow.getInstance(activity).destroy();														
							//LoadPage.activity.finish();
							clearStatus();
							activity.finish();
							//System.exit(0);
						}else if(s.equals("CY_CONTINUE")){
							//
						}else{
							
						}
					}});
			}});		
	}
	
	
	
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {  
        if (keyCode == KeyEvent.KEYCODE_BACK) {  
        	//SY07073API.getInstance().destroy(activity);
			//System.exit(0);
        	SY07073API.getInstance().exitSDK(activity, new SDKCallBack(){
				@Override
				public void callback(String s) {
					// TODO Auto-generated method stub
					//Toast.makeText(activity, s, 0).show();
					if(s.equals("CY_EXIT")){
						clearStatus();
						activity.finish();
						//System.exit(0);
					}
				}});
        }
		return false;
    }
    
	private void clearStatus(){
		isInit = false;
		username="";
		token="";
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		FloatWindow.getInstance(activity.getApplicationContext()).hide();	
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		FloatWindow.getInstance(activity.getApplicationContext()).show();
	}

}
