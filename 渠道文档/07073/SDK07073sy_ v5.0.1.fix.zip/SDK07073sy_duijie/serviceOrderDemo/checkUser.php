<?php
	$key = '';
	$data['pid'] = '';
	$data['username'] = '';
	$data['token'] = '';
	ksort($data);
	$data['sign'] = md5(http_build_query($data).$key);
	$url = "http://sdk.07073sy.com/index.php/User/v4";
	$result = gethttpcurl($url,array('postarr'=>$data));
	exit($result);




	function gethttpcurl($url, $ntarr = null){ 
		$header = array('User-Agent: Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1)'); 
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_TIMEOUT, (isset($ntarr['timeout']) && is_numeric($ntarr['timeout']))?$ntarr['timeout']:10);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if(is_array($ntarr['postarr'])){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $ntarr['postarr']);
		}
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$s = curl_exec($ch);
		curl_close($ch);
		return $s;
	}
	
?>