<?php
	$key	= ''; //联运方提供key
	$data = $_POST['data'];
	if(!$data) 
		exit('fail');
	//将json数据解析为数组
	$data	= json_decode($data,TRUE);
	//提取签名数据
	$sign	= $data['sign'];
	//提取扩展信息
	$extendsInfo = $data['extendsInfo'];
	//去掉不参与签名的元素
	unset($data['sign']);
	unset($data['extendsInfo']);
	//数组排序
	ksort($data);
	//验证签名
	if($sign != md5(http_build_query($data).$key)){
		//签名失败
		exit('fail'); 
	}
	//游戏方验证逻辑。。符合发放元宝返回succ，不符合返回fail
	
?>