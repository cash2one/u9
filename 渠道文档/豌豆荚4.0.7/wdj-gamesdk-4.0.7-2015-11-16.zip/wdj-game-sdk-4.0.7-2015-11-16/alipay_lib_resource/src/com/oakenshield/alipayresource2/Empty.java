package com.oakenshield.alipayresource2;

/**
 * 
 */

public class Empty {

}
