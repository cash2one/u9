jQuery.noConflict();
jQuery(function(){

    jQuery('.search-box input').focus(function(){
        var self = jQuery(this),
            input_tips = self.attr('input_tips'),
            key_word = self.val();

        if ( input_tips ==  key_word){
            self.val('');
        }

    }).blur(function(){
        var self = jQuery(this),
            input_tips = self.attr('input_tips'),
            key_word = self.val();

        if ( key_word == ''){
            self.val(input_tips);
        }
    });

    var suggestion_wp;
    // search keyword suggestion
    jQuery('#scform_srchtxt,#scbar_txt').bind('focus change keyup',function(e){
        var self = jQuery(this),
            parent = self.parent(),
            key_word = self.val(),
            get_data = function(callback){
                jQuery.getJSON(
                    'http://suggest2.wandoujia.com/search_sug?key='+key_word+'&cb=?',
                    null,
                    function(data){

                        var wl = data['wl'],
                            html = [];

                        for ( var i = 0 ; i < wl.length; i++ ){
                            html.push('<li>'+ wl[i] +'</li>');
                        }


                        callback && callback(html.join(''));

                    }
                );
            }


        var suggestion_list = parent.find('.suggestion-list');
        suggestion_wp = suggestion_list.parent();

        var call_back = function(html){
            suggestion_list.html(html);
            suggestion_wp.show();


            suggestion_list.find('li').bind('mouseover',function(e){
                suggestion_list.find('li').removeClass('current');
                jQuery(this).addClass('current');
            }).bind('click',function(e){
                var li = jQuery(this),
                    val = li.text();

                val.replace('<em>','').replace('</em>','');
                self.val(val);
                
                var _czc = window._czc || [];
                _czc.push(["_setAccount", "1000074060"]);
                if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                    _czc.push(["_trackEvent",'搜索按钮','PC']);
                } else {
                	_czc.push(["_trackEvent",'搜索按钮','Browser']);
                }
                
                self.closest('form').submit();
            });
        };

        if (jQuery.trim(key_word).length > 0 ){
            get_data(call_back);
        }

        jQuery('body').live('click',function(e){
            if ( (jQuery(e.target).attr('id') != 'scform_srchtxt' && jQuery(e.target).attr('id') != 'scbar_txt' ) && jQuery(e.target).attr('class') != 'suggestion-wp' && !jQuery(e.target).closest('.suggestion-list').length ){
                suggestion_wp.hide();
            }
        });

    });




    jQuery('#quick_sch').click(function(e){
        jQuery('#quick_sch_menu').show();

        jQuery('body').on('click',function(e){
            if ( !jQuery(e.target).closest('#quick_sch_menu').length && jQuery(e.target).attr('id')!='quick_sch'){
                jQuery('#quick_sch_menu').hide();
            }
        });

    });
    window.appsDownload = function(packageName){
    	var _czc = window._czc || [];
        _czc.push(["_setAccount", "1000074060"]);
        if(!!window.campaignPlugin) {
    		//P4
        	_czc.push(["_trackEvent", '搜索下载按钮p4', packageName]);
    		window.campaignPlugin.openAppDetail(packageName);
    	}else{
    		if((window.OneRingRequest !== undefined)&&(window.OneRingStreaming !== undefined)){
    			//PC client
    			_czc.push(["_trackEvent", '搜索下载按钮PC', packageName]);
    			window.location.href='http://apps.wandoujia.com/apps/'+packageName;
    		}else{
    			//Web Browser
    			_czc.push(["_trackEvent", '搜索下载按钮Browser', packageName]);
    			window.open('http://www.wandoujia.com/apps/'+packageName);
    		}
    	}
        return false;
    }

    jQuery("#scform_submit").click(function(){
    	var _czc = window._czc || [];
        _czc.push(["_setAccount", "1000074060"]);
        if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
            _czc.push(["_trackEvent",'搜索按钮','PC']);
        } else {
        	_czc.push(["_trackEvent",'搜索按钮','Browser']);
        }
    });


    var new_popup_cookie = document.cookie;
    console.log(new_popup_cookie.indexOf('wdj_new_popup') < 0);
    if ( new_popup_cookie && new_popup_cookie.indexOf('wdj_new_popup') < 0 ){

        jQuery('.new_popup').show();
        jQuery('.new_popup .close').click(function(e){

            jQuery(this).parent().hide();
            document.cookie = "wdj_new_popup=1";

        });
    }



});

