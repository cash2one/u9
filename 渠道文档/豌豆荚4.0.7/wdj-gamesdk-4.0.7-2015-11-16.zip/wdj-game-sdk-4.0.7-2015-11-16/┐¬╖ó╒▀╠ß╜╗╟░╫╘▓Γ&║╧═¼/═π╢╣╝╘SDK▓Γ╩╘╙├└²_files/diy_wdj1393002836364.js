jQuery.noConflict();
(function($) {
    if (window['WDJ'] && window['WDJ']['isunreadnum']) {
        $('#header-profile-nav_menu li').each(function(idx, item) {
            if ($(item).find('a').text() === '消息') {
                $(item).css('position', 'relative');
                $(item).append($('<em>').text(WDJ['unread-num'] + '条未读').addClass('unread-num'));
            }
        });
    }
    $(document).ready(function() {
        if (!((location.href.indexOf('forum-') > -1) || (location.href.indexOf('thread-') > -1))) {
            $('#newspecial').attr('onclick', "showWindow('nav', 'forum.php?mod=misc&action=nav', 'get', 0)");
        }
        if (window.location.pathname == '/') {
            jQuery('#nv ul').find('li.a').removeClass('a').end().find('li:first').addClass('a');
        }

        $('img').error(function() {
            $(this).unbind("error").attr("src", "http://bbs.wandoujia.com/template/week_mfxl006/wdj/brokenimg.jpg");
        });
        // inject scroll for pager
        jQuery('#pgt a').attr('ajaxfunc', "index_list_scroll('#threadlist', '50')");
        jQuery('ignore_js_op').prev('ignore_js_op:not("ignore_js_op +ignore_js_op")').css('display', 'inline');
    });

    // new_element..appendTo('.your_div').fadeIn(); $(window).scrollTop($(window).scrollTop()-1);
})(jQuery);

// new-index script here
(function($) {
    function elementInViewport2(el) {
        var top = el.offsetTop;
        var left = el.offsetLeft;
        var width = el.offsetWidth;
        var height = el.offsetHeight;

        while (el.offsetParent) {
            el = el.offsetParent;
            top += el.offsetTop;
            left += el.offsetLeft;
        }

        return (
            top < (window.pageYOffset + window.innerHeight) &&
            left < (window.pageXOffset + window.innerWidth) &&
            (top + height) > window.pageYOffset &&
            (left + width) > window.pageXOffset
        );
    }
    jQuery('.idx-sbar').parent('.wp').css('position', 'relative');

    if (jQuery('.idx-loading').length == 0) {
        return;
    } else {
        var s = document.createElement('p').style;
        var supportsTransitions = 'transition' in s ||
            'WebkitTransition' in s ||
            'MozTransition' in s ||
            'msTransition' in s ||
            'OTransition' in s;

        if (!supportsTransitions) {
            $('.w-ui-loading-horizental-ctn').hide();
            $('.idx-loading').show();
        }

        window['AJAX_NEXTING'] = false;
        window['AJAX_NOPAGE'] = false;
        $('.w-ui-loading-horizental-ctn').fadeOut();
        window['AJAX_PAGE'] = 1;

        function loadMoreArticle(e) {
            if (!window['AJAX_NEXTING'] && !window['AJAX_NOPAGE']) {
                window['AJAX_NEXTING'] = true
                $('.w-ui-loading-horizental-ctn').fadeIn();
                loadnextpage();
                e.preventDefault();
            }
        }

        function loadMoreScrollHandler(e) {
            if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                loadMoreArticle(e);
            }
        }
        $(window).on('scroll', loadMoreScrollHandler);

        $('#loading-more').click(function(e) {
            loadMoreArticle(e);
        });

        $('li.article, .bbs-panel').live({
            mouseenter: function() {
                $(this).addClass('hover');
            },
            mouseleave: function() {
                $(this).removeClass('hover');
            }
        });

        function loadnextpage() {
            window['AJAX_PAGE'] += 1;
            // inajax=1&page=xxx&count=xxxxx, ,{dataType: "xml"}
            jQuery.ajax('http://bbs.wandoujia.com/index.php?inajax=1&page=' + window['AJAX_PAGE'] + '&count=' + window['IDXITEMCOUNT']).done(function(resp) {
                if (resp) {
                    jQuery(jQuery(resp).find('root').text()).hide().appendTo(jQuery('.idx-articlelist')).fadeIn('slow');
                    // $(window).scrollTop($(window).scrollTop()-1);
                    $('.w-ui-loading-horizental-ctn').fadeOut();
                } else {
                    window['AJAX_NOPAGE'] = true;
                    $('.w-ui-loading-horizental-ctn').fadeOut();
                    $('.idx-loading').hide();
                    $('#loading-none').fadeIn();
                    $('#loading-more').hide();
                }
                window['AJAX_NEXTING'] = false;
                if (window['AJAX_PAGE'] === 3) {
                    $(window).off('scroll', loadMoreScrollHandler);
                    $('#loading-more').show();
                }
            });
        }

        // idx-sidebar-tnew fix scroll
        //如侧边栏的一个panel，需要当left main足够下的时候，也能fix在侧栏。

        SidebarFollow = function() {

            this.config = {
                element: null, // 处理的节点
                distanceToTop: 0 // 节点上边到页面顶部的距离
            };

            this.cache = {
                originalToTop: 0, // 原本到页面顶部的距离
                prevElement: null, // 上一个节点
                parentToTop: 0, // 父节点的上边到顶部距离
                placeholder: jQuery('<div>') // 占位节点
            }
        };

        SidebarFollow.prototype = {

            init: function(config) {
                this.config = config || this.config;
                var _self = this;
                var element = jQuery(_self.config.element);

                // 如果没有找到节点, 不进行处理
                if (element.length <= 0) {
                    return;
                }

                // 获取上一个节点
                var prevElement = element.prev();
                while (prevElement.is(':hidden')) {
                    prevElement = prevElement.prev();
                    if (prevElement.length <= 0) {
                        break;
                    }
                }
                _self.cache.prevElement = prevElement;

                // 计算父节点的上边到顶部距离
                var parent = element.parent();
                var parentToTop = parent.offset().top;
                var parentBorderTop = parent.css('border-top');
                var parentPaddingTop = parent.css('padding-top');
                _self.cache.parentToTop = parentToTop + parentBorderTop + parentPaddingTop;

                // 滚动屏幕
                jQuery(window).scroll(function() {
                    _self._scrollScreen({
                        element: element,
                        _self: _self
                    });
                });

                // 改变屏幕尺寸
                jQuery(window).resize(function() {
                    _self._scrollScreen({
                        element: element,
                        _self: _self
                    });
                });
            },

            /**
             * 修改节点位置
             */
            _scrollScreen: function(args) {
                var _self = args._self;
                var element = args.element;
                var prevElement = _self.cache.prevElement;

                // 获得到顶部的距离
                var toTop = _self.config.distanceToTop;

                // 如果 body 有 top 属性, 消除这些位移
                var bodyToTop = parseInt(jQuery('body').css('top'), 10);
                if (!isNaN(bodyToTop)) {
                    toTop += bodyToTop;
                }

                // 获得到顶部的绝对距离
                var elementToTop = element.offset().top - toTop;

                // 如果存在上一个节点, 获得到上一个节点的距离; 否则计算到父节点顶部的距离
                var referenceToTop = 0;
                if (prevElement && prevElement.length === 1) {
                    referenceToTop = prevElement.offset().top + prevElement.outerHeight();
                } else {
                    referenceToTop = _self.cache.parentToTop - toTop;
                }

                // 当节点进入跟随区域, 跟随滚动
                if (jQuery(document).scrollTop() > elementToTop) {
                    // 添加占位节点
                    var elementHeight = element.outerHeight();
                    _self.cache.placeholder.css('height', elementHeight).insertBefore(element);
                    // 记录原位置
                    _self.cache.originalToTop = elementToTop;
                    // 修改样式
                    element.css({
                        top: toTop + 'px',
                        position: 'fixed',
                        width: '280px',
                        zIndex: '100'
                    });

                    // fix
                    if (elementInViewport2(jQuery('.footer')[0])) {
                        element.css({
                            position: 'absolute',
                            bottom: '10px'
                        })
                    }

                    // 否则回到原位
                } else if (_self.cache.originalToTop > elementToTop || referenceToTop > elementToTop) {
                    _self.cache.placeholder.remove(); // 删除占位节点
                    // 修改样式
                    element.css({
                        position: 'static'
                    });
                }
            }
        };
        // (new SidebarFollow()).init({
        //     element: jQuery('.idx-sidebar-tnew'),
        //     distanceToTop: 55
        // });
    }

})(jQuery);

/*
new forum list script here
 */
(function($) {
    // script for findex page
    if (jQuery('.flist-category').length == 0) {
        return;
    } else {
        $(function() {
            // hack for last bottom border
            $('.flist-item-long:last').css('border-bottom', 'none');

            $('.flist-category-header .collapse').toggle(function() {
                $(this).parents('.flist-category').find('.flist-category-body').stop(false, true).slideUp('slow');
                $(this).removeClass('icon-chevron-down').addClass('icon-chevron-up');
            }, function() {
                $(this).parents('.flist-category').find('.flist-category-body').stop(false, true).slideDown('slow');
                $(this).removeClass('icon-chevron-up').addClass('icon-chevron-down');
            });
            $('.flist-item-short, .flist-item-long').hover(function() {
                $(this).addClass('hover');
            }, function() {
                $(this).removeClass('hover');
            });
            $('.flist-item-short, .flist-item-long').click(function() {
                // $(this).find('h3 a').attr('href')
                window.location.href = $(this).find('h3 a').attr('href');
            });
        })
    }
})(jQuery);

(function($) {
    if ($('.carousel-discuz').length == 0) {
        return;
    } else {
        $(function($) {
            $('.pg_index #nv #newspecial').attr('onclick', "showWindow('nav', 'forum.php?mod=misc&action=nav', 'get', 0)");
            //$that uses jQuery's $ can follow here.
            $(".carousel-discuz").carousel({
                itemContainer: $(".carousel-items"),
                nextBtn: ".carousel-discuz .prev",
                prevBtn: ".carousel-discuz .next",
                btnNav: 1,
                repeat: 1,
                useNav: 1,
                delayTime: 3000,
                customChange: opacityChange,
                customInit: opacityInit
            }).on("mouseenter", function() {
                $(this).addClass("active")
            }).on("mouseleave", function() {
                $(this).removeClass("active")
            });
            $(".carousel-discuz").animate({
                'opacity': 1
            })
        });
    }
})(jQuery);