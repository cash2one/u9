var docCookies = {
    getItem: function(sKey) {
        return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
    },
    setItem: function(sKey, sValue, vEnd, sPath, sDomain, bSecure) {
        if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
            return false;
        }
        var sExpires = "";
        if (vEnd) {
            switch (vEnd.constructor) {
                case Number:
                    sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                    break;
                case String:
                    sExpires = "; expires=" + vEnd;
                    break;
                case Date:
                    sExpires = "; expires=" + vEnd.toUTCString();
                    break;
            }
        }
        document.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
        return true;
    },
    removeItem: function(sKey, sPath, sDomain) {
        if (!sKey || !this.hasItem(sKey)) {
            returnfalse;
        }
        document.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "");
        return true;
    },
    hasItem: function(sKey) {
        return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
    },
    keys: /* optional method: you can safely remove it! */ function() {
        var aKeys = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
        for (var nIdx = 0; nIdx < aKeys.length; nIdx++) {
            aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]);
        }
        return aKeys;
    }
};
(function($) {
    $(function() {
        var _signup_pop_fetched = false;

        $('#signup-popup').click(function() {
            var _czc = window._czc || [];
            _czc.push(["_trackEvent", "头部", "签到按钮"]);
            if (!_signup_pop_fetched) {
                $.get('/plugin.php?id=mpage_sign:sign&sign=1').then(function(resp) {
                    $('#signup-popup_menu').html(resp);
                    _signup_pop_fetched = true;
                    showMenu({
                        'ctrlid': 'signup-popup',
                        'pos': '34'
                    });
                });
            } else {
                showMenu({
                    'ctrlid': 'signup-popup',
                    'pos': '34'
                });
            }
            return false;
        });
        $.get('/home.php?mod=newpmapi').then(function(resp) {
            $('#notice-popup_menu').html(resp);
            if ($('.notice-popup').data('unread-count')) {
                $('#header-notice-unread-count').html($('.notice-popup').data('unread-count'));
                $('#header-notice-unread-count').show();
            }
            $('.notice-name-list').on('click', 'li', function(e) {
                var idx = $('.notice-name-list li').index(this);
                var unread_count = $(this).data('unread');
                var current_type = $(this).data('type');
                if (unread_count) {
                    if (current_type === 'system') {
                        $.get('/home.php?mod=finishnewpm&category=system').then(function() {
                            $(this).data('unread', 0);
                        });
                    } else if (current_type === 'thread') {
                        $.get('/home.php?mod=finishnewpm&category=post').then(function() {
                            $(this).data('unread', 0);
                        });
                    } else if (current_type === 'pm') {
                        $.get('/home.php?mod=finishnewpm&category=message&plids=' + $(this).parents('.notice-popup').find('.notice-content-pm ul').data('plids')).then(function() {
                            $(this).data('unread', 0);
                        });
                    }
                    var unread_count_total = $('.notice-popup').data('unread-count') - unread_count;
                    if (unread_count_total > 0) {
                        if (unread_count_total > 99) {
                            $('.notice-popup').data('unread-count', '99+');
                        } else {
                            $('.notice-popup').data('unread-count', unread_count_total);
                        }
                        $('#header-notice-unread-count').html($('.notice-popup').data('unread-count'));
                    } else {
                        $('.notice-popup').data('unread-count', 0);
                        $('#header-notice-unread-count').html('');
                        $('#header-notice-unread-count').hide();
                    }

                }
                $('.notice-content-list .notice-content-block').removeClass('active').eq(idx).addClass('active');
                $('.notice-name-list li').removeClass('active').eq(idx).addClass('active');
            });
        });

        $('#notice-popup').click(function() {
            var _czc = window._czc || [];
            _czc.push(["_trackEvent", "头部", "消息按钮"]);
            showMenu({
                'ctrlid': 'notice-popup',
                'pos': '34',
                'timeout': 5000
            });
            var _firstUnReadTypeItem = $('.notice-name-list li').filter(function(idx, item) {
                return $(item).data('unread') != 0;
            });
            if (_firstUnReadTypeItem.length == '0') {
                _firstUnReadTypeItem = $('.notice-name-list li').eq(0);
            }
            if (_firstUnReadTypeItem.length) {
                _firstUnReadTypeItem = _firstUnReadTypeItem[0];
            }
            _firstUnReadTypeItem.click();
            return false;
        });

        $('body').click(function() {
            $('#notice-popup_menu').hide();
        });


        // showPrompt(null, 'diy', '<i>您之前没有参与预订活动，不能领取激活码~</i>', 2 * 1000, 'popuptext');
        jQuery('.post-action-like').click(function() {
            var type = $(this).data('type');
            var $elem = $(this);
            var likeCount = $(this).data('likenum');
            var _czc = window._czc || [];
            _czc.push(["_setAccount", "1000074060"]);
            toggleLike();
            processCopyRight();
            return false;

            // type: unlike - 当前用户没有喜欢
            function toggleLike() {
                var processAPIUrl = function(url) {
                    return 'http://bbs.wandoujia.com/' + url.replace('[tid]', window.threadActionState.tid).replace('[hash]', window.threadActionState.like.hash).replace('[pid]', $elem.data('pid'));
                };
                if (type === 'unlike') {
                    if (threadActionState.login) {
                        _czc.push(["_trackEvent", '回复点赞', '已登陆']);
                    } else {
                        _czc.push(["_trackEvent", '回复点赞', '未登陆']);
                    }
                    type = 'like';
                    $.get(processAPIUrl('forum.php?mod=misc&action=postreview&do=support&tid=[tid]&pid=[pid]&hash=[hash]&newfav=1'));
                    likeCount += 1;
                } else {
                    if (threadActionState.login) {
                        _czc.push(["_trackEvent", '取消回复点赞', '已登陆']);
                    } else {
                        _czc.push(["_trackEvent", '取消回复点赞', '未登陆']);
                    }
                    $.get(processAPIUrl('forum.php?mod=misc&action=postreview&do=delete&tid=[tid]&pid=[pid]&hash=[hash]&newfav=1'));
                    type = 'unlike';
                    likeCount -= 1;
                }
                $elem.data('type', type);
                $elem.data('likenum', likeCount);
            }

            function processCopyRight() {
                var copyright;
                if (type === 'like') {
                    if (likeCount == 1) {
                        copyright = '您赞成';
                    } else {
                        copyright = '您与' + (likeCount - 1) + '人赞成';
                    }
                } else {
                    if (likeCount == 0) {
                        copyright = '赞成';
                    } else {
                        copyright = likeCount + '人赞成';
                    }
                }
                $elem.html(copyright);
            }
        });

        function setLikeAnonymousCookie(type, key) {
            if (threadActionState.islogin) return;
            var cookieStr = docCookies.getItem('bbs-thread-anonymous-like');
            if (type == 'add') {
                cookieStr += key + ',';
            } else {
                cookieStr = cookieStr.replace(key + ',', '');
            }
            docCookies.setItem('bbs-thread-anonymous-like', cookieStr);
        }

        function checkLikeAnonymous(key) {
            if (threadActionState.islogin) return;
            if (docCookies.hasItem('bbs-thread-anonymous-like')) {
                if (docCookies.getItem('bbs-thread-anonymous-like').indexOf(key) == -1) {
                    return true;
                } else {
                    return false;
                }
            }
            return true;
        }

        // 初始化，从cookie中获取
        if ('threadActionState' in window && !checkLikeAnonymous(threadActionState.tid)) {
            // 已经喜欢
            $('.thread-action-unlike').removeClass('thread-action-unlike').addClass('thread-action-like');
            threadActionState.like.status = !threadActionState.like.status;
        }

        $(document).on('click', '.thread-action a', function(e) {
            var type = $(this).data('type');
            var $elem = $(this);
            var _czc = window._czc || [];
            _czc.push(["_setAccount", "1000074060"]);
            // route by type
            switch (type) {
                case 'fav':
                    favHandler();
                    break;
                case 'rate':
                    // do as default
                    _czc.push(["_trackEvent", '评分', '1']);
                    if (threadActionState.rate.status) {
                        showPrompt(null, 'diy', '<i>不能重复评分哦</i>', 1000, 'popuptext');
                    }
                    break;
                case 'like':
                    likeHandler();
                    break;
                case 'share':
                    shareHandler();
                    break;
            }
            return false;

            function favHandler() {
                // http://home.php?mod=spacecp&ac=favorite&type=thread&id=[tid]&newfav=1
                // home.php?mod=spacecp&ac=favorite&op=delete&favid=[favid]&newfav=1
                if (!checkLogin()) {
                    return false;
                }
                if (this.flag === true) {
                    return false;
                }
                this.flag = true;
                var parentwindow = this;
                if (!threadActionState.fav.status) {

                    _czc.push(["_trackEvent", '收藏', '已登陆']);


                    $.get('/home.php?mod=spacecp&ac=favorite&type=thread&id=[tid]&newfav=1'.replace('[tid]', threadActionState.tid)).then(function(resp) {
                        parentwindow.flag = false;
                        resp = JSON.parse(resp);
                        threadActionState.fav.favid = resp.favid;
                        $elem.removeClass('thread-action-unfav').addClass('thread-action-fav');
                        threadActionState.fav.count = threadActionState.fav.count + 1;
                        if (threadActionState.fav.count == 0) {
                            $elem.find('span').html('&nbsp;');
                        } else {
                            $elem.find('span').html(threadActionState.fav.count);
                        }
                        threadActionState.fav.status = 1;

                        if (resp['error_code'] == '0') {
                            showPrompt(null, 'diy', '<i>收藏成功</i>', 1000, 'popuptext');
                        } else {
                            showPrompt(null, 'diy', '<i>' + resp['error_message'] + '</i>', 1000, 'popuptext');
                        }
                        // console.log(resp);
                        // set favid to threadActionState
                    });
                    // checkLogin
                    // addClass()
                    // changeNum()
                } else {

                    _czc.push(["_trackEvent", '取消收藏', '已登陆']);

                    $.get('/home.php?mod=spacecp&ac=favorite&op=delete&favid=[favid]&newfav=1'.replace('[favid]', threadActionState.fav.favid)).then(function(resp) {
                        parentwindow.flag = false;
                        $elem.removeClass('thread-action-fav').addClass('thread-action-unfav');
                        threadActionState.fav.count = threadActionState.fav.count - 1;
                        if (threadActionState.fav.count == 0) {
                            $elem.find('span').html('&nbsp;');
                        } else {
                            $elem.find('span').html(threadActionState.fav.count);
                        }
                        threadActionState.fav.status = 0;
                        resp = JSON.parse(resp);
                        if (resp['error_code'] == '0') {
                            showPrompt(null, 'diy', '<i>取消成功</i>', 1000, 'popuptext');
                        } else {
                            showPrompt(null, 'diy', '<i>' + resp['error_message'] + '</i>', 1000, 'popuptext');
                        }
                        // console.log(resp);
                        // set favid to threadActionState
                    });
                    // removeClass()
                    // changeNum()
                }
            }

            function likeHandler() {
                if (this.flag === true) {
                    return false;
                }
                this.flag = true;
                var parentwindow = this;

                if (!checkLikeAnonymous(threadActionState.tid)) {
                    if (threadActionState.login) {
                        _czc.push(["_trackEvent", '取消喜欢', '已登陆']);
                    } else {
                        _czc.push(["_trackEvent", '取消喜欢', '未登陆']);
                    }
                    setLikeAnonymousCookie('remove', threadActionState.tid);
                    $elem.removeClass('thread-action-like').addClass('thread-action-unlike');
                    threadActionState.like.count = threadActionState.like.count - 1;
                    if (threadActionState.like.count == 0) {
                        $elem.find('span').html('&nbsp;');
                    } else {
                        $elem.find('span').html(threadActionState.like.count);
                    }
                    threadActionState.like.status = 0;
                    $.get('/forum.php?mod=misc&action=recommend&do=dislike&tid=[tid]&hash=[hash]'.replace('[tid]', threadActionState.tid).replace('[hash]', threadActionState.like.hash)).then(function(resp) {
                        showPrompt(null, 'diy', '<i>取消成功</i>', 1000, 'popuptext');
                        parentwindow.flag = false;
                    });
                    return false;
                }


                if (!threadActionState.like.status) {
                    if (threadActionState.login) {
                        _czc.push(["_trackEvent", '喜欢', '已登陆']);
                    } else {
                        _czc.push(["_trackEvent", '喜欢', '未登陆']);
                    }
                    $.get('/forum.php?mod=misc&action=recommend&do=add&tid=[tid]&hash=[hash]&newfav=1'.replace('[tid]', threadActionState.tid).replace('[hash]', threadActionState.like.hash)).then(function(resp) {
                        parentwindow.flag = false;
                        $elem.removeClass('thread-action-unlike').addClass('thread-action-like');
                        threadActionState.like.count = threadActionState.like.count + 1;
                        if (threadActionState.like.count == 0) {
                            $elem.find('span').html('&nbsp;');
                        } else {
                            $elem.find('span').html(threadActionState.like.count);
                        }
                        threadActionState.like.status = 1;
                        resp = JSON.parse(resp);
                        if (resp['error_code'] == '0') {
                            showPrompt(null, 'diy', '<i>赞</i>', 1000, 'popuptext');
                        } else {
                            showPrompt(null, 'diy', '<i>' + resp['error_message'] + '</i>', 1000, 'popuptext');
                        }
                        // console.log(resp);
                        setLikeAnonymousCookie('add', threadActionState.tid);
                        // set favid to threadActionState
                    });
                } else {
                    if (threadActionState.login) {
                        _czc.push(["_trackEvent", '取消喜欢', '已登陆']);
                    } else {
                        _czc.push(["_trackEvent", '取消喜欢', '未登陆']);
                    }
                    $.get('/forum.php?mod=misc&action=recommend&do=dislike&tid=[tid]&hash=[hash]'.replace('[tid]', threadActionState.tid).replace('[hash]', threadActionState.like.hash)).then(function(resp) {
                        parentwindow.flag = false;
                        $elem.removeClass('thread-action-like').addClass('thread-action-unlike');
                        threadActionState.like.count = threadActionState.like.count - 1;
                        if (threadActionState.like.count == 0) {
                            $elem.find('span').html('&nbsp;');
                        } else {
                            $elem.find('span').html(threadActionState.like.count);
                        }
                        threadActionState.like.status = 0;
                        resp = JSON.parse(resp);
                        if (resp['error_code'] == '0') {
                            showPrompt(null, 'diy', '<i>取消成功</i>', 1000, 'popuptext');
                        } else {
                            showPrompt(null, 'diy', '<i>' + resp['error_message'] + '</i>', 1000, 'popuptext');
                        }
                        // console.log(resp);
                        setLikeAnonymousCookie('remove', threadActionState.tid);
                    });
                }
            }

            function shareHandler() {
                // plugin.php?id=wdjshare:wdjshare&tid=[tid]&path=sina
                // path可选值：sina，txwb，qzone
                // showMenu
                showMenu({
                    'ctrlid': 'thread-share-popup',
                    'pos': '34'
                });
            }
        });

        function checkLogin() {
            if (threadActionState.login) {
                return true;
            } else {
                // popup or redirect - then reload or promise defer
                if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                    window.location.href = 'http://www.wandoujia.com/account/web.html?medium=bbs&callback=http%3a%2f%2fbbs.wandoujia.com%2fplugin.php%3fid%3daccount%3acallback%26tid%3d&tid=' + threadActionState.tid;
                } else {
                    SnapPea.AccountHook.checkAsync().then(function(resp) {
                        window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback&tid=' + threadActionState.tid;
                        return true;
                    }).fail(function() {
                        SnapPea.AccountHook.openAsync('login').then(function(resp) {
                            if (resp.isLoggedIn) {
                                window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback&tid=' + threadActionState.tid;
                                return true;
                            } else {
                                return false;
                            }
                        });
                    });
                }

                return false;
            }
        }
        // $('.thread-action-share-ctn').on('click', 'a', function() {
        //     // plugin.php?id=wdjshare:wdjshare&tid=[tid]&path=sina
        //     // path可选值：sina，txwb，qzone
        //     var type = $(this).data('type');
        //     var $elem = $(this);
        //     var url = '';
        //     switch (type) {
        //         case 'sina':
        //             // open window for do share weibo
        //             url = "http://service.weibo.com/share/share.php?url=http%3A%2F%2Fbbs.wandoujia.com%2Fthread-[tid]-1-1.html&type=button&ralateUid=3879563082&language=zh_cn&appkey=3017506897&title=[content]&searchPic=false&style=number&sudaref=service.weibo.com&pic=[pic]";
        //             break;
        //         case 'txwb':
        //             url = "http://share.v.t.qq.com/index.php?c=share&a=index&url=http%3A%2F%2Fbbs.wandoujia.com%2Fthread-[tid]-1-1.html&appkey=801476866&assname=&title=[content]&pic=[pic]";
        //             break;
        //         case 'qzone':
        //             url = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http%3A%2F%2Fbbs.wandoujia.com%2Fthread-[tid]-1-1.html&summary=[desc]&title=[title]&desc=这个写得很不错，大家快来看看！&pics=[pic]";
        //             break;
        //     }
        //     url = url.replace('[tid]', threadActionState.tid).replace('[title]', threadActionState.title).replace('[pic]', threadActionState.pic).replace('[content]', "【" + threadActionState.title + "】" + threadActionState.desc).replace('[desc]', threadActionState.desc);
        //     if ( !! window.campaignPlugin) {
        //         //P4
        //         window.location.href = url;
        //     } else {
        //         if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
        //             //PC client
        //             window.location.href = url;
        //         } else {
        //             //Web Browser
        //             window.open(url, '', 'width=700, height=400, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no');
        //         }
        //     }
        //     $.get('/plugin.php?id=wdjshare:wdjshare&tid=[tid]&path=[type]'.replace('[type]', type).replace('[tid]', threadActionState.tid)).then(function(resp) {
        //         // success - add number
        //         threadActionState[type].count += 1;
        //         threadActionState.share.count += 1;
        //         $elem.find('span').html(threadActionState[type].count);
        //         $('#thread-share-popup').find('span').html(threadActionState.share.count);
        //         $elem.removeClass('share-btn-un' + type).addClass('share-btn-' + type);
        //         $('#thread-share-popup').removeClass('thread-action-unshare').addClass('thread-action-share');
        //     });
        //     return false;
        // });


        window.notloginsign = function(tid) {
            var _czc = window._czc || [];
            _czc.push(["_trackEvent", '未登录签到', '1']);
            globalLoginAndRegister('login', tid);
        };
        window.globalLoginAndRegister = function(name, tid) {
            if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                if (name == "login") {
                    window.location.href = 'http://www.wandoujia.com/account/web.html?medium=bbs&callback=http%3a%2f%2fbbs.wandoujia.com%2fplugin.php%3fid%3daccount%3acallback%26tid%3d&tid=' + tid;
                } else {
                    window.location.href = 'http://www.wandoujia.com/account/web.html?medium=bbs&callback=http%3a%2f%2fbbs.wandoujia.com%2fplugin.php%3fid%3daccount%3acallback%26tid%3d&tid=' + tid + '#register';
                }
            } else {
                SnapPea.AccountHook.checkAsync().then(function(resp) {
                    if (tid === 0) {
                        window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback';
                    } else {
                        window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback&tid=' + tid;
                    }
                }).fail(function() {
                    SnapPea.AccountHook.openAsync(name).then(function(resp) {
                        if (resp.isLoggedIn) {
                            if (tid === 0) {
                                window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback';
                            } else {
                                window.location.href = 'http://bbs.wandoujia.com/plugin.php?id=account:callback&tid=' + tid;
                            }
                            // console.log('Welcome back, %s.', resp.data.nick); // 操作成功后处于登录状态
                        } else {
                            // console.log('Bye.'); // 操作成功后处于未登录状态
                        }
                    });
                });
            }
            return false;
        };

        window.downloadbtn = function(package) {
            var _czc = window._czc || [];
            _czc.push(["_setAccount", "1000074060"]);
            if ( !! window.campaignPlugin) {
                _czc.push(["_trackEvent", '下载按钮P4', package]);
                window.campaignPlugin.openAppDetail(package);
            } else {
                if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                    _czc.push(["_trackEvent", '下载按钮PC', package]);
                    window.location.href = 'http://apps.wandoujia.com/apps/' + package;
                } else {
                    _czc.push(["_trackEvent", '下载按钮Browser', package]);
                    window.open('http://www.wandoujia.com/apps/' + package);
                }
            }
        };
        window.searchbtnClcik = function() {
            var _czc = window._czc || [];

            if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                _czc.push(["_trackEvent", '搜索按钮', 'PC']);
            } else {
                _czc.push(["_trackEvent", '搜索按钮', 'Browser']);
            }
        };

        window.jumpApps = function(uid) {
            var _czc = window._czc || [];

            _czc.push(["_trackEvent", '应用中心按钮', '1']);

        }

        // add arrow
        $('.thread-action-share-ctn').prepend('<i class="arrow icon"></i>');
        $('.thread-action-share-ctn').addClass('popover').addClass('bottom');
    });
})(jQuery);

//http://bbs.wandoujia.com/home.php?mod=finishnewpm&category=post
if (window.switchRadio === 1) {
    (function($) {
        jQuery("#hd .wp .hdc h2 a").css("background", "url('/static/image/common/logo_wc.png') no-repeat").css("height", "70px").css("width", "460px").css("background-size", "460px,70px");
        jQuery("#hd .wp .hdc h2").css("padding", "0 20px 0 0");
    })(jQuery);
}

/* earthhour block */
if (false) {
    (function($) {
        window.earthhourClosing = false;
        var shareStr = '<div class="eh-share-ctn"><span>分享到： </span>' +
            '<a href="#" class="share-btn-sina" data-type="sina" title="新浪微博"><i></i></a>' +
            '<a href="#" class="share-btn-qzone" data-type="qzone" title="QQ空间"><i></i></a>' +
            '<a href="#" class="share-btn-txwb" data-type="txwb" title="腾讯微博"><i></i></a></div>';

        var earthhourSwitchStr = '<a class="earthhour-switch-wrap"><img src="http://img.wdjimg.com/bbs/earthhour/switcher.png" /><img class="earthhour-switch-light" src="http://img.wdjimg.com/bbs/earthhour/light.png"></img></a>';
        jQuery('<div class="popup-wrap"></div>').append(jQuery('<div class="img-wrap"><img src="http://img.wdjimg.com/bbs/earthhour/popup.jpg"></img></div>')).appendTo('body');
        $('.hdc h2').after($(earthhourSwitchStr));
        $('.popup-wrap .img-wrap').append($(shareStr));
        $('.earthhour-switch-wrap').click(function(e) {
            var $popupWrap = $('.popup-wrap');
            if ($popupWrap.css('opacity') == 0) {
                $popupWrap.css('opacity', 1).css('zIndex', 9998);
            }
            if ($popupWrap.css('opacity') == 1) {
                $popupWrap.css('opacity', 0);
                if (window.earthhourClosing) return;
                window.earthhourClosing = true;
                setTimeout(function() {
                    $popupWrap.css('zIndex', '-1');
                    window.earthhourClosing = false;
                }, 1000);
            }
        });
        $('.eh-share-ctn').on('click', 'a', function(e) {
            var type = $(this).data('type');
            switch (type) {
                case 'sina':
                    url = 'http://service.weibo.com/share/share.php?url=http%3A%2F%2Fbbs.wandoujia.com&type=button&ralateUid=3879563082&language=zh_cn&appkey=3017506897&title=[content]&searchPic=false&style=number&sudaref=service.weibo.com&pic=[pic]';
                    break;
                case 'txwb':
                    url = 'http://share.v.t.qq.com/index.php?c=share&a=index&url=http%3A%2F%2Fbbs.wandoujia.com&appkey=801476866&assname=&title=[content]&pic=[pic]';
                    break;
                case 'qzone':
                    url = 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http%3A%2F%2Fbbs.wandoujia.com&summary=[content]&title=地球一小时，我不要生活被埋葬！——豌豆荚论坛&desc=3月29日晚20点30分，一起行动来！&pics=[pic]';
                    break;
            }
            url = url.replace('[content]', '%23%e5%9c%b0%e7%90%83%e4%b8%80%e5%b0%8f%e6%97%b6%23%e6%88%91%e4%b8%8d%e8%a6%81%e5%81%9a%e4%ba%ba%e8%82%89%e5%90%b8%e5%b0%98%e5%99%a8%ef%bc%8c%e6%af%8f%e5%a4%a9%e8%b5%b7%e5%ba%8a%e5%88%b7+PM+2.5%ef%bc%81%e6%88%91%e4%b8%8d%e8%a6%81%e5%87%ba%e9%97%a8%e6%88%b4%e5%8f%a3%e7%bd%a9%ef%bc%8c%e6%ad%bb%e5%ae%85%e5%9c%a8%e5%ae%b6%e4%b8%8d%e5%bc%80%e7%aa%97%ef%bc%81%e6%88%91%e4%b8%8d%e8%a6%81%ef%bc%8c%e7%94%9f%e6%b4%bb%e8%a2%ab%e9%9c%be%e8%91%ac%ef%bc%81').replace('[pic]', 'http%3a%2f%2fimg.wdjimg.com%2fbbs%2fearthhour%2fpopup.jpg');
            if ( !! window.campaignPlugin) {
                //P4
                window.location.href = url;
            } else {
                if ((window.OneRingRequest !== undefined) && (window.OneRingStreaming !== undefined)) {
                    //PC client
                    window.location.href = url;
                } else {
                    //Web Browser
                    window.open(url, '', 'width=700, height=400, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no');
                }
            }
            return false;
        });
        $(document).on('click', '.popup-wrap', function() {
            $(this).css('opacity', 0);
            if (window.earthhourClosing) return;
            window.earthhourClosing = true;
            setTimeout(function() {
                $('.popup-wrap').css('zIndex', '-1');
                window.earthhourClosing = false;
            }, 1000);
        });
    })(jQuery);
}
/* endblock */