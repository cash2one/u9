#!/bin/sh
gradle clean
gradle asD
adb uninstall com.wandoujia.mariosdk.plugin.demo
adb install ./build/outputs/apk/plugin-demo-debug.apk
adb shell am start -n com.wandoujia.mariosdk.plugin.demo/com.wandoujia.mariosdk.plugin.demo.MarioPluginDemoActivity
