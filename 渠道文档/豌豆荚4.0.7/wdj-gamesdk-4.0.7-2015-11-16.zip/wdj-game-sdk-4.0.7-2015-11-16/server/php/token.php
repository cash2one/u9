<?
/* token check example
write by Aidi(aidi@wandoujia.com)
remember to set your game appkey_id
*/
$tokenAPI="https://pay.wandoujia.com/api/uid/check";
$uid="8139480";
$token=urlencode("TdIKyj1Wqor3XrlamnLQcmCaqlHeClkPXg4OmPo3iBo=");
$url=$tokenAPI."?uid=".$uid."&token=".$token."&appkey_id=100000000";
echo file_get_contents($url);
?>

