<?php
// write by Aidi(aidi@wandoujia.com)
include "rsa.php";
$content=$_REQUEST['content'];
$sign=$_REQUEST['sign'];
$rsa=new Rsa;
$result=$rsa->verify($content,$sign);
if($result) {
	//deal order info in $content
	echo "success";
} else {
	echo "fail";
}
?>

