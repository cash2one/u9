// WandoujiaRSA_cpp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <atlbase.h>
#include <wincrypt.h>
#include <string>

#include "signature_verifier.h"

const char kPublicKey[] =
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCd95FnJFhPinpNiE/h4VA6bU1rzRa5+a2"
    "5BxsnFX8TzquWxqDCoe4xG6QKXMXuKvV57tTRpzRo2jeto40eHKClzEgjx9lTYVb2RFHHFW"
    "io/YGTfnqIPTVpi7d7uHY+0FZ0lYL5LlW4E2+CQMxFOPRwfqGzMjs1SDlH7lVrLEVy6QIDA"
    "QAB";

void Base64ToBinary(const char* b64str, DWORD str_size, std::string* bin_data){
  DWORD dwSkip;
  DWORD dwFlags;
  DWORD bin_size;
  CryptStringToBinaryA(b64str, str_size, CRYPT_STRING_BASE64,
                       NULL, &bin_size, &dwSkip, &dwFlags);
  bin_data->resize(bin_size);
  CryptStringToBinaryA(b64str, str_size, CRYPT_STRING_BASE64,
                       (BYTE*)bin_data->data(), &bin_size, &dwSkip, &dwFlags);
}

int _tmain(int argc, _TCHAR* argv[])
{
  std::string public_key_data;
  Base64ToBinary(kPublicKey, strlen(kPublicKey), &public_key_data);
  
  std::string sign_data;
  const char sign[] =
      "VwnhaP9gAbDD2Msl3bFnvsJfgz3NOAqM/JVexl1myHfsrHX3cRrFXz86cNO+oNY"
      "WBBM7m/5ZdtHRpSArZWFuZHysKfirO3BynUaIYSAiD2J1Xio5q9+Yr83cI/ESye"
      "mVAt7lK4lMW3ReSwmAcOs0kDZLAxVIb++EPy0y2NpH4kI=";
  Base64ToBinary(sign, strlen(sign), &sign_data);
  
  crypto::SignatureVerifier signer;
  signer.VerifyInit((const uint8*)sign_data.data(), sign_data.size(),
                    (const uint8*)public_key_data.data(), public_key_data.size());

  std::string content =
    "{\"timeStamp\":1363848203377,\"orderId\":100001472,"
    "\"money\":4000,\"chargeType\":\"BALANCEPAY\",\"appK"
    "eyId\":100000000,\"buyerId\":1,\"cardNo\":null}";
  signer.VerifyUpdate((const uint8*)content.data(), content.size());
  ATLASSERT(signer.VerifyFinal());
  return 0;
}
