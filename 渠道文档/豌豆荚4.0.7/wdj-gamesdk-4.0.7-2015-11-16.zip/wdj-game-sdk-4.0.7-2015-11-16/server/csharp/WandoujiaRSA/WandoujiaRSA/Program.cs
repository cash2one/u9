﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.Diagnostics;

namespace WandoujiaRSA
{
    class Program
    {
        static void Main(string[] args)
        {
            bool verified = RSAUtils.VerifyData("{\"timeStamp\":1363848203377,\"orderId\":100001472,\"money\":4000,\"chargeType\":\"BALANCEPAY\",\"appKeyId\":100000000,\"buyerId\":1,\"cardNo\":null}",
                "VwnhaP9gAbDD2Msl3bFnvsJfgz3NOAqM/JVexl1myHfsrHX3cRrFXz86cNO+oNYWBBM7m/5ZdtHRpSArZWFuZHysKfirO3BynUaIYSAiD2J1Xio5q9+Yr83cI/ESyemVAt7lK4lMW3ReSwmAcOs0kDZLAxVIb++EPy0y2NpH4kI=");
            Debug.Assert(verified);
        }
    }

}