

@Controller
public class CallTestAction {

    private final static Log logger = LogFactory.getLog(CallTestAction.class);


    private static String sign_key = "thisistestkey";


    @RequestMapping(value = "/vc/notifytest")
    @ResponseBody
    public String notifyTest(@RequestParam("app_id") String app_id, @RequestParam("lepay_order_no") String lepay_order_no,
                             @RequestParam("letv_user_id") String letv_user_id, @RequestParam("out_trade_no") String out_trade_no,
                             @RequestParam("pay_time") String pay_time, @RequestParam("price") String price,
                             @RequestParam("product_id") String product_id, @RequestParam("sign_type") String sign_type,
                             @RequestParam("trade_result") String trade_result,@RequestParam("version") String version,
                             @RequestParam("cooperator_order_no") String cooperator_order_no,@RequestParam("sign") String sign,
                             @RequestParam("extra_info") String extra_info,
                             @RequestParam("original_price") String original_price){
        if(checkSign(app_id,lepay_order_no,letv_user_id,out_trade_no, pay_time,price,product_id,sign_type,
                trade_result,version,cooperator_order_no,sign,extra_info,original_price)){
            return Const.NOTIFY_CP_RESP_SUCC;
        }else {
            return "sign-fail";
        }
    }

    /**
     * sign succ >> true,fail >> false;
     * @return
     */
    private boolean checkSign( String app_id,  String lepay_order_no,
                            String letv_user_id,  String out_trade_no,
                            String pay_time,  String price,
                            String product_id,  String sign_type,
                            String trade_result, String version,
                            String cooperator_order_no, String sign,
                            String extra_info, String original_price) {

        List<NameValuePair> paramslist = new LinkedList<NameValuePair>();
        paramslist.add(new BasicNameValuePair("app_id", app_id));
        paramslist.add(new BasicNameValuePair("lepay_order_no", lepay_order_no));
        paramslist.add(new BasicNameValuePair("letv_user_id", letv_user_id));
        paramslist.add(new BasicNameValuePair("out_trade_no", out_trade_no));
        paramslist.add(new BasicNameValuePair("pay_time", pay_time));
        paramslist.add(new BasicNameValuePair("price", price));
        paramslist.add(new BasicNameValuePair("product_id", product_id));
        paramslist.add(new BasicNameValuePair("sign_type", sign_type));
        paramslist.add(new BasicNameValuePair("trade_result", trade_result));
        paramslist.add(new BasicNameValuePair("version", version));
        paramslist.add(new BasicNameValuePair("cooperator_order_no", cooperator_order_no));
        paramslist.add(new BasicNameValuePair("extra_info", extra_info));
        paramslist.add(new BasicNameValuePair("original_price", original_price));
        String paramStrg = getUrlParams(paramslist) + "&key=" + sign_key;
        logger.info("param_str_append_key:=" + paramStrg);
        String selfSign = getMD5(paramStrg);
        logger.info(" param_str_sign:=" + sign);
        logger.info(" create_str_sign:=" + selfSign);
        return selfSign.equals(sign);    
    }

    private String getUrlParams(List<NameValuePair> paramslist) {
        if (paramslist == null || paramslist.size() == 0) {
            return "";
        }
        Collections.sort(paramslist, DICCOMPARATOR);
        StringBuffer sb = new StringBuffer();
        final int count = paramslist.size();
        for (int i = 0; i < count; i++) {
            if (i != 0) {
                sb.append("&");
            }
            sb.append(paramslist.get(i).getName());
            sb.append("=");
            sb.append(paramslist.get(i).getValue());
        }
        return sb.toString();
    }

    private static final Comparator<NameValuePair> DICCOMPARATOR = new Comparator<NameValuePair>() {
        @Override
        public int compare(NameValuePair lhs, NameValuePair rhs) {
            if (lhs.getName().equals(rhs.getName())) {
                return 0;
            }
            return lhs.getName().compareToIgnoreCase(rhs.getName());
        }
    };

    public final static String getMD5(String s) {
        char hexDigits[]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
        try {
            byte[] btInput = s.getBytes();
            // 获得MD5摘要算法的 MessageDigest 对象
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            // 使用指定的字节更新摘要
            mdInst.update(btInput);
            // 获得密文
            byte[] md = mdInst.digest();
            // 把密文转换成十六进制的字符串形式
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
