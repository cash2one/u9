package com.letv.sdk.demo.utils;

import java.util.Random;

public class RandomUtil {
	
	public static String getRandom(){
		Random random=new Random(System.currentTimeMillis());
		return random.nextInt(99999999)%90000000+10000000+"";
	}
	
}
