package com.letv.sdk.demo.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

public class SignUtil {
	private static final String signKey = "qwertyuiolkjhgfdsa"; // 测试md5签名key

	/**
	 * 获取回调传里的签名
	 * 
	 * @param result
	 *            处理后的回调串
	 * @return 回调串里的签名sign
	 */
	public static String getSign(String result) {
		try {
			result = URLDecoder.decode(result, "UTF-8");
			String[] str = result.split("&");
			for (int i = 0; i < str.length; i++) {
				String[] param = str[i].split("=");
				if (param.length == 2) {
					if ("sign".equals(param[0])) {
						return param[1];
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 获取支付结果
	 * 
	 * @param result
	 *            处理后的回调串
	 * @return 支付结果(TRADE_SUCCESS)
	 */
	public static String getState(String result) {
		try {
			result = URLDecoder.decode(result, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] str = result.split("&");
		for (int i = 0; i < str.length; i++) {
			String[] param = str[i].split("=");
			if (param.length == 2) {
				if ("trade_result".equals(param[0])) {
					return param[1];
				}
			}
		}
		return null;
	}

	/**
	 * CP自行签名用于验签
	 * 
	 * @param result
	 *            处理后的回调串
	 * @return 返回签名结果
	 */
	public static String creatSign(String result) {
		try {
			result = URLDecoder.decode(result, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] str = result.split("&");
		ArrayList<NameValuePair> pairs = new ArrayList<NameValuePair>();
		for (int i = 0; i < str.length; i++) {
			String[] param = str[i].split("=");
			if (param.length == 2) {
				if ("sign".equals(param[0]) || "extra_info".equals(param[0]) || "cooperator_order_no".equals(param[0])
						|| "original_price".equals(param[0])) {

				} else {
					pairs.add(new BasicNameValuePair(param[0], param[1]));
				}
			}
		}
		return MD5Util.MD5(getUrlParams(pairs));
	}

	/**
	 * 拼接签名串
	 * 
	 * @param paramslist
	 *            签名串参数
	 * @return 签名串
	 */
	private static String getUrlParams(List<NameValuePair> paramslist) {
		if (paramslist == null || paramslist.size() == 0) {
			return "";
		}
		URLEncodedUtils.format(paramslist, "UTF-8");
		Collections.sort(paramslist, DICCOMPARATOR);
		StringBuffer sb = new StringBuffer();
		final int count = paramslist.size();
		for (int i = 0; i < count; i++) {
			if (i != 0) {
				sb.append("&");
			}
			sb.append(paramslist.get(i).getName());
			sb.append("=");
			sb.append(paramslist.get(i).getValue());
		}
		return sb.toString() + "&key=" + signKey;
	}

	private static final Comparator<NameValuePair> DICCOMPARATOR = new Comparator<NameValuePair>() {
		@Override
		public int compare(NameValuePair lhs, NameValuePair rhs) {
			if (lhs.getName().equals(rhs.getName())) {
				return 0;
			}
			return lhs.getName().compareToIgnoreCase(rhs.getName());
		}
	};

}
