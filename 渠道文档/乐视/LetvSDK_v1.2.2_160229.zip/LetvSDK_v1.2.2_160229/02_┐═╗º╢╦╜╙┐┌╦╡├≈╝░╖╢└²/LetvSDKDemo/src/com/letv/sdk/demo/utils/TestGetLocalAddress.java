package com.letv.sdk.demo.utils;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class TestGetLocalAddress {
	public static String getLocalAddress(Context context) {
		BufferedReader bw = null;
		try {
			PackageManager pm = context.getPackageManager();
			String filepath = pm.getApplicationInfo("com.letv.sdk.demo.leshi", PackageManager.GET_META_DATA).dataDir
					+ "/files/lds.cfg";
			File f = new File(filepath);
			if (!f.exists()) {
				return null;
			}
			bw = new BufferedReader(new FileReader(f));
			String line = bw.readLine();
			if (line != null)
				return line;
		} catch (Exception e) {
			// e.printStackTrace();
		} finally {
			try {
				if (bw != null) {
					bw.close();
				}
			} catch (Exception e) {
			}
		}
		return null;
	}

}
