package com.letv.sdk.demo.activity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

import com.letv.lepaysdk.smart.LePayInfo;
import com.letv.letvsdk.LetvSDK;
import com.letv.letvsdk.LetvSDK.ExitCallback;
import com.letv.letvsdk.LetvSDK.InitCallback;
import com.letv.letvsdk.LetvSDK.LoginCallback;
import com.letv.letvsdk.LetvSDK.PayCallback;
import com.letv.sdk.demo.leshi.R;
import com.letv.sdk.demo.utils.RandomUtil;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GameActivity extends Activity implements OnClickListener {

	private LetvSDK letvSDK;

	private String TAG = "LetvSDK";

	private String letv_uid = null;
	private String access_token = null;

	private String product_image = null;

	private boolean isPay = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState != null) {
			letv_uid = savedInstanceState.getString("letv_uid");
			access_token = savedInstanceState.getString("access_token");
		}

		setContentView(R.layout.activity_game);
		initViews();
		product_image = getApplicationContext().getFilesDir().getAbsolutePath() + "/product_image.png";
		product_image_url_edt.setText(product_image);
		try {
			copyAssetsDataToSD(product_image);
		} catch (IOException e) {
			e.printStackTrace();
		}
		letvSDK = LetvSDK.init(this, initCallback);
		System.out.println(letvSDK);

		// 登录账号
		loginBtn.setOnClickListener(this);

		// 切换账号
		switchUserBtn.setOnClickListener(this);

		// 发起支付
		payBtn.setOnClickListener(this);

	}

	@Override
	protected void onStart() {
		super.onStart();
		Log.i(TAG, "===onStart is called===");
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "===onResume is called===");
		letvSDK.resume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "===onPause is called===");
		letvSDK.pause(this);
	}

	@Override
	protected void onStop() {
		super.onStop();
		Log.i(TAG, "===onStop is called===");
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Log.i(TAG, "===onRestart is called===");
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "===onDestroy is called===");
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.loginBtnId:

			doLogin();
			break;
		case R.id.switchUserBtnId:

			doSwitchUser();
			break;
		case R.id.payBtnId:

			if (letv_uid == null || access_token == null) {
				isPay = true;
				doLogin();
			} else {
				doPay();
			}

			break;

		default:
			break;
		}
	}

	/**
	 * 初始化回调
	 */
	private InitCallback initCallback = new InitCallback() {

		@Override
		public void onSdkInitResult(String status, String errorMessage) {
			Log.i("TAG", "===onSdkInitResult is called===");
			Log.i("TAG", "Init_Status: " + status + ", error_message: " + errorMessage);
		}
	};

	/**
	 * 登录
	 */
	private void doLogin() {
		Log.i(TAG, "===doLogin is called");

		// false表示不切换账号
		letvSDK.login(this,loginCallback, false);
	}

	/**
	 * 切换账号
	 */
	private void doSwitchUser() {
		Log.i(TAG, "===doSwitchUser is called");

		// true表示切换账号
		letvSDK.login(this,loginCallback, true);

	}

	/**
	 * 登录及切换账号回调
	 */
	private LoginCallback loginCallback = new LoginCallback() {

		@Override
		public void onLoginResult(HashMap<String, Object> userInfo) {
			Log.i(TAG, "===onLoginResult is called===");
			if (userInfo != null) {
				// 获取access_token
				access_token = (String) userInfo.get("access_token");
				// 获取letv_uid
				letv_uid = (String) userInfo.get("letv_uid");
				String nickname = (String) userInfo.get("nickname");
				Log.i(TAG, "Access_Token=" + access_token + ",Letv_uid=" + letv_uid + ",NickName=" + nickname);

			} else {
				Log.e(TAG, "===Login Failed===");
			}

			if (isPay) {
				doPay();
				isPay = false;
			}

		}

		@Override
		public void onLoginQuit() {
			Log.i(TAG, "==onLoginQuit is called==");
		}
	};

	/**
	 * 支付
	 */
	private void doPay() {
		Log.i(TAG, "==doPay is called==");

		LePayInfo payInfo = new LePayInfo();
		payInfo.setLetv_user_access_token(access_token);
		payInfo.setLetv_user_id(letv_uid);// 乐视集团用户id
		payInfo.setNotify_url(notify_url_edt.getText().toString());// 支付结果回调地址
		payInfo.setCooperator_order_no(RandomUtil.getRandom());// CP自定义订单号
		payInfo.setPrice(product_price_edt.getText().toString());// 产品价格
		payInfo.setProduct_name(product_name_edt.getText().toString());// 商品名称
		payInfo.setProduct_desc(product_desc_edt.getText().toString());// 商品描述

		payInfo.setPay_expire(pay_expire_edt.getText().toString());// 支付结束期限
		payInfo.setProduct_id(product_id_edt.getText().toString());// 商品id
		payInfo.setCurrency(currency_edt.getText().toString());// 货币种类
		payInfo.setProduct_urls("file://android_asset/res/image/common/gold_icon.png");// 商品图片
		payInfo.setExtro_info(extra_info_edt.getText().toString());// cp自定义参数
		letvSDK.pay(this,payInfo, payCallback);
	}

	/**
	 * 支付回调
	 */
	private PayCallback payCallback = new PayCallback() {

		@Override
		public void onPayResult(String status, String errorMessage) {
			Log.i(TAG, "==onPayResult is called==");
			
			Toast.makeText(getApplicationContext(), "Status:"+status+", message"+errorMessage, Toast.LENGTH_LONG).show();
			if (status.equals("success")) {
				Log.i(TAG, "支付成功，支付订单信息：" + errorMessage);
				// 支付成功，游戏做逻辑处理

			} else if (status.equals("failed")) {
				Log.i(TAG, "支付失败，失败信息：" + errorMessage);
				// 支付失败，游戏做逻辑处理

			} else {
				Log.i(TAG, "支付失败, Unknown Error Occoured！");
				// 未知情况，游戏做逻辑处理

			}
		}
	};

	@Override
	public void onBackPressed() {
		Log.i(TAG, "===onBackPressed is called");
		letvSDK.exit(this,exitCallback);
	}

	/**
	 * 退出回调
	 */
	private ExitCallback exitCallback = new ExitCallback() {

		@Override
		public void onSdkExitConfirmed() {
			Log.i(TAG, "===onSdkExitConfirmed is called===");
			// 玩家确认退出,在此处理游戏退出的逻辑,例如回收等;
			GameActivity.this.finish();
		}

		@Override
		public void onSdkExitCanceled() {
			Log.i(TAG, "===onSdkExitCanceled is called===");
			// 玩家取消退出,继续游戏;
		}
	};

	protected void onSaveInstanceState(Bundle outState) {
		outState.putString("letv_uid", letv_uid);
		outState.putString("access_token", access_token);
	};

	private Button loginBtn;
	private Button switchUserBtn;
	private Button payBtn;
	private EditText notify_url_edt;
	private EditText product_price_edt;
	private EditText currency_edt;
	private EditText pay_expire_edt;
	private EditText product_id_edt;
	private EditText product_name_edt;
	private EditText product_desc_edt;
	private EditText product_image_url_edt;
	private EditText extra_info_edt;

	/**
	 * 初始化控件
	 */
	private void initViews() {
		Log.i(TAG, "===initViews is called===");

		loginBtn = (Button) findViewById(R.id.loginBtnId);
		switchUserBtn = (Button) findViewById(R.id.switchUserBtnId);
		payBtn = (Button) findViewById(R.id.payBtnId);

		notify_url_edt = (EditText) findViewById(R.id.notifyUrlEdtId);
		product_price_edt = (EditText) findViewById(R.id.productPriceEdtId);
		currency_edt = (EditText) findViewById(R.id.currencyEdtId);
		pay_expire_edt = (EditText) findViewById(R.id.payExpireEdtId);
		product_id_edt = (EditText) findViewById(R.id.productIdEdtId);
		product_name_edt = (EditText) findViewById(R.id.productNameEdtId);
		product_desc_edt = (EditText) findViewById(R.id.productDescEdtId);
		product_image_url_edt = (EditText) findViewById(R.id.productImageUrlEdtId);
		extra_info_edt = (EditText) findViewById(R.id.extraInfoEdtId);
	}

	/**
	 * 
	 * @param fileName
	 *            文件名
	 * @throws IOException
	 */
	private void copyAssetsDataToSD(String fileName) throws IOException {
		Log.i(TAG, "===copyAssetsDataToSD is called");

		if (fileName == "" || fileName == null) {
			return;
		}

		InputStream is = null;
		OutputStream os = new FileOutputStream(fileName);
		AssetManager am = this.getAssets();
		is = am.open("diamond_01.png");
		byte[] buffer = new byte[1024];
		int length = is.read(buffer);
		while (length > 0) {
			os.write(buffer, 0, length);
			length = is.read(buffer);
		}
		os.flush();
		is.close();
		os.close();
	}

}
