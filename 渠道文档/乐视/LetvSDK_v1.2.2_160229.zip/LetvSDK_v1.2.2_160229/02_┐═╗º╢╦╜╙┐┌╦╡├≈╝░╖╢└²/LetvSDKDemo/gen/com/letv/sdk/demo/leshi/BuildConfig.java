/** Automatically generated file. DO NOT MODIFY */
package com.letv.sdk.demo.leshi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}