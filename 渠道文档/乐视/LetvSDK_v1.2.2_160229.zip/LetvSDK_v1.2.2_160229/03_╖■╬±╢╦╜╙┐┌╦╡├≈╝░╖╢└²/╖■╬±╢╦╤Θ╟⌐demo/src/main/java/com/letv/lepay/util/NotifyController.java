package com.letv.lepay.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("test")
public class NotifyController {


	@RequestMapping(value = "notify")
	public String receive(HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("start");
		System.out.println(LepayNotify.verify(request));

		return null;
	}

}
