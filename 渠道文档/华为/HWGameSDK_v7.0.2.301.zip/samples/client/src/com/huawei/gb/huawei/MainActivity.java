/*
Copyright (C) Huawei Technologies Co., Ltd. 2015. All rights reserved.
See LICENSE.txt for this sample's licensing information.
*/

package com.huawei.gb.huawei;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.huawei.gamebox.buoy.sdk.impl.BuoyOpenSDK;
import com.huawei.gamebox.buoy.sdk.inter.UserInfo;
import com.huawei.gamebox.buoy.sdk.util.DebugConfig;
import com.huawei.gb.huawei.net.ReqTask;
import com.huawei.gb.huawei.net.ReqTask.Delegate;
import com.huawei.hwid.openapi.OpenHwID;
import com.huawei.opensdk.OpenSDK;
import com.huawei.opensdk.RetCode;

public class MainActivity extends Activity implements OnClickListener
{
    
    // 日志标签
    public static final String TAG = "MainActivity";
    
    // 返回键是否可用
    private static boolean isBackKeyEnable = true;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        
        // 设置全屏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.main);
        
        Button start = (Button)findViewById(R.id.start);
        start.setOnClickListener(this);

    }
    
    protected void onStart()
    {
        super.onStart();
        TextView loginPageTips = (TextView)findViewById(R.id.page1);
        loginPageTips.setText("点击按钮进行登录");
    }
    
    protected void onDestroy()
    {
        super.onDestroy();
        // 仅当MainActivity为最后一个Activity时，才释放资源
        if (isTaskRoot())
        {
            // 清空帐号资源
            OpenHwID.releaseResouce();
            // 在退出的时候销毁浮标
            BuoyOpenSDK.getIntance().destroy(this);
        }
        
    }
    
    /**
     * 对login按钮进行响应
     */
    @Override
    public void onClick(View view)
    {
        final String privateKeyCons = "";

        int id = view.getId();
        // 开启浮标的日志功能，发布时去掉
        DebugConfig.setLog(true);
        switch (id)
        {
        // 点击初始化按钮进行初始化
            case R.id.start:
                
                // 为了安全把浮标密钥放到服务端，并使用https的方式获取下来存储到内存中，CP可以使用自己的安全方式处理
                ReqTask getBuoyPrivate = new ReqTask(new ReqTask.Delegate()
                {
                    
                    @Override
                    public void execute(String buoyPrivateKey)
                    {
                        /**
                         * 从服务端获取的浮标私钥，由于没有部署最终的服务端，所以返回值写死一个值，CP需要从服务端获取，服务端代码参考华为Demo
                         * 请查阅 华为游戏中心SDK开发指导书.docx 的2.5节
                         */
                        buoyPrivateKey = privateKeyCons;
                        
                        GlobalParam.BUO_SECRET = buoyPrivateKey;

                        // 浮标初始化
                        int retCode = OpenSDK.init(
                            MainActivity.this,
                            GlobalParam.APP_ID,
                            GlobalParam.CP_ID,
                            buoyPrivateKey,
                            new UserInfo()
                            {
                                
                                @Override
                                public void dealUserInfo(HashMap<String, String> userInfo)
                                {
                                    TextView loginPageTips = (TextView)findViewById(R.id.page1);
                                    
                                    // 用户信息为空，登录失败
                                    if (null == userInfo)
                                    {
                                        loginPageTips.setText("用户信息为null");
                                    }
                                    // 使用华为账号登录且成功，进行accessToken验证
                                    else if ("1".equals((String)userInfo.get("loginStatus")))
                                    {
                                        loginPageTips.setText("使用华为账号登录，进行accessToken校验");
                                        
                                        // 进行accessToken校验
                                        Map<String, String> param = new HashMap<String, String>();
                                        param.put("accessToken", (String)userInfo.get("accesstoken"));
                                        
                                        // 此处禁用返回键，防止校验accessToken完成前退出当前Activity，CP可以用等待框等其他方式处理
                                        // 校验accessToken完成以后恢复返回键可用
                                        isBackKeyEnable = false;

                                        ReqTask checkAccessToken = new ReqTask(new Delegate()
                                        {
                                            
                                            @Override
                                            public void execute(String ret)
                                            {
                                                /*
                                                 * 向服务端发起校验accessToken的请求，服务端向华为https://api.vmall.com/rest.
                                                 * php进行校验accessToken，并返回校验结果
                                                 * 由于没有部署最终的服务端，所以这里写死一个校验结果，服务端代码参考华为Demo
                                                 */
                                                ret = "200";
                                                TextView loginPageTips = (TextView)findViewById(R.id.page1);
                                                if ("200".equals(ret))
                                                {
                                                    loginPageTips.setText("验证accessToken成功，进入游戏");
                                                    Intent goInGame = new Intent(MainActivity.this, GameActivity.class);
                                                    startActivity(goInGame);
                                                }
                                                else
                                                {
                                                    loginPageTips.setText("验证accessToken失败");
                                                }
                                                
                                                // 校验accessToken完成以后恢复返回键可用
                                                isBackKeyEnable = true;

                                            }
                                        }, param, GlobalParam.VALID_TOKEN_ADDR);
                                        checkAccessToken.execute();
                                        
                                    }
                                }
                                
                            });
                        
                        DebugConfig.d(TAG, "OpenSDK init retCode is:" + retCode);
                        
                        // 初始化成功，进行登录调用
                        if(RetCode.SUCCESS == retCode)
                        {
                            OpenSDK.start();
                        }
                    }
                }, null, GlobalParam.GET_BUOY_PRIVATE_KEY);
                getBuoyPrivate.execute();
                
                break;
            default:
                break;
        }
        
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if (keyCode == KeyEvent.KEYCODE_BACK)
        {
            if (isBackKeyEnable)
            {
                return super.onKeyDown(keyCode, event);
            }
            else
            {
                return true;
            }

        }
        return super.onKeyDown(keyCode, event);
    }

}
