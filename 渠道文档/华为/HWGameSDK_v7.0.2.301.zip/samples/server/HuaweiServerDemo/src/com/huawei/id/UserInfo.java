package com.huawei.id;

public class UserInfo
{
    public String userID;
    
    public String getUserID()
    {
        return userID;
    }

    public void setUserID(String userID)
    {
        this.userID = userID;
    }

    public String getUserName()
    {
        return userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getLanguageCode()
    {
        return languageCode;
    }

    public void setLanguageCode(String languageCode)
    {
        this.languageCode = languageCode;
    }

    public int getUserState()
    {
        return userState;
    }

    public void setUserState(int userState)
    {
        this.userState = userState;
    }

    public int getUserValidStatus()
    {
        return userValidStatus;
    }

    public void setUserValidStatus(int userValidStatus)
    {
        this.userValidStatus = userValidStatus;
    }

    public String userName;
    
    public String languageCode;
    
    public int userState;
    
    public int userValidStatus;
}
