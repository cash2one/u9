/** Automatically generated file. DO NOT MODIFY */
package com.doupo.ewan.xmw;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}