sdk 简单文档

[POST] ~/api/oauth/authorize 用于登陆用户获取authorize_code
GET参数:
	client_id sdk的应用id
	state 用于验证的唯一值
	response_type 定值code
POST参数:
	username 用户名
	password 密码
返回:
	authorize_code 用于交换access_token 1分钟有效
	authorize_token 用于交换authorize_code 14天有效
	state 用于握手验证 

[GET] ~/api/oauth/authorization 用于获取authorize_code 当没有用户登陆时使用
GET参数:
	client_id sdk的应用id
	state 用于验证的唯一值
	response_type 定值code
返回:
	authorize_code 用于交换access_token 1分钟有效
	state 用于握手验证

[GET] ~/api/oauth/authorize_token 用于做自动登陆 获取authorize_code
GET参数:
	authorize_token 用于交换authorize_code 每次调用本接口 有效期更新
返回:
	authorize_code 用于交换access_token 1分钟有效
	authorize_token 用于交换authorize_code 14天有效

[POST] ~/api/oauth/access_token 用于交换access_token 笑话api sdk涵盖的功能
POST参数:
	grant_type 定值 authorization_code
	code authorization_code
	client_id 笑话sdk的client_id

 [POST] ~/api/oauth/token 用于交换access_token 适用于第三方游戏服务器 使用sdk 的server端调用
POST参数:
	grant_type 定值 authorization_code
	code authorization_code
	client_id 游戏的client_id
	client_secret 游戏的client_secret

[GET] ~/api/user/me 用于获取当前用户的信息 未验证用户而获取的access_token将得到404
GET参数:
	access_token 接入token

[GET] ~/api/user/create 用于创建新用户
POST参数:
	username 6-18位 唯一
	password 6-18位

[POST] ~/api/pay/create 用于创建订单
GET参数:
access_token 接入token
POST参数:
app_order_id 游戏构造的订单id 会传回 会参与签名
app_subject 游戏构造的订单名称 会传回 会参与签名
app_description 游戏构造的订单描述 会传回 会参与签名
amount 订单金额 不会传回 会参与签名
notify_url 支付完成后回掉的url 不会传回 会参与签名
payment	[enum: alipay ] 枚举 支付方式 不会传回 会参与签名
intent jsonString 构造不同支付方式传入的信息(待定) 不会传回 会参与签名
不够再加
sign_type 暂时定值md5 以后根据需求增加其他算法
sign 签名 你懂的

[POST] ~/notify_url 支付结果通知 发送到游戏server
app_order_id
app_subject
app_description
amount
(sdk)order_id
flag
sign_type
sign
sign_return 

[GET] ~/api/pay/verification 订单查询核实 用于游戏服务器查询订单
app_order_id 游戏订单的id
amount 订单的金额
order_id sdk订单的id
sign_type 订单的签名类型
sign 订单的签名
sign_return 订单签名的返回签名

client_id
client_secret

返回:
{status:invalid} 未找到该订单
{status:success} 该订单已成功
{status:failed} 该订单已失败
{status:canceled} 该订单已取消
{status:processing} 该订单正在处理中


