package com.example.xmwsdk_dome;

import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.doupo.ewan.xmw.R;
import com.xmwsdk.asynchttp.AsyncHttpConnection;
import com.xmwsdk.asynchttp.StringResponseHandler;
import com.xmwsdk.asynchttp.support.ParamsWrapper;
import com.xmwsdk.control.XmwMatrix;
import com.xmwsdk.data.XmwProtocolKeys;
import com.xmwsdk.data.XmwTimeData;
import com.xmwsdk.inface.XmwIDispatcherCallback;
import com.xmwsdk.model.PayInfo;
import com.xmwsdk.view.ConAlertDialog;

public class MainActivity2 extends Activity {

	public Context con;
	public String token = "", refresh_token;
	public int user_id;
	public String client_id;
	// public String notify_url = "http://demo.xmwan.com/notify.php";
	/**
	 * 自己客户端服务器地址。 用服务器访问SDK 服务器获取access_token
	 */
	public String access_token_url = "http://demo.xmwan.com/oauth2.php";

	public String user_me_url = XmwTimeData.getInstance().ohost + "/users/me";

	/**
	 * 自己客户端服务器地址。 用服务器访问SDK 服务器获取serial
	 */
	public String purchases_url = "http://demo.xmwan.com/purchase.php";
	public Handler handler;
	private PayInfo payinfo;
	boolean island = false;
	LinearLayout landview;
	LinearLayout gameview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);
		Intent intent = this.getIntent();
		Bundle bundle = intent.getExtras();
		// 登录的 LinearLayout
		landview = (LinearLayout) findViewById(R.id.landview);
		// 商品购买 LinearLayout
		gameview = (LinearLayout) findViewById(R.id.gameview);

		if (bundle.getBoolean(XmwProtocolKeys.isLandScape)) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			landview.setBackgroundResource(R.drawable.aaab);
			gameview.setBackgroundResource(R.drawable.aaad);
			island = true;
		} else {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
			landview.setBackgroundResource(R.drawable.aaaa);
			gameview.setBackgroundResource(R.drawable.aaac);
			island = false;
		}
		
		con = this;
		handler = createHandler();

		// 登录窗口
		Button login = (Button) findViewById(R.id.login);
		login.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				doLogin(island);
			}
		});

		// 支付窗口
		Button pay = (Button) findViewById(R.id.pay);
		pay.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (token.equalsIgnoreCase("")) {
					Message msg = new Message();
					msg.what = 1;
					msg.obj = "请先登录";
					handler.sendMessage(msg);
				} else {
					getpurchases();
				}
			}
		});
		// 支付窗口
		Button aaa = (Button) findViewById(R.id.aaa);
		aaa.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				doLogin(island);
			}
		});
		// application package 名字
		XmwMatrix.initxmw(con, "com.doupo.ewan.xmw");
		// XmwMatrix.initxmw(con, "");
		dologo();
		
		
		
	}

	private Handler createHandler() {
		Handler handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					landview.setVisibility(View.GONE);
					gameview.setVisibility(View.VISIBLE);
					Toast.makeText(con, (String) msg.obj, Toast.LENGTH_SHORT)
							.show();
					break;
				case 3:
					Toast.makeText(con, (String) msg.obj, Toast.LENGTH_SHORT)
							.show();
					break;
				}
			}
		};
		return handler;
	}

	private void dologo() {
		XmwMatrix.invokelogo(con);
	}

	/**
	 * 
	 * @param transparent
	 *            透明，全屏
	 * @param isLandScape
	 *            横屏，竖屏
	 */
	public void doLogin(boolean isLandScape) {
		XmwMatrix.invokeLogin(con, logincallback, isLandScape);// 无背景登陆
		// XmwMatrix.invokeLogin(con, logincallback,
		// isLandScape,XmwProtocolKeys.noTransParent);//有背景登陆
	}

	/**
	 * 
	 * 
	 * @param payinfo
	 * @param callback
	 */
	public void doPay() {
		XmwMatrix.invokePay(con, paycallback, payinfo);
	}

	// 登录回调
	public XmwIDispatcherCallback logincallback = new XmwIDispatcherCallback() {

		@Override
		public void onFinished(int error_code, String data) {
			if (error_code == 99) {
				// 用户取消登录
				return; 
			}
			try {
				JSONObject json = new JSONObject(data);
				String auth_code = json.optString("authorization_code", "");
				if (!"".equalsIgnoreCase(auth_code)) {
					getAccessToken(auth_code);
				}

			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
	};

	// 支付回调
	public XmwIDispatcherCallback paycallback = new XmwIDispatcherCallback() {
		@Override
		public void onFinished(int code, String data) {
			System.out.println("code:" + code + " data:" + data);
			if (code == 99) {
				// 用户取消支付或支付失败
				return;
			} else if (code == 1) {
				// 支付正在处理，充值卡重置可能比较慢 支付完成后会向服务器返回充值结果
				return;
			} else if (code == 0) {
				// 支付成功
				Message msg = new Message();
				msg.what = 3;
				msg.obj = "支付成功！";
				handler.sendMessageDelayed(msg, 1000);
				return;
			}
		}
	};

	/*
	 * grant_type 定值 authorization_code code authorization_code client_id
	 * 游戏的client_id client_secret 游戏的client_secret 客户端在获取游戏信息失败时请重新获取
	 */
	public void getAccessToken(String code) {
		Log.i("MainActivity2", "code:----->" + code);
		progress();
		AsyncHttpConnection http = AsyncHttpConnection.getInstance();
		ParamsWrapper params = new ParamsWrapper();
		if (!"".equalsIgnoreCase(code)) {
			params.put("grant_type", "authorization_code");
			params.put("code", code);
		}
		Log.i("MainActivity2", "access_token_url:----->" + access_token_url);
		http.get(access_token_url, params, new StringResponseHandler() {
			@Override
			public void onResponse(String content, URL url, int code) {
				System.out.println("content:" + content);
				JSONObject j;
				try {
					j = new JSONObject(content); 
					token = j.optString("access_token");
					//将access_token回传给SDK，用于悬浮框用户信息的展示 （XMWSDK_V2.2.0更新，重要）
					XmwMatrix.xmw_settoken(con,token);

					System.out.println("pagename:"+XmwTimeData.getInstance().PackageName);
	
					Log.i("MainActivity2", "j----->" + j.toString());

					getUser_Me();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					disprogress();
					Message msg = new Message();
					msg.what = 1;
					msg.obj = "获取用户账号失败";
					handler.sendMessage(msg);
					System.out.println("url+" + url);
				}
			}

		});
	}
 
	public void getpurchases() {
		progress();
		EditText a = (EditText) findViewById(R.id.payamount);
		String amount = a.getText().toString();
		AsyncHttpConnection http = AsyncHttpConnection.getInstance();
		ParamsWrapper params = new ParamsWrapper();
		params.put("access_token", token);
		params.put("app_user_id", "游戏账号");
		params.put("amount", amount);
		params.put("app_subject", "宝石");
		http.get(purchases_url, params, new StringResponseHandler() {
			@Override
			public void onResponse(String content, URL url, int code) {
				System.out.println("content:" + content);
				JSONObject j;
				try {
					j = new JSONObject(content);
					String error = j.optString("error_description", "");
					if (error.equalsIgnoreCase("")) {
						String serial = j.optString("serial");
						String amount = j.optString("amount");
						String app_subject = j.optString("app_subject");
						payinfo = new PayInfo();
						payinfo.setPurchase_serial(serial);
						payinfo.setAmount(amount);// 金额
						payinfo.setApp_subject(app_subject);// 商品名称
						doPay();
					} else {
						disprogress();
						Message msg = new Message();
						msg.what = 1;
						msg.obj = error;
						handler.sendMessage(msg);
					}
					disprogress();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					disprogress();
					Message msg = new Message();

					msg.what = 1;
					msg.obj = "申请消费订单失败";
					handler.sendMessage(msg);
					System.out.println("url+" + url);
				}
			}
		});
	}

	// 使用access_token获取SDK用户信息的访问地址 可以在服务器调用此链接也可以在客户端服务器调用以换取和客户端用户信息信息匹配的信息
	// 客户端在获取游戏信息失败时请重新获取
	public void getUser_Me() {
		AsyncHttpConnection http = AsyncHttpConnection.getInstance();
		String url = user_me_url + "?access_token=" + token;
		Log.i("MainActivity2", "url:----->" + url);
		http.get(url, new StringResponseHandler() {
			@Override
			public void onResponse(String content, URL url, int code) {
				System.out.println("content:" + content);
				JSONObject json;
				try {
					// 具体返回内容见打印信息
					json = new JSONObject(content);
					String error = json.optString("error", "");
					if (error == "") {
						String id = json.optString("xmw_open_id", "");
						String nickname = json.optString("nickname", "");
						System.out.println("avata1r:" + nickname);
						Message msg = new Message();
						msg.what = 1;
						msg.obj = content;
						handler.sendMessage(msg);
					} else {
						Message msg = new Message();
						msg.what = 1;
						msg.obj = "获取用户资料失败";
						handler.sendMessage(msg);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				disprogress();
			}

		});
	}

	// 获取论坛地址
	public void getBBS_link() {
		progress();
		AsyncHttpConnection http = AsyncHttpConnection.getInstance();
		http.getbbslink(new StringResponseHandler() {
			@Override
			protected void onResponse(String content, URL url, int code) {
				// TODO Auto-generated method stub
				switch (code) {
				case 200:
					try {
						JSONObject jsonObject;
						jsonObject = new JSONObject(content);
						// bbslink 即为论坛地址
						String bbslink = jsonObject.optString("bbs_link", "");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case 1001:// 超时
					break;
				case 1002:// 网络连接失败
					break;
				default:
					break;
				}
				disprogress();
			}
		});
	}

	ProgressDialog progressDialog = null;

	private void progress() {
		progressDialog = new ProgressDialog(MainActivity2.this);
		// 设置进度条风格，风格为圆形，旋转的
		progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		progressDialog.setMessage("获取游戏数据");
		progressDialog.setIndeterminate(true);
		progressDialog.setCancelable(false);
		try {
			progressDialog.show();
		} catch (Exception e) {

		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			close();
			return true;
		}
		return false;
	}

	/**
	 * 退出方法
	 */
	private void close() {
	
		XmwMatrix.exitXMW(con);
	}

	private void disprogress() {
		if (progressDialog != null) {
			if (progressDialog.isShowing())
				progressDialog.dismiss();
		}
	}

	@Override
	protected void onDestroy() {
		disprogress();
		super.onDestroy();
	}
}
