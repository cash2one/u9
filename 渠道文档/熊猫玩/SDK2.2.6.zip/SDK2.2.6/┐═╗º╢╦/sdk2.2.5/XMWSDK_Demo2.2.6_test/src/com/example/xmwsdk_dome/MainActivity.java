package com.example.xmwsdk_dome;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.doupo.ewan.xmw.R;
import com.xmwsdk.data.XmwProtocolKeys;

/**
 * demo入口页面
 */
public class MainActivity extends Activity {

	public Context con;
	// 判断横屏，竖屏标识
	boolean island = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		con = this;

		// 横屏模式
		Button landland = (Button) findViewById(R.id.landland);
		landland.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				island = true;
				Intent intent;
				Bundle bundle = new Bundle();
				bundle.putBoolean(XmwProtocolKeys.isLandScape, island);
				intent = new Intent(con, MainActivity2.class);
				intent.putExtras(bundle);
				con.startActivity(intent);
			}
		});
		// 竖屏模式
		Button portland = (Button) findViewById(R.id.portland);
		portland.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				island = false;
				Intent intent;
				Bundle bundle = new Bundle();
				bundle.putBoolean(XmwProtocolKeys.isLandScape, island);
				intent = new Intent(con, MainActivity2.class);
				intent.putExtras(bundle);
				con.startActivity(intent);
			}
		});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			System.exit(0);
			return true;
		}
		return false;
	}
}
