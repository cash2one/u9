package com.xmw.util;

import java.util.Comparator;

import com.xmw.model.KeyAndValue;

public class ComparatorByKey implements Comparator{   
	       public int compare(Object o1, Object o2) {   
	            KeyAndValue  m1 = (KeyAndValue)o1;   
	            KeyAndValue  m2 = (KeyAndValue)o2;   
	            String i1 = m1.getKey();   
	            String i2 = m2.getKey();   
	           return i1.compareTo(i2);   
	       }          
	    } 