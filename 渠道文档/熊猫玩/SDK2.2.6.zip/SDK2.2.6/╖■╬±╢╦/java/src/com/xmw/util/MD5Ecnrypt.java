package com.xmw.util;

  import java.security.MessageDigest;

public class MD5Ecnrypt {        
	
    public static String EncodeMD5Hex(String text) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(text.getBytes("UTF-8"));
        byte[] digest = md.digest();    
        StringBuffer md5 = new StringBuffer();
        for (int i = 0; i < digest.length; i++) {
            md5.append(Character.forDigit((digest[i] & 0xF0) >> 4, 16));
            md5.append(Character.forDigit((digest[i] & 0xF), 16));
        }
        return md5.toString();
    }


    public static String EncodeMD5ASCII(String text) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(text.getBytes("utf-8"));
        byte[] digest = md.digest();        
        return new String(digest,"utf-8");        
    }


    public static String DecodeMD5Hex(String text) throws Exception {        
        byte[] digest = text.getBytes();        
        StringBuffer md5 = new StringBuffer();
        for (int i = 0; i < digest.length; i++) {
            md5.append(Character.forDigit((digest[i] & 0xF0) >> 4, 16));
            md5.append(Character.forDigit((digest[i] & 0xF), 16));
        }
        return md5.toString();    
    }


    public static Boolean CheckPSW(String a,String b) throws Exception
    {        
        String strone=EncodeMD5ASCII(a);            
        return strone.equals(b);
    }
}