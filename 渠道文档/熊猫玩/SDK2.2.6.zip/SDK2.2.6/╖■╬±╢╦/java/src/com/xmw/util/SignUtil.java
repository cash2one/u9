package com.xmw.util;


import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.List;

import com.xmw.model.KeyAndValue;



public class SignUtil {

		public String Encrypt(String prestr)
		{
			return Encrypt(prestr, "md5");
		}

	
		public String Encrypt(String prestr, String encrypt_type)
		{
			try {
				return MD5Ecnrypt.EncodeMD5Hex(prestr);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		public static String getMD5String(String str) 
	    { 
	        try 
	        { 
	            byte[] res=str.getBytes(); 
	            MessageDigest md = MessageDigest.getInstance("MD5".toUpperCase()); 
                byte[] result=md.digest(res); 

	            for(int i=0;i<result.length;i++) 
	            { 
	                md.update(result[i]); 
	            } 
	            byte[] hash=md.digest(); 

	            StringBuffer d=new StringBuffer(""); 
	            for(int i=0;i<hash.length;i++) 
	            { 
	                int v=hash[i] & 0xFF; 
	                 if(v<16) d.append("0"); 
	                   d.append(Integer.toString(v,16).toUpperCase()+""); 
	            } 
	                return d.toString(); 
	        } 
	        catch(Exception e) 
	        { 
	            return ""; 
	        } 
	} 

		
		private static String getDigest(String content, String algorithm,String charset) {

            try {

                     byte[] plainText = content.getBytes(charset);

                     MessageDigest messageDigest = MessageDigest.getInstance(algorithm);

                     //messageDigest.update(plainText);

                     byte[] digest = messageDigest.digest(plainText);

                     return byte2hex(digest);

            } catch (NoSuchAlgorithmException ex) {

                    System.out.println("Error digest algorithm: " + algorithm);

            } catch (UnsupportedEncodingException e) {

            	System.out.println("Error digest algorithm: " + algorithm);

            }

            return null;

  }



  private static String byte2hex(byte[] b) {

            StringBuilder hs = new StringBuilder();

            String stmp = "";

            for (int n = 0; n < b.length; n++) {

                     stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));

                     if (stmp.length() == 1) {

                              hs.append("0" + stmp);

                     } else {

                              hs.append(stmp);

                     }

            }

           return hs.toString();

  }

		public static String Sign(String prestr, String secret)
		{
			return Sign(prestr, secret, "md5");
		}


		public static String Sign(String prestr, String secret, String sign_type)
		{
			return Sign(prestr, secret, sign_type, "utf-8");
		}


		public static String Sign(String prestr,String secret, String sign_type, String _input_charset)
		{
			///
			//prestr = secret + prestr + secret;
			StringBuffer s=new StringBuffer();
		//	s.append(secret);
			s.append(prestr);
			s.append("&client_secret=");
			s.append(secret);
			prestr=s.toString();
			System.out.println("prestr:"+prestr);
			String str;
			try {
			//	str= new MD5_Encoding().getMD5ofStr(prestr);
				str = MD5Ecnrypt.EncodeMD5Hex(prestr);
				//str=getMD5String(prestr);
				//str=getDigest(prestr,sign_type,_input_charset);
				return str;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		}

		public static String Sign(List<KeyAndValue> parameters, String secret)
		{
			return Sign(parameters, secret, "md5");
		}

		public static String Sign(List<KeyAndValue> parameters, String secret, String sign_type)
		{
			return GoSign(parameters, secret);
		}


		public static String GoSign(List<KeyAndValue> parameters, String secret)
		{
			for(KeyAndValue k:parameters){
				k.setKey(k.getKey().toLowerCase());
				k.setValue(k.getValue().toLowerCase());
			}

			ComparatorByKey com=new ComparatorByKey();
			Collections.sort(parameters, com);   

			StringBuilder sb = new StringBuilder();

			for(KeyAndValue k:parameters){
				sb.append(k.getKey()).append(k.getValue());
			}
			
			
			return Sign(Tools.CreateLinkString(parameters), secret);
		}
		

}
