package com.xmw.demo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.xmw.model.KeyAndValue;
import com.xmw.util.HttpRequestParser;
import com.xmw.util.SignUtil;
import com.xmw.util.Tools;


/**
 * *  熊猫玩开放平台 SDK调用示例 用户验证 创建消费订单 验证消费订单
 * 
 *  本示例仅供参考，不建议直接使用。
 *  请根据游戏方具体业务及应用环境参照本示例对接。
 * @author Qindi
 */
public class HttpServerDemo {

	private static String XMW_CLIENT_ID = "testclient";//游戏客户端号
	private static String XMW_CLIENT_SECRET = "testpass";//游戏客户端密钥
	private static String ACESSTOKEN_URL = "/v2/oauth2/access_token?";//获取token接口
	private static String PURCHASES_URL = "/v2/purchases?";//创建消费订单接口
	private static String CHECK_PURCHASES_URL = "v2/purchases/verify?";//验证消费订单接口
	/*
	 * 测试平台地址: http://open.dev.xmwan.com/
	 * 正式环境地址：http://open.xmwan.com/
	 */
	private static String XMW_SERVER = "http://open.dev.xmwan.com/";

	/**
	 * java 测试HttpServer
	 * 获取测试  authorization_code ：POST  ：  http://open.dev.xmwan.com/v2/oauth2/authorize?account=blindshadow&password=yangchao&client_id=testclient
	 * 测试获取token接口：POST ：http://127.0.0.1:8686/gettoken?code=a5529c0b62581c25d2a250981f898a5323cfc770
	 * 测试创建消费订单接口: POST :  http://127.0.0.1:8686/purchase?amount=10&app_order_id=testorder1&app_user_id=112&notify_url=http%3A%2F%2Fwww.xmwan.com&timestamp=1234567&access_token=6bd78457098cfad2f76fbeb908c13900049bfbf2 
	 * 测试验证消费订单接口: POST :  http://127.0.0.1:8686/checkpurchase?amount=10&app_order_id=testorder1&serial=20140923165327068112
	 */
	public static void main(String[] args) throws IOException {
		HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 8686), 0);
		server.createContext("/gettoken", new MyOauth2());
		server.createContext("/purchase", new MyPurchases());
		server.createContext("/checkpurchase", new CheckPurchases());
		server.setExecutor(null); 
		server.start();
		System.out.println("http server start！");
	}

	public static class MyOauth2 implements HttpHandler {
		@Override
		public void handle(HttpExchange httpExchange) throws IOException {
			String method = httpExchange.getRequestMethod();
			if (method.equalsIgnoreCase("POST")) {
				URI uri = httpExchange.getRequestURI();
				String pro = httpExchange.getProtocol();
				Headers respons = httpExchange.getResponseHeaders();
				respons.set("Content-Type", "application/json; charset=utf-8");
				HttpServletRequest request = HttpRequestParser.parse(uri.toString());
				String code = request.getParameter("code");
				String data = "";
				if (!"".equalsIgnoreCase(code)) {
					//调用获取token接口
					data = getTokenByCode(code);
				} else {
					data = "needcode";
				}
				httpExchange.sendResponseHeaders(200, data.length());
				OutputStream out = httpExchange.getResponseBody();
				out.write(data.getBytes());
				out.close();
			}
		}
	}

	public static class MyPurchases implements HttpHandler {
		@Override
		public void handle(HttpExchange httpExchange) throws IOException {

			System.out.println("token!!!");
			String method = httpExchange.getRequestMethod();
			if (method.equalsIgnoreCase("POST")) {
				URI uri = httpExchange.getRequestURI();
				String pro = httpExchange.getProtocol();
				Headers respons = httpExchange.getResponseHeaders();
				respons.set("Content-Type", "application/json; charset=utf-8");
				HttpServletRequest request = HttpRequestParser.parse(uri
						.toString());
				String code = request.getParameter("code");
				System.out.println("code:" + code);
				//调用创建订单接口
				String data = XMWPurchases(request.getParameter("amount"),
						request.getParameter("app_order_id"),
						request.getParameter("app_user_id"),
						request.getParameter("notify_url"),
						request.getParameter("timestamp"),
						request.getParameter("access_token"));
				httpExchange.sendResponseHeaders(200, data.length());
				OutputStream out = httpExchange.getResponseBody();
				out.write(data.getBytes());
				out.close();
			}
		}
	}

	public static class CheckPurchases implements HttpHandler {
		@Override
		public void handle(HttpExchange httpExchange) throws IOException {

			System.out.println("token!!!");
			String method = httpExchange.getRequestMethod();
			if (method.equalsIgnoreCase("POST")) {
				URI uri = httpExchange.getRequestURI();
				String pro = httpExchange.getProtocol();
				Headers respons = httpExchange.getResponseHeaders();
				respons.set("Content-Type", "application/json; charset=utf-8");
				HttpServletRequest request = HttpRequestParser.parse(uri.toString());
				String code = request.getParameter("code");
				System.out.println("code:" + code);
				//调用验证订单接口
				String data = CheckPurchases(request.getParameter("amount"),
						request.getParameter("app_order_id"),
						request.getParameter("serial"));
				httpExchange.sendResponseHeaders(200, data.length());
				OutputStream out = httpExchange.getResponseBody();
				out.write(data.getBytes());
				out.close();
			}
		}
	}

	

	/**
	 * 请求熊猫玩服务器用authorization_code换取token
	 * @param code
	 * @return
	 */
	public static String getTokenByCode(String code) {

		HttpURLConnection connection = null;
		InputStreamReader in = null;
		String result = "";
		StringBuilder sb = new StringBuilder();
		// 服务器地址
		sb.append(XMW_SERVER);
		// 对应接口地址
		sb.append(ACESSTOKEN_URL);
		/*
		 * client_id  游戏的客户端号 
		 * client_secret  游戏的客户端密钥 
		 * grant_type    获取授权码的依据类型可传refresh_token 和 authorization_code 两种
		 * code  当使用authorization_code 方式获取授权码时, 本参数必传并填入 authorization_code 的内容
		 * refresh_token 当使用 refresh_token 方式获取授权码时, 本参数必传并填入 refresh_token的内容
		 */
		sb.append("client_id=");
		sb.append(XMW_CLIENT_ID);
		sb.append("&client_secret=");
		sb.append(XMW_CLIENT_SECRET);
		sb.append("&grant_type=");
		sb.append("authorization_code");
		sb.append("&code=");
		sb.append(code);
		System.out.println("url:" + sb.toString());
		URL url;
		try {
			url = new URL(sb.toString());
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setUseCaches(false);
			int response_code = connection.getResponseCode();
			if (response_code == 200) {
				in = new InputStreamReader(connection.getInputStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();
			} else {
				System.out.println("http code:" + response_code);
				in = new InputStreamReader(connection.getErrorStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();

			}
		} catch (Exception e) {
			result = "get token fail";
			e.printStackTrace();
		}
		return result;

	}

	/**
	 * 请求熊猫玩服务器生成订单
	 * @param amount
	 * @param app_order_id
	 * @param app_user_id
	 * @param notify_url
	 * @param timestamp
	 * @param token
	 * @return
	 */
	public static String XMWPurchases(String amount, String app_order_id,
			String app_user_id, String notify_url, String timestamp,
			String token) {

		HttpURLConnection connection = null;
		InputStreamReader in = null;
		String result = "";
		StringBuilder sb = new StringBuilder();
		// 服务器地址
		sb.append(XMW_SERVER);
		// 对应接口地址
		sb.append(PURCHASES_URL);
		/*
		 * access_token		登录授权码
		 * client_id	游戏的客户端号
		 * client_secret		游戏的客户端密钥
		 * app_order_id		订单号. 会参与签名
		 * app_user_id	用户id. 会参与签名
		 * app_subject		订单标题. 会参与签名
		 * app_description		订单描述. 会参与签名
		 * app_ext1	订单额外参数. 会参与签名
		 * app_ext2	订单额外参数. 会参与签名
		 * amount 	订单金额. 会参与签名
		 * notify_url		订单完成后通知到游戏服务器的回调地址. 会参与签名
		 * timestamp		订单创建时的时间戳. 会参与签名
		 * sign	参数签名
		 */
		List<KeyAndValue> paras = new ArrayList<KeyAndValue>();
		paras.add(new KeyAndValue("amount", amount));
		paras.add(new KeyAndValue("app_order_id", app_order_id));
		paras.add(new KeyAndValue("app_user_id", app_user_id));
		paras.add(new KeyAndValue("notify_url", notify_url));
		paras.add(new KeyAndValue("timestamp", timestamp));
		String sign = SignUtil.GoSign(paras, XMW_CLIENT_SECRET);
		paras.add(new KeyAndValue("sign", sign));
		paras.add(new KeyAndValue("access_token", token));
		paras.add(new KeyAndValue("client_id", XMW_CLIENT_ID));
		paras.add(new KeyAndValue("client_secret", XMW_CLIENT_SECRET));
		String data = Tools.CreateLinkString(paras);

		sb.append(data);
		System.out.println("url:" + sb.toString());
		URL url;
		try {
			url = new URL(sb.toString());

			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setUseCaches(false);

			int response_code = connection.getResponseCode();

			if (response_code == 200) {
				in = new InputStreamReader(connection.getInputStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();
			} else {
				System.out.println("http code:" + response_code);
				in = new InputStreamReader(connection.getErrorStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}


	/**
	 * 请求熊猫玩服务器验证订单
	 * @param amount
	 * @param app_order_id
	 * @param serial
	 * @return
	 */
	public static String CheckPurchases(String amount, String app_order_id,String serial) {

		HttpURLConnection connection = null;
		InputStreamReader in = null;
		String result = "";
		StringBuilder sb = new StringBuilder();
		// 服务器地址
		sb.append(XMW_SERVER);
		// 对应接口地址
		sb.append(CHECK_PURCHASES_URL);
		
		/**
		 * client_id	游戏的客户端号
		 * client_secret		游戏的客户端密钥
		 * serial		消费订单的订单号. 会参与签名
		 * app_order_id		游戏服务器传入的订单号. 会参与签名
		 * amount 	订单金额. 会参与签名
		 * sign	 参数签名
		 */
		List<KeyAndValue> paras = new ArrayList<KeyAndValue>();
		paras.add(new KeyAndValue("amount", amount));
		paras.add(new KeyAndValue("app_order_id", app_order_id));
		paras.add(new KeyAndValue("serial", serial));
		String sign = SignUtil.GoSign(paras, XMW_CLIENT_SECRET);
		paras.add(new KeyAndValue("sign", sign));
		paras.add(new KeyAndValue("client_id", XMW_CLIENT_ID));
		paras.add(new KeyAndValue("client_secret", XMW_CLIENT_SECRET));
		String data = Tools.CreateLinkString(paras);
		sb.append(data);
		System.out.println("url:" + sb.toString());
		URL url;
		try {
			url = new URL(sb.toString());
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setUseCaches(false);
			int response_code = connection.getResponseCode();
			if (response_code == 200) {
				in = new InputStreamReader(connection.getInputStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();
			} else {
				System.out.println("http code:" + response_code);
				in = new InputStreamReader(connection.getErrorStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				StringBuffer strBuffer = new StringBuffer();
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					strBuffer.append(line);
				}
				result = strBuffer.toString();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

}