package com.xmw.util;

import java.util.List;

import com.xmw.model.KeyAndValue;

public class Tools {

	/**
	 * 键值转换
	 * @param dicArray
	 * @return
	 */
    public static String CreateLinkString(List<KeyAndValue> dicArray)
    {
        StringBuilder prestr = new StringBuilder();
        for(KeyAndValue k:dicArray){
        	prestr.append(k.getKey() + "=" + k.getValue() + "&");
        }
        int nLen = prestr.length();
        prestr.delete(nLen - 1, nLen);
        return prestr.toString();
    }
	
}
