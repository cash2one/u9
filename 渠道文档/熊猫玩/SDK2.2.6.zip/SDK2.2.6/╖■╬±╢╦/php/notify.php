<?php

/*
|--------------------------------------------------------------------------
| 熊猫玩开放平台 SDK调用示例 订单通知接收
|--------------------------------------------------------------------------
|
| 本示例仅供参考，不建议直接使用。
| 请根据游戏方具体业务及应用环境参照本示例对接。
|
*/

require_once 'common.php';

try
{
	$purchase = new XMWPurchase(XMW_CLIENT_ID, XMW_CLIENT_SECRET);
	header('Content-Type: application/json; charset=utf-8');

	// 验证参数签名
	if(!$purchase->checkSign($_REQUEST))
	{
        throw new XMWException(XMWException::CODE_PARAM_ERROR, '支付通知签名验证失败.');
	}

	// 请求熊猫玩平台服务器 验证订单状态
	$response = $purchase->verifyPurchase($_REQUEST);

	// 如果熊猫玩平台服务器返回该订单为成功状态
	if(is_array($response) && array_key_exists('status', $response) && $response['status'] === 'success')
	{
		// 执行游戏逻辑
		// TODO: 执行游戏逻辑，请允许重复接收通知。



		echo 'success';
		exit();
	}

	// 通知失败
	echo 'fail';
	exit();

}
catch(XMWException $exception)
{
	// 调试过程中可以使用以下错误描述来排查，但在生产环境中请务必返回字符串 'fail'
	/*
    echo json_encode(array(
        'error_description' => $exception->getMessage(),
    ));
    exit();
    */

    // 通知失败
	echo 'fail';
	exit();
}
