<?php

/*
|--------------------------------------------------------------------------
| 熊猫玩开放平台 SDK调用示例 用户验证
|--------------------------------------------------------------------------
|
| 本示例仅供参考，不建议直接使用。
| 请根据游戏方具体业务及应用环境参照本示例对接。
|
*/

require_once 'common.php';


try
{
	$oauth2 = new XMWOAuth2(XMW_CLIENT_ID, XMW_CLIENT_SECRET);
	header('Content-Type: application/json; charset=utf-8');

	$grantType = isset($_REQUEST['grant_type']) ?
		$_REQUEST['grant_type'] : 'authorization_code';

	if($grantType === 'authorization_code' && array_key_exists('code', $_REQUEST))
	{
		$data = $oauth2->getAccessTokenByCode($_REQUEST['code']);
	}
	elseif($grantType === 'refresh_token' && array_key_exists('refresh_token', $_REQUEST))
	{
		$data = $oauth2->getAccessTokenByRefreshToken($_REQUEST['refresh_token']);
	}
	else
	{
		throw new XMWException(XMWException::CODE_PARAM_ERROR);
	}

	echo json_encode($data);
}
catch(XMWException $exception)
{
    echo json_encode(array(
        'error_description' => $exception->getMessage(),
    ));
}
