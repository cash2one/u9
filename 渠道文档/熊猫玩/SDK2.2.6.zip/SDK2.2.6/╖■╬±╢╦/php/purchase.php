<?php

/*
|--------------------------------------------------------------------------
| 熊猫玩开放平台 SDK调用示例 订单创建
|--------------------------------------------------------------------------
|
| 本示例仅供参考，不建议直接使用。
| 请根据游戏方具体业务及应用环境参照本示例对接。
|
*/

require_once 'common.php';

try
{
	$purchase = new XMWPurchase(XMW_CLIENT_ID, XMW_CLIENT_SECRET);
	header('Content-Type: application/json; charset=utf-8');

	if(array_key_exists('access_token', $_REQUEST) && !empty($_REQUEST['access_token']))
	{
		$accessToken = $_REQUEST['access_token'];
	}
	else
	{
		throw new XMWException(XMWException::CODE_PARAM_ERROR);
	}


	// 构建订单信息.
	$data = array();

	// 获取当前发起订单的游戏用户
	if(array_key_exists('app_user_id', $_REQUEST) && !empty($_REQUEST['app_user_id']))
	{
		$data['app_user_id'] = $_REQUEST['app_user_id'];
	}
	else
	{
		throw new XMWException(XMWException::CODE_PARAM_ERROR);
	}

	// 处理游戏服务器及其客户端的通信.
	// 例如获取充值金额, 购买道具等.

	if(array_key_exists('amount', $_REQUEST) && !empty($_REQUEST['amount']))
	{
		$data['amount'] = $_REQUEST['amount'];
	}
	else
	{
		throw new XMWException(XMWException::CODE_PARAM_ERROR);
	}

	$data['app_subject'] = '游戏订单' . time();
	$data['app_description'] = '游戏订单' . time();

	// 游戏方生成的游戏订单号
	$data['app_order_id'] = '游戏订单' . time();

	// 游戏方的支付完成通知回调地址
	$data['notify_url'] = 'http://demo.dev.xmwan.com/notify.php';

	// 额外参数
	$data['app_ext1'] = '哦呵呵呵呵呵';
	$data['app_ext2'] = '啊哈';

	// 订单生成的时间戳
	$data['timestamp'] = time();

	// 根据游戏方的接口进行返回
	$purchase = $purchase->createPurchase($accessToken, $data);
	echo json_encode($purchase);
}
catch(XMWException $exception)
{
    echo json_encode(array(
        'error_description' => $exception->getMessage(),
    ));
}
