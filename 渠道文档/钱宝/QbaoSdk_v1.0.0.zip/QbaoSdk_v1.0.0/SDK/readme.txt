1.test_libs 测试SDK，测试阶段使用此文件下SDK jar包
2.libs 商用SDK,待游戏包体通过测试后，申请上线，才可使用此文件下SDK jar包
