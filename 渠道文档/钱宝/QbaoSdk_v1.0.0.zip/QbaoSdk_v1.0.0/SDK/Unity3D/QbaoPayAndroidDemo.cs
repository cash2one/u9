﻿using UnityEngine;
using System;
using System.Collections.Generic;

public class QbaoPayAndroidDemo : MonoBehaviour
{
	#if UNITY_ANDROID

	void Awake ()
	{
		if (Application.platform == RuntimePlatform.Android)
		{
			QbaoPayAndroid.Instance.InitializeApp("appCode", "loginNo", "Main Camera", "OnLoginResult");
		}
	}

	void Start ()
	{
		QbaoPayAndroidDemo.Pay("payInfo");
	}
	
	void OnLoginResult(String result)
	{ 
		Debug.Log("LoginResult="+result);
		String[] results = result.Split('|');
		Debug.Log("userId=" + results[0] + "resultCode=" + results[1]);
	}
	
	void OnPayResult(String result)
	{ 
		Debug.Log("PayResult="+result);
		String[] results = result.Split('|');
		Debug.Log("payCode=" + results[0] + "resultCode=" + results[1]);
	}
	
	void OnExitResult(String result)
	{ 
		Debug.Log("PayResult="+result);
		if("1".equals(result))
		{
			QbaoPayAndroid.Instance.ExitWithUI();
		} 
	}

	public static void Pay(String payInfo)
    {
       QbaoPayAndroid.Instance.pay(payInfo, "Main Camera", "OnPayResult");
    }
	#endif
}
