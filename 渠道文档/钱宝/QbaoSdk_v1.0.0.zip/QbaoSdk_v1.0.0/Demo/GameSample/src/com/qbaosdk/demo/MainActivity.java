package com.qbaosdk.demo;

import java.net.URLEncoder;
import java.util.Random;

import com.qbao.sdk.api.LoginResult;
import com.qbao.sdk.api.PayResult;
import com.qbao.sdk.api.QbaoSdk;
import com.sdk.util.RSACoder;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends ListActivity {
	
	static final String[] BUTTONS = new String[]{
		"00.购买道具", 
		"01.购买道具", 
		"02.购买道具", 
		"03.购买道具",
		"04.购买道具",
		"05.退出游戏"};
	
	public static char[] CHAR_TABLE_10 = "0123456789".toCharArray();
	
	public String rsa_private_key = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBANXpnN6W51yyK20I7rEJrEK8qRmwXxyIfi+egXAhfZWx+0JTd54lUJ6ukyW+85STpaN61DqwokpIZR/qGxmJKHkUabbncy505Wwbd6pvp5QIGk7m4ld+csBff/hP3Q4D0EVZdzDrGGERM0TA2MQu1r0AyPFNLaivxaj7gH6fbECXAgMBAAECgYAgov7zGxT7mJd1kEpSqoYkvIIUUEuCn/SYsVdQU1vEzh3mtbNnZowRWdNLjAG/5nL8KU5eEfsA2GDNaLtvvvR0lRDmfh0e1ILMOBhZHyJyplVbBucBXemsuvCcqH5fHvnf+iYOnJc3AfYPdbdOH6WEoC4AtIzlsQnO/BubNi9kkQJBAP963Ka3icAoJORcOpzXh7BamcBG3ZCQJyQ9FCCUuUiEg4wxiQKV+vdwku+a9j/4rENMweVVn01lN9OVCtQ7y98CQQDWWRbAWJao3or2Xo+pJIrMpmcvNX6QvfHgnpWblKLwRInO9gMwvRcWLKcfBywz88uEwmPtjPa4vzjbqQFoJKJJAkEA0u9ACy5yv4Llot47To/takADvetEuD0s9BCx84yXxjYS3sdvVgE66t25k7cgJgVNRWu0k4M0OhSeGUVvYXfVhQJAVD7DoGmxHUIKX/aehB4mp3SnjXh6/CyLinsJ1hI/UCu/9iXe7yMCleaK8LkC+JBTZyR33f/PYKFXmY39TY9IcQJAVHKUfLLyVlYdmDY8siT7elwc+IFvpl5PpdN8Q6sLzqkCHvxc65dj7rpbmWQ0VnmXdK0A5i8N8RAZXubIi7R+nA==";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 不显示程序的标题栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // 不显示系统的标题栏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        // 监听登录结果，游戏根据自身业务逻辑，使用钱宝游戏SDK提供的登录结果
        QbaoSdk.ILoginCallback loginCallback = new QbaoSdk.ILoginCallback() {
			
			@Override
			public void onResult(int resultCode, String userId, Object ogj) {
				switch (resultCode) {
				case LoginResult.SUCCESS:
					Toast.makeText(MainActivity.this, "用户登录成功>>uid=" +userId, Toast.LENGTH_SHORT).show();
					break;
				case LoginResult.CANCELLED://用户取消登录，此处游戏处理退出逻辑
					Toast.makeText(MainActivity.this, "用户取消登录", Toast.LENGTH_SHORT).show();
					MainActivity.this.finish();
					break;
				default:
					break;
				}
			}
		};
        //初始化钱宝SDK，包含弹出登录对话框，登录流程
        QbaoSdk.initSDK(MainActivity.this, "A0001076", getRandomNum(20), loginCallback);
        
		// 监听支付结果，游戏根据自身业务逻辑，使用移动游戏SDK提供的支付结果
		final QbaoSdk.IPayCallback payCallback = new QbaoSdk.IPayCallback() {
			@Override
			public void onResult(int resultCode, String propId, Object obj) {
				String result = "";
				switch (resultCode) {
				case PayResult.SUCCESS:
					result = "购买道具：[" + propId + "] 成功！";
					break;
				case PayResult.FAILED:
					result = "购买道具：[" + propId + "] 失败！" + obj.toString();
					break;
				default:
					result = "购买道具：[" + propId + "] 取消！";
					break;
				}
				Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
			}
		};
        
        setListAdapter(new ArrayAdapter<String>(this, R.layout.main_menu_item, BUTTONS));
		ListView lv = getListView();
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (position == 5) {
					exitGame();
				}else {
					try {
						//支付信息签名需由游戏服务器完成，此demo仅供参考
						String info = getPayInfo();
						info += "&signCode=" +RSACoder.sign(info.getBytes(), rsa_private_key);
						QbaoSdk.pay(MainActivity.this, info, payCallback);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				}
			});
    }
    
    //生成指定长度随机数
    public static String getRandomNum(int length) {
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int seed = random.nextInt(10);
			sb.append(String.valueOf(CHAR_TABLE_10[seed]));
		}
		return sb.toString();
	}
    
    //拼装计费信息参数
    private String getPayInfo() {
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("appCode=");
		sBuilder.append("A0001076");//应用编码
		sBuilder.append("&orderNo=");
		sBuilder.append(getRandomNum(20));//订单号,此参数最多20位，只能包含数字，支付成功会透传给游戏服务器
		sBuilder.append("&payCode=");
		sBuilder.append("C0000079");//道具编码
		sBuilder.append("&payNotifyUrl=");
		sBuilder.append(URLEncoder.encode("http://www.baidu.com"));//支付回调URL,支付处理后，将支付结果信息通知至此地址
		return new String(sBuilder);
	}
    
    //钱宝退出接口，包含退出UI
    private void exitGame() {
		QbaoSdk.exit(this, new QbaoSdk.IExitCallback() {
			
			@Override
			public void onConfirmExit() {
				MainActivity.this.finish();
			}
			
			@Override
			public void onCancelExit() {
				Toast.makeText(MainActivity.this, "取消退出", Toast.LENGTH_SHORT).show();
			}
		});
	}
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
      if (keyCode == KeyEvent.KEYCODE_BACK) {
        exitGame();
        return true;
      }
      return super.onKeyDown(keyCode, event);
    }
}
