/** Automatically generated file. DO NOT MODIFY */
package com.anzhi.test.a;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}