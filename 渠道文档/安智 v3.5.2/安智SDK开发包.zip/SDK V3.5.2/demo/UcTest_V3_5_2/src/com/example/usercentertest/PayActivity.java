/*
 * File Name: PayActivity.java 
 * History:
 * Created by Administrator on 2015-3-24
 */
package com.example.usercentertest;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.anzhi.usercenter.sdk.AnzhiUserCenter;
import com.anzhi.test.a.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class PayActivity extends Activity implements OnClickListener {

    private AnzhiUserCenter mCenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gamepay);
        mCenter = AnzhiUserCenter.getInstance();
        findViewById(R.id.btn_pay_1).setOnClickListener(this);
        findViewById(R.id.btn_pay_2).setOnClickListener(this);
        findViewById(R.id.btn_pay_3).setOnClickListener(this);
        findViewById(R.id.btn_pay_4).setOnClickListener(this);
        findViewById(R.id.btn_pay_5).setOnClickListener(this);
        findViewById(R.id.btn_pay_6).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.btn_pay_1:
            mCenter.pay(this, 0, 0.02f, "1元宝", null);
            break;
        case R.id.btn_pay_2:
            mCenter.pay(this, 0, 0.1f, "1元宝", getcode());
            break;
        case R.id.btn_pay_3:
            mCenter.pay(this, 0, 2f, "1元宝", getcode());
            break;
        case R.id.btn_pay_4:
            mCenter.pay(this, 0, 5f, "1元宝", getcode());
            break;
        case R.id.btn_pay_5:
            mCenter.pay(this, 0, 10f, "1元宝", getcode());
            break;
        case R.id.btn_pay_6:
            mCenter.pay(this, 0, 0f, "1元宝", getcode());
            break;
        default:
            break;
        }
    }

    private String getcode() {
        SimpleDateFormat slp = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String st = slp.format(new Date(System.currentTimeMillis()));
        return "anzhi_" + st;
    }

}
