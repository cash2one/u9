/*

o * File Name: GameActivity.java 
 * History:
 * Created by Administrator on 2013-8-2
 */
package com.example.usercentertest;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.anzhi.test.a.R;
import com.anzhi.usercenter.sdk.AnzhiUserCenter;
import com.anzhi.usercenter.sdk.inter.AnzhiCallback;
import com.anzhi.usercenter.sdk.inter.AzOutGameInter;
import com.anzhi.usercenter.sdk.inter.InitSDKCallback;
import com.anzhi.usercenter.sdk.inter.KeybackCall;
import com.anzhi.usercenter.sdk.item.CPInfo;
import com.anzhi.usercenter.sdk.item.UserGameInfo;

/**
 * 本类做为安智游戏SDK的实例代码类，开发者在引用本示例代码时需要谨慎处理
 * 
 */

public class GameActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "anzhiTest";

    private static final String JS_LOGIN_DESC = "code_desc";

    private static final String JS_CODE = "code";

    private static final String JS_UID = "uid"; //

    private static final String JS_NICK = "nick_name";//

    private static final String JS_SID = "sid";//

    private static final String JS_NAME = "login_name";

    private static final String JS_CALLBACK_KEY = "callback_key";

    private static final int CODE_LOGIN_RESULT = 0x00;

    private static final int CODE_PAY_RESULT = CODE_LOGIN_RESULT + 1;

    private static final int CODE_LOGOUT_SUCCESS = CODE_PAY_RESULT + 1;

    private static final String KEY_LOGIN = "key_login";// 登录的key

    private static final String KEY_LOGOUT = "key_logout";// 登出的KEY

    private static final String KEY_PAY = "key_pay";// 支付的key

    /**
     * 登录按钮
     */
    private Button mBtnLogin;

    /**
     * 用户中心参数
     */
//    private String Appkey = "1441966338YGtGIps3LGWeiH7E6Y08";// SDK 初始化参数
//    private String AppSecret = "w958f750o804es4V62IiTJIV";
    private String Appkey = "1378375366Az26xatNyDOD5EM6D2ys";// SDK 初始化参数
    
    private String AppSecret = "ug2KMdLi2JSr4naOE48XmL3h";

    /**
     * 用户中心管理实例
     */
    private AnzhiUserCenter mAnzhiCenter;

    private LinearLayout mControlLayout;

    /**
     * 用户当前的UID
     */
    private String currentUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        initInfo();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void initView() {
        setContentView(R.layout.game);
        mControlLayout = (LinearLayout) findViewById(R.id.ll_control);
        mBtnLogin = (Button) findViewById(R.id.btn_login);// 登录游戏
        mBtnLogin.setOnClickListener(this);
        findViewById(R.id.btn_view_user).setOnClickListener(this);// 唤起用户中心
        findViewById(R.id.btn_charge).setOnClickListener(this);// 支付按钮
        findViewById(R.id.btn_logout).setOnClickListener(this);// 退出游戏按钮
        findViewById(R.id.btn_showf).setOnClickListener(this);// 显示悬浮球
        findViewById(R.id.btn_disf).setOnClickListener(this); // 隐藏悬浮球

    }

    private void initInfo() {
        final CPInfo info = new CPInfo();
        info.setOpenOfficialLogin(false);// 是否开启游戏官方账号登录，默认为关闭
        info.setAppKey(Appkey);
        info.setSecret(AppSecret);
        info.setChannel("AnZhi");
        info.setGameName(getResources().getString(R.string.app_name));
        mAnzhiCenter = AnzhiUserCenter.getInstance();
        mAnzhiCenter.setKeybackCall(keyCall);// 设置返回游戏的通知
        mAnzhiCenter.azinitSDK(this, info, initSDKCallback, gameInter);
        mAnzhiCenter.setCallback(mCallback);// 设置 登录、登出、支付 回调
        mAnzhiCenter.setActivityOrientation(4);// 0横屏,1竖屏,4根据物理感应来选择方向

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
        case R.id.btn_login:// 登录
            mAnzhiCenter.login(this, true);// 登录方法
            break;
        case R.id.btn_view_user:// 个人中心
            mAnzhiCenter.viewUserInfo(this);
            break;
        case R.id.btn_charge:// 支付
            startActivity(new Intent(this, PayActivity.class));
            break;
        case R.id.btn_showf:// 显示悬浮球
            mAnzhiCenter.showFloaticon();
            break;
        case R.id.btn_disf:// 隐藏悬浮球
            mAnzhiCenter.dismissFloaticon();
            break;

        case R.id.btn_logout:// 退出游戏
            AlertDialog.Builder build = new AlertDialog.Builder(GameActivity.this);
            build.setMessage("是否退出或切换账户?");
            build.setNeutralButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mAnzhiCenter.logout(GameActivity.this);// 退出游戏的方法
                }
            });
            build.setNegativeButton("取消", null);
            build.show();
            break;

        default:
            break;
        }
    }

    /**
     * 登录、登出、支付通知
     */
    AnzhiCallback mCallback = new AnzhiCallback() {

        @Override
        public void onCallback(CPInfo cpInfo, final String result) {
            Log.e(TAG, "result " + result);
            try {
                JSONObject json = new JSONObject(result);
                String key = json.optString(JS_CALLBACK_KEY);
                if (KEY_PAY.equals(key)) {// 支付结果通知

                    mHandler.obtainMessage(CODE_PAY_RESULT, json).sendToTarget();

                } else if (KEY_LOGOUT.equals(key)) {// 切换或退出账号的通知

                    mHandler.sendEmptyMessage(CODE_LOGOUT_SUCCESS);

                } else if (KEY_LOGIN.equals(key)) {// 登录游戏的方法

                    mHandler.obtainMessage(CODE_LOGIN_RESULT, json).sendToTarget();

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * 页面返回回调 ，包括登录、支付等；
     * 
     * Login 登录界面 / GamePay 支付界面 / UserCenter 个人中心界面 / GameGift 礼包页面 / anzhiBbs 论坛页面 / Message 消息页面/ Feedback 客服中心页面 /
     * Login 登录页面/ gamePay 充值页面 / AnzhiCurrent 安智币充值界面
     * 
     */
    KeybackCall keyCall = new KeybackCall() {
        @Override
        public void KeybackCall(String Call) {
            Log.e("xugh", "Call == " + Call);
        }
    };

    /**
     * 初始化完成后的回调
     */
    InitSDKCallback initSDKCallback = new InitSDKCallback() {
        @Override
        public void initSdkCallcack() {
            mAnzhiCenter.login(GameActivity.this, true);
        }
    };

    /**
     * 退出游戏的接口，开发者在本接口中实现退出游戏的方法。 在安智的退出弹窗页点退出游戏或在三秒内连续两次调用 azoutGame(boolean)方法会调用本接口
     * 
     * 根据标示码判读是否退出游戏
     * 
     */
    AzOutGameInter gameInter = new AzOutGameInter() {
        @Override
        public void azOutGameInter(int arg) {

            switch (arg) {
            case AzOutGameInter.KEY_OUT_GAME:// 退出游戏
                mAnzhiCenter.removeFloaticon(GameActivity.this);
                finish();
                break;
            case AzOutGameInter.KEY_CANCEL: // 取消退出游戏
                Log.e("xugh", "-----");
                break;
            default:
                break;
            }

        }
    };

    @Override
    public void onBackPressed() {
        /**
         * 1、调用本方法或触发退出逻辑 2、在账号登录的情况下，首次调用本方法或展示后台配置的推广位，如果没有则弹Toast 3、三秒内重复调用本方法会发出退出游戏的通知回调。
         */
        mAnzhiCenter.azoutGame(true);

    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(final Message msg) {
            switch (msg.what) {
            case CODE_PAY_RESULT:
                JSONObject payJson = (JSONObject) msg.obj;
                int code = payJson.optInt(JS_CODE);
                String desc = payJson.optString("desc");// 支付说明
                String orderId = payJson.optString("order_id");//安智支付订单
                String price = payJson.optString("price");// 支付金额
                String time = payJson.optString("time");
                if (code == 200 || code == 201) {// 当支付的返回码是200时 表示 支付成功， 当支付的返回码是201 时 表示支付中此时需要通过服务端来验证支付结果
                    showToast("支付结果：" + desc + "\n支付成功 \n订单号: " + orderId + "\n金额: " + price + "\n时间: " + time);
                } else {
                    showToast(desc);
                }

                break;
            case CODE_LOGOUT_SUCCESS:
                currentUid = null;
                mBtnLogin.setVisibility(View.VISIBLE);
                mControlLayout.setVisibility(View.GONE);
                showToast("已退出账户");
                break;
            case CODE_LOGIN_RESULT:
                JSONObject loginJson = (JSONObject) msg.obj;
                int loginCode = loginJson.optInt(JS_CODE);
                String loginDesc = loginJson.optString(JS_LOGIN_DESC);
                if (loginCode == 200) {
                    mBtnLogin.setVisibility(View.GONE);
                    mControlLayout.setVisibility(View.VISIBLE);
                    String uid = loginJson.optString(JS_UID);// uid 是安智平台用户的唯一标示
                    String loginName = loginJson.optString(JS_NAME);// 获得用户名
                    String sid = loginJson.optString(JS_SID);// 获得SID
                    String Nick = loginJson.optString(JS_NICK);// 获得昵称
                    UserGameInfo gameInfo = new UserGameInfo();
                    gameInfo.setNickName(Nick);
                    gameInfo.setUid(uid);
                    gameInfo.setAppName(getString(R.string.app_name));
                    gameInfo.setGameArea("1");// 游戏的服务器区
                    gameInfo.setGameLevel("10");// 游戏角色等级
                    gameInfo.setUserRole("");// 角色名称
                    gameInfo.setMemo("");// 备注
                    mAnzhiCenter.submitGameInfo(GameActivity.this, gameInfo);
                    showToast(loginDesc);
                } else {
                    showToast(loginDesc);
                }
                break;

            }
        }
    };

    /**
     * 展示Toast，必须在UI线程中调用
     */
    private void showToast(String st) {
        Toast.makeText(this, st, 0).show();
    }

}
