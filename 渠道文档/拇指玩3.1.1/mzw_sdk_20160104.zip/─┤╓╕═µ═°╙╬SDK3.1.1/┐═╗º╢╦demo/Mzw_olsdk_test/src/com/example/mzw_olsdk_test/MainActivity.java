package com.example.mzw_olsdk_test;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.muzhiwan.sdk.core.MzwSdkController;
import com.muzhiwan.sdk.core.callback.MzwInitCallback;
import com.muzhiwan.sdk.core.callback.MzwLoignCallback;
import com.muzhiwan.sdk.core.callback.MzwPayCallback;
import com.muzhiwan.sdk.core.callback.MzwPostGiftCodeCallback;
import com.muzhiwan.sdk.service.MzwOrder;

public class MainActivity extends Activity implements View.OnClickListener {

	private static String TAG = MainActivity.class.getName();
	private EditText giftCodeTextView;
	private Button postGiftCode;
	private MzwOrder order;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/**
		 * 设置屏幕方向
		 */
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);// SCREEN_ORIENTATION_LANDSCAPE

		setContentView(R.layout.activity_main);
		MzwSdkController.getInstance().init(MainActivity.this,
				MzwSdkController.ORIENTATION_HORIZONTAL, new MzwInitCallback() {

					@Override
					public void onResult(int code, String msg) {
						Log.i(TAG, msg+"..");
						MzwSdkController.getInstance().doLogin(new MzwLoignCallback() {
							@Override
							public void onResult(int code, String msg) {
								Log.e("login success-----back with client----", "code:"
										+ code + "--------msg:" + msg);
							}
						});
					}
				});
		Button login = (Button) findViewById(R.id.login);
		login.setOnClickListener(this);
		Button login_out = (Button) findViewById(R.id.login_out);
		login_out.setOnClickListener(this);
		Button update_auto = (Button) findViewById(R.id.update_auto);
		update_auto.setOnClickListener(this);
		Button pay001 = (Button) findViewById(R.id.pay001);
		pay001.setOnClickListener(this);
		Button pay002 = (Button) findViewById(R.id.pay002);
		pay002.setOnClickListener(this);
		Button pay01 = (Button) findViewById(R.id.pay01);
		pay01.setOnClickListener(this);
		Button pay03 = (Button) findViewById(R.id.pay03);
		pay03.setOnClickListener(this);
		Button pay09 = (Button) findViewById(R.id.pay09);
		pay09.setOnClickListener(this);
		giftCodeTextView = (EditText) findViewById(R.id.inputGiftCode);
		postGiftCode = (Button)findViewById(R.id.postGiftCode);
		postGiftCode.setOnClickListener(this);
	}

	@Override
	public void onBackPressed() {
		MzwSdkController.getInstance().destory();
		Log.e("---------onDestroy---------", "destory....");
		super.onBackPressed();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.login:
			MzwSdkController.getInstance().doLogin(new MzwLoignCallback() {
				@Override
				public void onResult(int code, String msg) {
					Log.e("login success-----back with client----", "code:"
							+ code + "--------msg:" + msg);
				}
			});

			break;
		case R.id.login_out:
			MzwSdkController.getInstance().doLogout();
			break;
		case R.id.update_auto:
			MzwSdkController.getInstance().doUpdateAuto(-1);//0
			break;
		case R.id.pay001:
			order = new MzwOrder();
			order.setMoney(1);
			order.setProductname("蓝钻");
			order.setProductdesc("成为蓝钻用户");
			MzwSdkController.getInstance().doPay(order, new MzwPayCallback() {
				@Override
				public void onResult(int code, MzwOrder order) {
					Log.e("pay success-----back with client----",
							"code:" + code + "--------order:" + order);
				}
			});
			break;
		case R.id.pay002:
			order = new MzwOrder();
			order.setMoney(2);
			order.setProductname("黄钻");
			order.setProductdesc("成为黄钻用户");
			MzwSdkController.getInstance().doPay(order, new MzwPayCallback() {
				@Override
				public void onResult(int code, MzwOrder order) {
					Log.e("pay success-----back with client----",
							"code:" + code + "--------order:" + order);
				}
			});
			break;
		case R.id.pay01:
			order = new MzwOrder();
			order.setMoney(10);
			order.setProductname("绿钻");
			order.setProductdesc("成为绿钻用户");
			MzwSdkController.getInstance().doPay(order, new MzwPayCallback() {
				@Override
				public void onResult(int code, MzwOrder order) {
					Log.e("pay success-----back with client----",
							"code:" + code + "--------order:" + order);
				}
			});
			break;
		case R.id.pay03:
			order = new MzwOrder();
			order.setMoney(30);
			order.setProductname("vip");
			order.setProductdesc("成为vip用户");
			MzwSdkController.getInstance().doPay(order, new MzwPayCallback() {
				@Override
				public void onResult(int code, MzwOrder order) {
					Log.e("pay success-----back with client----",
							"code:" + code + "--------order:" + order);
				}
			});
			break;
		case R.id.pay09:
			order = new MzwOrder();
			order.setMoney(90);
			order.setProductname("svip");
			order.setProductdesc("成为svip用户");
			MzwSdkController.getInstance().doPay(order, new MzwPayCallback() {
				@Override
				public void onResult(int code, MzwOrder order) {
					Log.e("pay success-----back with client----",
							"code:" + code + "--------order:" + order);
				}
			});
			break;
		case R.id.postGiftCode:
			String giftCodeValue = giftCodeTextView.getText().toString().trim();
			if(!"".equals(giftCodeValue)){
				MzwSdkController.getInstance().doPostGiftCode(giftCodeValue,new MzwPostGiftCodeCallback() {
					
					@Override
					public void onResult(int code, String msg) {
						Log.e("doPostGiftCode finished-----back with client----",
								"code:" + code + "--------msg:"
										+ msg);
						if(code == 1){
							giftCodeTextView.setEnabled(false);
							giftCodeTextView.setText("渠道设置成功，如需重新设置，请卸载重装！");
							postGiftCode.setClickable(false);
						}
						Toast.makeText(MainActivity.this, code == 1?"礼包码对应渠道设置成功!":"礼包码对应渠道设置失败!", Toast.LENGTH_LONG).show();
					}
				});
			}else{
				Toast.makeText(MainActivity.this, "请输入礼包码!", Toast.LENGTH_LONG).show();
			}
			break;
		default:
			break;
		}
	}
}
