package com.jolosdk.demo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.jolo.account.Jolo.onAccountResult;
import com.jolo.jolopay.JoloPay.onPayResult;
import com.jolo.sdk.JoloSDK;
import com.joloplay.sdk.demo.R;

/**
 * JoloSDK的接口说明：<br>
 * joloSDK.initJoloSDK(Context ctx, String gameCode);// 初始化SDK。<br>
 * joloSDK.releaseJoloSDK(); // 释放SDK的资源。<br>
 * joloSDK.login(Activity activity);// 登录接口，跳转到登录页<br>
 * joloSDK.logoff(Activity activity); // 注销接口，切换用户<br>
 * joloSDK.startPay(Activity activity, String joloorderString,String
 * joloordersign);// 支付接口<br>
 * 
 * @author Tony
 * */
public class MainActivity extends Activity implements onAccountResult,
		onPayResult {

	private static final int AUTO_LOGIN = 1000;

	// 用户登录信息
	private String userName; // 用户名
	private String userId; // 用户ID
	private String session; // 用户登录session
	private String account; // 用户帐号信息
	private String accountSign; // 用户帐号信息签名(聚乐公钥验签)
	// 用户登录信息显示的VIEW
	private TextView usernameTV;
	private TextView userIDTV;
	private TextView sessionTV;
	// 登录/注册测试按钮
	private Button loginBT;
	// 支付/充值测试按钮
	private Button payBT1; // 1元支付(1元购买10000个金币)
	private Button payBT10; // 10元支付(10元购买100000个金币)
	private Button payBT50; // 50元支付(50元购买500000个金币)
	private Button payBTN; //任何金额购买N个金币
	//输入金额
	private EditText paynumET;
	
	private String order; // 支付申请订单
	private String sign; // 支付订单签名(CP私钥签名)
	private String resultOrder;// 支付回执订单
	private String resultSign;// 支付回执订单签名(聚乐公钥验签)

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// 注意：在调用JoloSDK其他接口之前，请调用初始化接口
		// 可以把游戏的gameCode先替换PartnerConfig.CP_GAME_CODE值来检测是否能获取UserId, username,
		// session, accountSign, account
		JoloSDK.initJoloSDK(this, PartnerConfig.CP_GAME_CODE);
		//注册 onPay回调和onAccount回调，一般建议CP使用onActivityResult回调，两个回调返回的数据是相同的。
		//两者选一个即可
		JoloSDK.initCallBack(this, this);
		
		usernameTV = (TextView) findViewById(R.id.username_tv);
		userIDTV = (TextView) findViewById(R.id.userid_tv);
		sessionTV = (TextView) findViewById(R.id.session_tv);
		paynumET = (EditText)findViewById(R.id.pay_number);
		
		loginBT = (Button) findViewById(R.id.login_bt);
		loginBT.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				logoff();
			}
		});
		updateUserInfoTV();
		// 显示一下游戏页面，然后1.5s后进入登录页（游戏自定义如何进入登录页）
		handler.sendEmptyMessageDelayed(AUTO_LOGIN, 1500);

		payBT1 = (Button) findViewById(R.id.pay_bt1);
		payBT1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (null == userId) {
					Toast.makeText(MainActivity.this, "未登录无法进行支付",
							Toast.LENGTH_SHORT).show();
				} else {
					Order or = new Order();
					//注意：参数里，不要出现类似“1元=10000个金币”的字段，因为“=”原因，会导致微信支付校验失败
					or.setAmount("100"); // 设置支付金额，单位分
					or.setGameCode(PartnerConfig.CP_GAME_CODE); // 设置游戏唯一ID,由Jolo提供
					or.setGameName(PartnerConfig.CP_GAME_NAME); // 设置游戏名称
					or.setGameOrderid("" + System.currentTimeMillis()); // 设置游戏订单号
					or.setNotifyUrl(PartnerConfig.CP_NOTIFY_URL); // 设置支付通知
					or.setProductDes("1元购买10000个金币"); // 设置产品描述
					or.setProductID("No100"); // 设置产品ID
					or.setProductName("10000个金币"); // 设置产品名称
					or.setSession(session); // 设置用户session
					or.setUsercode(userId); // 设置用户ID
					order = or.toJsonOrder(); // 生成Json字符串订单
					sign = RsaSign.sign(order, PartnerConfig.CP_PRIVATE_KEY_PKCS8); // 签名
					Log.i("test", "order = " + order);
					Log.i("test", "sign = " + sign);
					JoloSDK.startPay(MainActivity.this, order, sign); // 启动支付
					/**
					 * {"amount":"100","session_id":"82149928","product_id":"No100","product_des":"1元购买10000个金币","game_code":"game10001","product_name":"10000个金币","user_code":"100000961","notify_url":"http:\/\/218.245.6.236:12116\/cpserver\/pay.do","game_order_id":"1444709354577","game_name":"时空猎人"}
					 */
				}
			}
		});

		payBT10 = (Button) findViewById(R.id.pay_bt10);
		payBT10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (null == userId) {
					Toast.makeText(MainActivity.this, "未登录无法进行支付",
							Toast.LENGTH_SHORT).show();
				} else {
					Order or = new Order();
					or.setAmount("1000");// 单位分
					or.setGameCode(PartnerConfig.CP_GAME_CODE);
					or.setGameName(PartnerConfig.CP_GAME_NAME);
					or.setGameOrderid("" + System.currentTimeMillis());
					or.setNotifyUrl(PartnerConfig.CP_NOTIFY_URL);
					or.setProductDes("10元购买100000个金币");
					or.setProductID("No101");
					or.setProductName("100000个金币");
					or.setSession(session);
					or.setUsercode(userId);
					order = or.toJsonOrder();
					sign = RsaSign.sign(order, PartnerConfig.CP_PRIVATE_KEY_PKCS8);
					JoloSDK.startPay(MainActivity.this, order, sign);
				}
			}
		});

		payBT50 = (Button) findViewById(R.id.pay_bt50);
		payBT50.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (null == userId) {
					Toast.makeText(MainActivity.this, "未登录无法进行支付",
							Toast.LENGTH_SHORT).show();
				} else {
					Order or = new Order();
					or.setAmount("5000");// 单位分
					or.setGameCode(PartnerConfig.CP_GAME_CODE);
					or.setGameName(PartnerConfig.CP_GAME_NAME);
					or.setGameOrderid("" + System.currentTimeMillis());
					or.setNotifyUrl(PartnerConfig.CP_NOTIFY_URL);
					or.setProductDes("50元购买500000个金币");
					or.setProductID("No102");
					or.setProductName("500000个金币");
					or.setSession(session);
					or.setUsercode(userId);
					order = or.toJsonOrder();
					sign = RsaSign.sign(order, PartnerConfig.CP_PRIVATE_KEY_PKCS8);
					// 提交支付
					JoloSDK.startPay(MainActivity.this, order, sign);
				}
			}
		});
		
		payBTN = (Button) findViewById(R.id.pay_btN);
		payBTN.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				int number = Integer.valueOf(paynumET.getText().toString());
				if (null == userId) {
					Toast.makeText(MainActivity.this, "未登录无法进行支付",
							Toast.LENGTH_SHORT).show();
				} else if(number <=0){
					Toast.makeText(MainActivity.this, "输入金额不能为空",
							Toast.LENGTH_SHORT).show();
				}else {
					Order or = new Order();
					or.setAmount(String.valueOf(number*100));// 单位分
					or.setGameCode(PartnerConfig.CP_GAME_CODE);
					or.setGameName(PartnerConfig.CP_GAME_NAME);
					or.setGameOrderid("" + System.currentTimeMillis());
					or.setNotifyUrl(PartnerConfig.CP_NOTIFY_URL);
					or.setProductDes("50元购买500000个金币");
					or.setProductID("No103");
					or.setProductName("500000个金币");
					or.setSession(session);
					or.setUsercode(userId);
					order = or.toJsonOrder();
					sign = RsaSign.sign(order, PartnerConfig.CP_PRIVATE_KEY_PKCS8);
					// 提交支付
					JoloSDK.startPay(MainActivity.this, order, sign);
				}
			}
		});

	}

	private Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			int what = msg.what;
			switch (what) {
			case AUTO_LOGIN: {
				// 进入登录页
				JoloSDK.login(MainActivity.this);
			}
				break;
			}
		};
	};

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK || data == null){
			if(requestCode == JoloSDK.PAY_REQUESTCODE){
				Log.i("test", "取消支付");	
			}
			return;
		}

		switch (requestCode) {
		case JoloSDK.ACCOUNT_REQUESTCODE: {
			// 用户账号名
			userName = data.getStringExtra(JoloSDK.USER_NAME);
			// 用户账号ID
			userId = data.getStringExtra(JoloSDK.USER_ID);
			// 账号的session，支付时使用
			session = data.getStringExtra(JoloSDK.USER_SESSION);
			// 用户帐号信息签名(聚乐公钥验签)，密文，CP对该密文用公钥进行校验
			accountSign = data.getStringExtra(JoloSDK.ACCOUNT_SIGN);
			// 用户帐号信息，明文，用户加密的字符串
			account = data.getStringExtra(JoloSDK.ACCOUNT);

			Log.i("test", "account = " + account);
			Log.i("test", "account_sign = " + accountSign);
			// 账号合法性检验，注意：安全性考虑，建议将该代码放到服务器进行校验
			if (RsaSign.doCheck(account, accountSign,
					PartnerConfig.JOLO_PUBLIC_KEY)) {
				updateUserInfoTV();
				Toast.makeText(MainActivity.this, "签名校验成功，用户合法",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(MainActivity.this, "签名校验失败，用户不合法",
						Toast.LENGTH_SHORT).show();
			}
		}
			break;
		case JoloSDK.PAY_REQUESTCODE: {
			resultOrder = data.getStringExtra(JoloSDK.PAY_RESP_ORDER);
			resultSign = data.getStringExtra(JoloSDK.PAY_RESP_SIGN);
			Log.i("test", "resultOrder = " + resultOrder);
			Log.i("test", "resultSign = " + resultSign);
			if (RsaSign.doCheck(resultOrder, resultSign,
					PartnerConfig.JOLO_PUBLIC_KEY)) {
				// 校验支付订单后，解析订单内容
				ResultOrder or = new ResultOrder(resultOrder);
				String joloorderid = or.getJoloOrderID(); // jolo唯一订单号
				String amount = or.getRealAmount(); // 用户实际支付的金额
				int resultcode = or.getResultCode(); // 返回码, == 200为支付成功
				String resultmsg = or.getResultMsg(); // 返回提示信息
				Log.i("test", "joloorderid = " + joloorderid);
				Log.i("test", "amount = " + amount);
				Log.i("test", "resultcode = " + resultcode);
				Log.i("test", "resultmsg = " + resultmsg);
				Toast.makeText(MainActivity.this,
						"支付结果签名校验成功" + ",金额 = " + amount + "分",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(MainActivity.this, "支付结果签名校验失败",
						Toast.LENGTH_SHORT).show();
			}
		}
			break;
		default:
			break;
		}
	};

	private void updateUserInfoTV() {
		usernameTV.setText(userName);
		userIDTV.setText(userId);
		sessionTV.setText(session);
	}

	/**
	 * 清除游戏的用户信息，注销
	 */
	private void resetUserInfo() {
		userName = null;
		userId = null;
		session = null;
	}

	private void logoff() {
		// 清除游戏的用户信息
		resetUserInfo();
		updateUserInfoTV();
		// 调用注销接口，会重新进入登录页，进行用户的切换
		JoloSDK.logoff(MainActivity.this);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		// 销毁SDK所使用的资源
		JoloSDK.releaseJoloSDK();
		super.onDestroy();
	}

	@Override
	public void onPay(int resultCode, Intent data) {
		Log.i("test", "(onPay)!!!!!!!!!!!!!");
		if (resultCode != RESULT_OK || data == null){
			Toast.makeText(MainActivity.this,"取消支付", Toast.LENGTH_SHORT)
					.show();
			return;
		}
		resultOrder = data.getStringExtra(JoloSDK.PAY_RESP_ORDER);
		resultSign = data.getStringExtra(JoloSDK.PAY_RESP_SIGN);
		Log.i("test", "resultOrder(onPay) = " + resultOrder);
		Log.i("test", "resultSign(onPay) = " + resultSign);
		if (RsaSign.doCheck(resultOrder, resultSign,
				PartnerConfig.JOLO_PUBLIC_KEY)) {
			// 校验支付订单后，解析订单内容
			ResultOrder or = new ResultOrder(resultOrder);
			String joloorderid = or.getJoloOrderID(); // jolo唯一订单号
			String amount = or.getRealAmount(); // 用户实际支付的金额
			int resultcode = or.getResultCode(); // 返回码, == 200为支付成功
			String resultmsg = or.getResultMsg(); // 返回提示信息
			Log.i("test", "joloorderid(onPay) = " + joloorderid);
			Log.i("test", "amount(onPay) = " + amount);
			Log.i("test", "resultcode(onPay) = " + resultcode);
			Log.i("test", "resultmsg(onPay) = " + resultmsg);
			Toast.makeText(MainActivity.this,
					"支付结果签名校验成功(onPay)" + ",金额 = " + amount + "分", Toast.LENGTH_SHORT)
					.show();
		} else {
			Toast.makeText(MainActivity.this, "支付结果签名校验失败(onPay)", Toast.LENGTH_SHORT)
					.show();
		}
	}

	@Override
	public void onAccount(int resultCode, Intent data) {
		Log.i("test", "(onAccount)!!!!!!!!!!!!!");
		if (resultCode != RESULT_OK || data == null){
			return;
		}
		// 用户账号名
		userName = data.getStringExtra(JoloSDK.USER_NAME);
		// 用户账号ID，用该ID当用户的唯一标识符
		userId = data.getStringExtra(JoloSDK.USER_ID);
		// 账号的session，支付时使用
		session = data.getStringExtra(JoloSDK.USER_SESSION);
		// 用户帐号信息签名(聚乐公钥验签)，密文，CP对该密文用公钥进行校验
		accountSign = data.getStringExtra(JoloSDK.ACCOUNT_SIGN);
		// 用户帐号信息，明文，用户加密的字符串
		account = data.getStringExtra(JoloSDK.ACCOUNT);

		Log.i("test", "onAccount account = " + account);
		Log.i("test", "onAccount account_sign = " + accountSign);
		// 账号合法性检验，注意：安全性考虑，建议将该代码放到服务器进行校验
		if (RsaSign
				.doCheck(account, accountSign, PartnerConfig.JOLO_PUBLIC_KEY)) {
			updateUserInfoTV();
			Toast.makeText(MainActivity.this, "签名校验成功，用户合法(onAccount)",
					Toast.LENGTH_SHORT).show();
		} else {
			Toast.makeText(MainActivity.this, "签名校验失败，用户不合法(onAccount)",
					Toast.LENGTH_SHORT).show();
		}
	}

}
