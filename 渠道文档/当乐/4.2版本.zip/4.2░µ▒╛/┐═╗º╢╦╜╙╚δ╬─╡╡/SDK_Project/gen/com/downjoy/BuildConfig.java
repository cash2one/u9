/** Automatically generated file. DO NOT MODIFY */
package com.downjoy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}