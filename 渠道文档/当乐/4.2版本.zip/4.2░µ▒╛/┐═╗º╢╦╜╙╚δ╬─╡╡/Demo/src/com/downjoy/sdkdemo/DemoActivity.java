package com.downjoy.sdkdemo;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import com.downjoy.CallbackListener;
import com.downjoy.CallbackStatus;
import com.downjoy.Downjoy;
import com.downjoy.InitListener;
import com.downjoy.LoginInfo;
import com.downjoy.LogoutListener;
import com.downjoy.UserInfo;
import com.downjoy.util.Util;

public class DemoActivity extends Activity implements OnClickListener {

    private Downjoy downjoy; // 当乐游戏中心实例
    // CP后台可以查询到前三个参数MERCHANT_ID、APP_ID和APP_KEY.
    // 不同服务器序列号可使用不同计费通知地址
    private static final String MERCHANT_ID = "101"; // 当乐分配的MERCHANT_ID
    private static final String APP_ID = "195"; // 当乐分配的APP_ID.
    private static final String APP_KEY = "j5VEvxhc"; // 当乐分配的 APP_KEY
    private static final String SERVER_SEQ_NUM = "1"; // 此参数自定义，需登录CP后台配置支付通知回调，其中的服务器序号就是SERVER_SEQ_NUM

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initDownjoy();
        findViewById(R.id.login).setOnClickListener(this);
        findViewById(R.id.info).setOnClickListener(this);
        findViewById(R.id.pay_0).setOnClickListener(this);
        findViewById(R.id.pay_1).setOnClickListener(this);
        findViewById(R.id.get_info).setOnClickListener(this);
        findViewById(R.id.logout).setOnClickListener(this);
        // 此接口可以切换serverSeqNum参数，
        // downjoy.setServerSeqNum("1");
    }

    private void initDownjoy() {
        downjoy = Downjoy.getInstance(this, MERCHANT_ID, APP_ID, SERVER_SEQ_NUM, APP_KEY, new InitListener() {

            @Override
            public void onInitComplete() {
                //此处CP请根据自己的逻辑判断是否调用登陆
                downjoyLogin();
            }
        });
        // 设置登录成功后属否显示当乐游戏中心的悬浮按钮
        // 注意：
        // 此处应在调用登录接口之前设置，默认值是true，即登录成功后自动显示当乐游戏中心的悬浮按钮。
        // 如果此处设置为false，登录成功后，不显示当乐游戏中心的悬浮按钮。
        // 正常使用悬浮按钮还需要实现两个函数,onResume、onPause
        downjoy.showDownjoyIconAfterLogined(true);
        //设置悬浮窗显示位置
        downjoy.setInitLocation(Downjoy.LOCATION_RIGHT_CENTER_VERTICAL);
        //设置全局注销监听器，浮标中的注销也能接收到回调
        downjoy.setLogoutListener(mLogoutListener);
    }

    private LogoutListener mLogoutListener = new LogoutListener() {
        @Override
        public void onLogoutSuccess() {
            Util.alert(DemoActivity.this, "注销成功回调->注销成功");
            downjoyLogout();
        }

        @Override
        public void onLogoutError(String msg) {
            Util.alert(DemoActivity.this, "注销失败回调->" + msg);
        }
    };


    @Override
    protected void onResume() {
        super.onResume();
        if (downjoy != null) {
            downjoy.resume(DemoActivity.this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (downjoy != null) {
            downjoy.pause();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (downjoy != null) {
            downjoy.destroy();
            downjoy = null;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return downjoyExit();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login: // 登录
                downjoyLogin();
                break;
            case R.id.info:// 个人中心
                downjoy.openMemberCenterDialog(this);
                break;
            case R.id.pay_0:// 商品支付0
                downjoyPayment(0.0f);
                break;
            case R.id.pay_1:// 商品支付0.01
                downjoyPayment(0.01f);
                break;
            case R.id.get_info:// 获取用户信息
                downjoyInfo();
                break;
            case R.id.logout:// 注销
                downjoy.logout(this);
                break;
        }
    }

    /**
     * 获取用户信息
     */
    private void downjoyInfo() {
        if (null == downjoy)
            return;
        downjoy.getInfo(this, new CallbackListener<UserInfo>() {

            @Override
            public void callback(int status, UserInfo data) {
                if (status == CallbackStatus.SUCCESS) {
                    Util.alert(DemoActivity.this, data.toString());
                } else if (status == CallbackStatus.FAIL) {
                    Util.alert(getBaseContext(), "onError:" + data.getMsg());
                }
            }
        });
    }

    /**
     * 支付
     *
     * @param money 商品价格，单位：元
     */
    private void downjoyPayment(float money) {
        if (null == downjoy)
            return;
        String productName = "测试商品"; // 商品名称
        String body = getRandString(); // 商品描述
        String transNo = getRandString(); // cp订单号，计费结果通知时原样返回，尽量不要使用除字母和数字之外的特殊字符。
        String serverName = "Serer001"; //记录订单产生的服务器，没有可传“”
        String playerName = "Player001"; //记录订单产生的玩家名称，没有可传“”
        // 打开支付界面,获得订单号
        downjoy.openPaymentDialog(this, money, productName, body, transNo, serverName, playerName,
                new CallbackListener<String>() {

                    @Override
                    public void callback(int status, String data) {
                        if (status == CallbackStatus.SUCCESS) {
                            Util.alert(DemoActivity.this, "成功支付回调->订单号：" + data);
                        } else if (status == CallbackStatus.FAIL) {
                            Util.alert(DemoActivity.this, "失败支付回调->error:" + data);
                        } else if (status == CallbackStatus.CANCEL) {
                            Util.alert(DemoActivity.this, "取消支付回调->" + data);
                        }
                    }
                });
    }

    /**
     * 注销
     */
    private void downjoyLogout() {
        if (null == downjoy)
            return;
        //此处demo的逻辑是注销后弹出登录框，CP可根据自己的逻辑处理
       downjoyLogin();
    }

    /**
     * 登录
     */
    private void downjoyLogin() {
        if (null == downjoy)
            return;
        downjoy.openLoginDialog(DemoActivity.this, new CallbackListener<LoginInfo>() {

            @Override
            public void callback(int status, LoginInfo data) {
                if (status == CallbackStatus.SUCCESS && data != null) {
                    Util.alert(DemoActivity.this, "登录成功回调->" + data.toString());
                } else if (status == CallbackStatus.FAIL && data != null) {
                    Util.alert(DemoActivity.this, "登录失败回调->" + data.getMsg());
                } else if (status == CallbackStatus.CANCEL && data != null) {
                    Util.alert(DemoActivity.this, "登录取消回调->" + data.getMsg());
                }
            }
        });
    }

    /**
     * 退出对话框
     */
    private boolean downjoyExit() {
        if (null == downjoy)
            return false;
        downjoy.openExitDialog(this, new CallbackListener<String>() {

            @Override
            public void callback(int status, String data) {
                if (CallbackStatus.SUCCESS == status) {
                    finish();
                } else if (CallbackStatus.CANCEL == status) {
                    Util.alert(getBaseContext(), "退出回调-> " + data);
                }
            }
        });
        return true;
    }

    /**
     * 生成CP自定义信息和订单号
     *
     * @return
     */
    private static String getRandString() {
        int[] x = new int[10];
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            x[i] = (int) (Math.random() * 10);
            b.append(x[i]);
        }

        return b.toString() + "测试";
    }
    
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged( newConfig);
        if(downjoy != null) {
            downjoy.onConfigurationChanged( newConfig);
        }
    }
}