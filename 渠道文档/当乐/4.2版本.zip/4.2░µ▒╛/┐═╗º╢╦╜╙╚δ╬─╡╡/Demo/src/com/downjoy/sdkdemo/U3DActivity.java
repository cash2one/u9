package com.downjoy.sdkdemo;

import android.os.Bundle;
import android.util.Log;

import com.downjoy.CallbackListener;
import com.downjoy.CallbackStatus;
import com.downjoy.Downjoy;
import com.downjoy.InitListener;
import com.downjoy.LoginInfo;
import com.downjoy.LogoutListener;
import com.downjoy.UserInfo;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public class U3DActivity extends UnityPlayerActivity {

    static U3DActivity sCurrentActivity;
    static Downjoy sDownjoy;
    static String sGameObject;
    // CP后台可以查询到前三个参数MERCHANT_ID、APP_ID和APP_KEY.
    // 不同服务器序列号可使用不同计费通知地址
    private static final String MERCHANT_ID = "101"; // 当乐分配的MERCHANT_ID
    private static final String APP_ID = "195"; // 当乐分配的APP_ID.
    private static final String APP_KEY = "j5VEvxhc"; // 当乐分配的 APP_KEY
    private static final String SERVER_SEQ_NUM = "1"; // 此参数自定义，需登录CP后台配置支付通知回调，其中的服务器序号就是SERVER_SEQ_NUM

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        sCurrentActivity = this;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sDownjoy != null) {
            sDownjoy.destroy();
            sDownjoy = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sDownjoy != null)
            sDownjoy.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sDownjoy != null)
            sDownjoy.resume(this);
    }

    public static void InitDownjoy(String gameobject, final String initComplete, final String merchantId, final String appId,
                                   final String serverSeqNum, final String appKey) {
        Log.i("xltest", "i it......sucmethod=");
        sGameObject = gameobject;
        final InitListener initListener = new InitListener() {

            @Override
            public void onInitComplete() {
                Log.d( "xltest", "U3DActivity init complete");
                if (sDownjoy != null) {
                    UnityPlayer.UnitySendMessage(sGameObject, initComplete, "init complete");
                }
            }
        };

        sCurrentActivity.runOnUiThread(new Runnable() {

            @Override
            public void run() {
                sDownjoy = Downjoy.getInstance(sCurrentActivity, merchantId, appId, serverSeqNum, appKey, initListener);
            }

        });
    }

    public static void Log(String msg) {
        Log.i("xltest", "u3d=" + msg);
    }

    // 登录
    public static void doLogin(final String sucmethod, final String failmethod, final String cancelmethod) {
        Log.i("xltest", "i it......sucmethod=" + sucmethod + ",failmethod=" + failmethod);
        sDownjoy.openLoginDialog(sCurrentActivity, new CallbackListener<LoginInfo>() {
            @Override
            public void callback(int status, LoginInfo data) {
                if (status == CallbackStatus.SUCCESS && data != null) {
                    String memberId = data.getUmid();
                    String username = data.getUserName();
                    String nickname = data.getNickName();
                    String token = data.getToken();
                    UnityPlayer.UnitySendMessage(sGameObject, sucmethod, memberId + "|" + username + "|" + nickname + "|" + token);
                } else if (status == CallbackStatus.FAIL && data != null) {
                    UnityPlayer.UnitySendMessage(sGameObject, failmethod, data.getMsg());
                } else if (status == CallbackStatus.CANCEL && data != null) {
                    UnityPlayer.UnitySendMessage(sGameObject, cancelmethod, data.getMsg());
                }
            }
        });
    }

    // 个人中心
    public static void enterMemberCenter() {
        Log.i("xltest", "i it enterMemberCenter");
        sDownjoy.openMemberCenterDialog(sCurrentActivity);
    }

    // 设置注销回调，浮标-注销
    public static void setLogoutListenerForU3d(final String sucmethod, final String failmethod) {
        Log.i("xltest", "i it......sucmethod = " + sucmethod + ", failmethod = " + failmethod);
        sDownjoy.setLogoutListener(new LogoutListener() {

            @Override
            public void onLogoutSuccess() {
                UnityPlayer.UnitySendMessage(sGameObject, sucmethod, "logout ok");
            }

            @Override
            public void onLogoutError(String msg) {
                UnityPlayer.UnitySendMessage(sGameObject, failmethod, msg);
            }
        });
    }

    // 登出 调用此接口前必须有设置过setLogoutListenerForU3d，否则收不到回调
    public static void doLogout() {
        sDownjoy.logout(sCurrentActivity);
    }

    // 进入商品支付(0)
    public static void doPaymentUserEnterDialog(final String sucmethod, final String failmethod, String productName,
                                                String body, String transNo, String serverName, String playerName) {
        Log.i("xltest", "i it......sucmethod=" + sucmethod + ",failmethod=" + failmethod);
        float money = 0.0f; // 商品价格，单位：元
//        String productName = ProductInfo; // 商品名称
//        String body = body; // CP自定义信息，多为CP订单号

        // 打开支付界面,获得订单号
        sDownjoy.openPaymentDialog(sCurrentActivity, money, productName, body, transNo, serverName, playerName, new CallbackListener<String>() {

            @Override
            public void callback(int status, String data) {
                if (status == CallbackStatus.SUCCESS) {
                    UnityPlayer.UnitySendMessage(sGameObject, sucmethod, data);
                } else if (status == CallbackStatus.FAIL) {
                    UnityPlayer.UnitySendMessage(sGameObject, failmethod, data);
                }
            }
        });
    }

    // 进入商品支付(0.1)
    public static void doPaymentDialog(final String sucmethod, final String failmethod, String Money, String productName,
                                       String body, String transNo, String serverName, String playerName) {
        Log.i("xltest", "i it......sucmethod=" + sucmethod + ",failmethod=" + failmethod);
        float money = Float.valueOf(Money);// 0.0f; // 商品价格，单位：元
//        String productName = ProductInfo; // 商品名称
//        String body = body; // CP自定义信息，多为CP订单号

        // 打开支付界面,获得订单号
        sDownjoy.openPaymentDialog(sCurrentActivity, money, productName, body, transNo, serverName, playerName, new CallbackListener<String>() {

            @Override
            public void callback(int status, String data) {
                if (status == CallbackStatus.SUCCESS) {
                    UnityPlayer.UnitySendMessage(sGameObject, sucmethod, data);
                } else if (status == CallbackStatus.FAIL) {
                    UnityPlayer.UnitySendMessage(sGameObject, failmethod, data);
                }
            }
        });
    }

    // 获取用户信息
    public static void doGetInfo(final String sucmethod, final String failmethod) {
        Log.i("xltest", "i it......sucmethod=" + sucmethod + ",failmethod=" + failmethod);
        sDownjoy.getInfo(sCurrentActivity, new CallbackListener<UserInfo>() {

            @Override
            public void callback(int status, UserInfo data) {
                if (status == CallbackStatus.SUCCESS) {
                    String memberId = data.getUmid();
                    String username = data.getUserName();
                    String phone = data.getPhone();
                    String gender = data.getGender();
                    String vip = data.getVip();
                    String avatarUrl = data.getAvatarUrl();
                    String security_num = data.getSecurity_num();
                    UnityPlayer.UnitySendMessage(sGameObject, sucmethod, memberId + "|" + username + "|" + phone + "|" + gender
                            + "|" + vip + "|" + avatarUrl + "|" + security_num);
                } else if (status == CallbackStatus.FAIL) {
                    UnityPlayer.UnitySendMessage(sGameObject, failmethod, data.getMsg());
                }
            }
        });
    }

    // 退出游戏对话框
    public static void doExitGameDialog(final String cancelmethod) {
        sDownjoy.openExitDialog(sCurrentActivity, new CallbackListener<String>() {

            @Override
            public void callback(int status, String data) {
                if (CallbackStatus.SUCCESS == status) {
                    sCurrentActivity.finish();
                } else if (CallbackStatus.CANCEL == status) {
                    UnityPlayer.UnitySendMessage(sGameObject, cancelmethod, data);
                }
            }
        });
    }

    /**
     * 登录成功后，是否显示当乐图标的悬浮按钮
     *
     * @param show
     */
    public static void showDownjoyIconAfterLoginedForU3d(boolean show) {
        sDownjoy.showDownjoyIconAfterLogined(show);
    }

    /**
     * 设置悬浮按钮的初始位置
     *
     * @return
     */
    public static void setInitLocationForU3d(int location) {
        sDownjoy.setInitLocation(location);
    }

}
