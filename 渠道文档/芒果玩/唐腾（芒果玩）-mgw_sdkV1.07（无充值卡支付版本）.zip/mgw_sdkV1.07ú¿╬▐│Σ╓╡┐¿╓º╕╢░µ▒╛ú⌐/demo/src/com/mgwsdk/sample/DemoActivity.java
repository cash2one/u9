
package com.mgwsdk.sample;

import com.baina.sdk.BNSDK;
import com.baina.sdk.OnBNSDKListener;
import com.baina.sdk.entity.BNSDKOrderResult;
import com.baina.sdk.sample.R;
import com.baina.sdk.widget.FloatMenuManager;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.TextView;

public class DemoActivity extends Activity implements OnClickListener, OnBNSDKListener {

    Button b1, b2, b3, b4;

    TextView log;

    StringBuffer sb = new StringBuffer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**
         * STEP 1 初始化SDK 请在OnCreate中或之后进行SDK初始化，在一个Application生命周期内，只需要初始化一次即可
         * 多次初始化不影响登录状态 有时候如果订单状态出错，可重新初始化以解决问题
         */
        BNSDK sdk = BNSDK.getInstance();
        sdk.init(this);

        // 这里设置SDK界面方向，可根据游戏需要调整
        sdk.setOrientation(BNSDK.ORIENTATION_PORTRAIT);

        /**
         * 以下是Demo程序的UI及Log输出逻辑，可忽略
         */

        super.onCreate(savedInstanceState);
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_demo_land);
            sdk.setOrientation(BNSDK.ORIENTATION_LANDSCAPE);
        } else {
            setContentView(R.layout.activity_demo);
            sdk.setOrientation(BNSDK.ORIENTATION_PORTRAIT);
        }

        b1 = (Button) this.findViewById(R.id.start_Login);
        b1.setOnClickListener(this);

        b2 = (Button) this.findViewById(R.id.order_1);
        b2.setOnClickListener(this);

        b3 = (Button) this.findViewById(R.id.order_2);
        b3.setOnClickListener(this);

        b4 = (Button) this.findViewById(R.id.channel);
        b4.setOnClickListener(this);

        log = (TextView) this.findViewById(R.id.log);
        log.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        log.setOnLongClickListener(new OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                initLogcat();
                return false;
            }

        });

        initLogcat();
    }

    private void initLogcat() {
        sb.setLength(0);
        log("*Logcat* Ver " + BNSDK.getInstance().getVersion());
        log("Tips: 旋转屏幕可切换显示方向，长按可清屏");
        log(" ");
    }

    private void log(int code) {
        sb.append("操作： [" + code + "]" + BNSDK.getInstance().code2Msg(code));
        sb.append("\n");

        log.setText(sb.toString());
    }

    private void log(String msg) {
        sb.append(msg);
        sb.append("\n");

        log.setText(sb.toString());
    }

    @Override
    public void onClick(View v) {

        if (v == b1) {

            /**
             * STEP 2 登录 登录结果在OnLoginFinish(int userID, String sID, String
             * userName)中回调
             */
            BNSDK sdk = BNSDK.getInstance();
            sdk.login(this, this);
        }

        if (v == b2) {

            /**
             * STEP 3-A 提交订单， 这里是简易方式，建议使用下面STEP 3-B的详细参数
             * 此方式订单号，商品名称，扩展字段等，均为由SDK生成或空，金额默认1元 Parameters:
             *  context Context（请传入当前Context）
             *  listener OnBNSDKListener回调
             */
            // 提交订单
            BNSDK sdk = BNSDK.getInstance();
            int code = sdk.order(this,this);

            // log输出操作结果
            log(code);
            log(" ");
        }

        if (v == b3) {

            // 这里用时间戳来作为订单号，实际订单号应由游戏生成
            String orderNo = Long.toString(System.currentTimeMillis());
            orderNo = orderNo.substring(orderNo.length() - 10, orderNo.length())
                    + BNSDK.getInstance().getComefrom();

            /**
             * STEP 3-B 提交订单 Parameters: 
             * context Context （请传入当前Context）
             *  orderNo 订单号 如果需要由SDK生成，可传Null 
             *  name 商品名称，没有可为Null 
             *  amount 订单金额 
             *  dataEx附件数据（将会透传并返回）,可以为null
             *  callbackURL 订单结果的回调URL 
             */
            // 提交订单
            BNSDK sdk = BNSDK.getInstance();
            int code = sdk.order(this, orderNo, "宝石礼包1000", 10, "ExtField123", this);

            // log输出操作结果
            log(code);
            log(" ");
        }

        if (v == b4) {
            // 打印渠道号，log输出
            BNSDK sdk = BNSDK.getInstance();
            log("渠道号：" + sdk.getChannel());
            log("渠道类型(CPS=1 , CPA=2)：  " + sdk.getComefromType());
            log("游戏ID：  " + sdk.getGameId());
            log("游戏SKey：  " + sdk.getSKey());
            log(" ");
        }
    }

    /**
     * --------------------------------------------------------
     * 以下是OnBNSDKListener 接口的方式实现，登录/订单等操作结果均在这里返回
     */

    /**
     * 登录/注册成功
     */
    @Override
    public void OnLoginFinish(int userID, String sID, String userName) {
        // 显示悬浮菜单
        //FloatMenuManager floatMenuManager = FloatMenuManager.getInstance();
        //floatMenuManager.showFloatMenu(DemoActivity.this);

        BNSDK.getInstance().getUserID();
        log("SDK回调： 登录成功");
        log("UserID：" + userID);
        log("SID：" + sID);
        log("UserName：" + userName);
        log(" ");
    }

    /**
     * 登录/注册取消
     */
    @Override
    public void OnLoginCancel() {
        log("SDK回调： 登录取消");
        log(" ");
    }

    /**
     * 订单已经提交到SDK
     */
    @Override
    public void OnOrderApply(String orderNo) {
        log("SDK回调： 订单已提交");
        log("订单号：" + orderNo);
        log(" ");
    }

    /**
     * 订单处理结束，成功/出错均在此callback返回 请根据具体的 返回码 及 支付方式 处理订单（例如发放道具等）
     * 其中的支付方式可见BNSDKOrderResult.Mode类 BNSDKOrderResult.Mode.ALIPAY 支付宝支付
     * BNSDKOrderResult.Mode.UPPAY 银联支付 BNSDKOrderResult.Mode.CARD 充值卡支付
     */
    @Override
    public void OnOrderFinish(int resultCode, BNSDKOrderResult result) {
        log("SDK回调： 订单支付结束");
        log("返回码：" + resultCode + " (100=成功，199=错误)");
        if (result != null) {
            log("订单号：" + result.getOrderNo());
            log("支付方式：" + result.getPayBy());
            log("金额：" + result.getAmount());
            log("信息：" + result.getMsg());

        }
        log(" ");
    }

    /**
     * 订单处理取消，用户没走完支付流程就取消了
     */
    @Override
    public void OnOrderCancel(final String orderNo) {
        log("SDK回调： 订单支付取消");
        log("订单号：" + orderNo);
        log(" ");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            System.exit(0);
        }

        return super.onKeyDown(keyCode, event);
    }

}
