/** Automatically generated file. DO NOT MODIFY */
package com.baina.sdk.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}