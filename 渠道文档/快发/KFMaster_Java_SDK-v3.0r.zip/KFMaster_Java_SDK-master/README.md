# KFMaster_Java_SDK
快发助手AndroidSDK



# SDK版本2.0.1升级至2.0.2说明 #
- bug修复点：修复了在注销失败情况下无法隐藏悬浮窗口的bug
- 升级方法：直接替换KFMaster_Java_2.0.1.jar为KFMaster_Java_2.0.2.jar即可


# SDK版本2.0.2升级至2.0.3说明 #

- 升级点：
1.ui优化
2.悬浮窗口加入用户中心功能
3.用户中心加入切换账号功能

－升级方法：
1.替换KFMaster_Java_2.0.2.jar为KFMaster_Java_2.0.3.jar
2.拷贝res文件夹中的资源到项目工程中

# SDK版本2.0.3升级至2.0.4说明 #

- 升级点：
1.增加游戏强更支持

－升级方法：
1.替换KFMaster_Java_2.0.3.jar为KFMaster_Java_2.0.4.jar


# SDK版本2.0.4升级至3.0.0说明 #
-具体升级方法请参考sdk包中Documents--SDK2.0.4升级到3.0必看.pdf