package com.xcs_sdk.test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;

import com.xcs_sdk.main.Diary;
import com.xcs_sdk.main.LoginListener;
import com.xcs_sdk.main.PayListener;
import com.xcs_sdk.main.ToolUtil;
import com.xcs_sdk.main.XcsSDK;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {

	private EditText ed;
	private ProgressDialog dialoging;
	private String u_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);

		ed = (EditText) findViewById(R.id.appid);

		String appid = ed.getText().toString();
		XcsSDK.getInstance(MainActivity.this).login(appid, new LoginListener() {
			@Override
			public void LoginRequest(Bundle request) {
				ToolUtil.showTip(MainActivity.this, request.getString("code"));
				u_id = request.getString("u_id");
			}
		});

		findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String appid = ed.getText().toString();
				XcsSDK.getInstance(MainActivity.this).login(appid, new LoginListener() {
					@Override
					public void LoginRequest(Bundle request) {
						ToolUtil.showTip(MainActivity.this, request.getString("code"));
						u_id = request.getString("u_id");
					}
				});
			}
		});

		// findViewById(R.id.button3).setOnClickListener(new
		// View.OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// // TODO Auto-generated method stub
		// XcsSDK.getInstance(MainActivity.this).switchAccount("116", new
		// LoginListener() {
		// @Override
		// public void LoginRequest(Bundle request) {
		// ToolUtil.showTip(MainActivity.this, request.getString("code"));
		// }
		// });
		// }
		// });

		findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				// http://test.s.the9.com/Torders/getTestOrder?data={"product_id":"1","price":"1","game_uid":"1","u_id":"1","game_id":"621500022"}

				if (dialoging != null && dialoging.isShowing()) {
					dialoging.cancel();
				}

				dialoging = ProgressDialog.show(MainActivity.this, null, "�������ɶ���", false, false);

				new Thread(new Runnable() {

					@Override
					public void run() {

						try {
							/***
							 * С����dome����ǩ������������鿴������ǩ���ĵ�
							 */
							JSONObject json = new JSONObject();
							json.put("product_id", "1");
							json.put("price", "1");
							json.put("game_uid", "1");
							json.put("u_id", u_id);
							json.put("game_id", ed.getText().toString());
							String data = getSign("http://test.s.the9.com/Torders/getTestOrder?data=" + json.toString());
							JSONObject m_data = new JSONObject(data).getJSONObject("data");
							/**
							 * ����
							 */

							Bundle b = new Bundle();
							// b.putString("user_data", "yuyuyu");// �Զ������
							b.putString("notify_uri", "http://pay.s.the9.com/Callbacks/getNoty");// �ص���ַ
							b.putString("server_name", "С�ϻ�");// ��������
							b.putString("character", "yuyu");// ��ɫ����
							b.putString("game_name", "������");// ��Ϸ����
							b.putString("game_uid", m_data.getString("game_uid"));// �û�id
							b.putString("order_id", m_data.getString("order_id"));// ������
							b.putString("product_id", m_data.getString("product_id"));// ��Ʒid
							b.putString("order_sign", m_data.getString("order_sign"));// ǩ��
							b.putInt("Price", m_data.getInt("price"));// �۸񣨵�λΪԪ��

							XcsSDK.getInstance(MainActivity.this).pay(b, new PayListener() {
								@Override
								public void Request(Bundle request) {
									if (request != null) {
										request.getString("user_data");// �Զ������
										request.getString("notify_uri");// �ص���ַ
										request.getString("server_name");// ��������
										request.getString("character");// ��ɫ����
										request.getString("game_name");// ��Ϸ����
										request.getString("game_uid");// �û�id
										request.getString("order_id");// ������
										request.getString("product_id");// ��ƷID
										request.getString("order_id");// ������
										request.getInt("Price");// �۸񣨵�λΪԪ��
										ToolUtil.showTip(MainActivity.this, request.getString("code"));
									}
								}
							});
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (dialoging != null && dialoging.isShowing()) {
									dialoging.cancel();
								}
							}
						});

					}
				}).start();
			}
		});
	}

	@Override
	protected void onDestroy() {
		XcsSDK.getInstance(MainActivity.this).onDestroy();
		super.onDestroy();
	}

	/**
	 * GET����
	 * 
	 * @param url
	 * @return
	 */
	protected String getSign(String uriPic) {
		URL url = null;
		String result = null;
		HttpURLConnection conn = null;

		try {
			Diary.out("httpGet = " + uriPic);
			url = new URL(uriPic);
			conn = (HttpURLConnection) url.openConnection();
			conn.setDoInput(true);
			conn.setRequestProperty("accept", "*/*");
			conn.setReadTimeout(50000);
			conn.setConnectTimeout(30000);
			conn.connect();
			if (conn.getResponseCode() == 302) {

			} else {

				InputStream is = conn.getInputStream();
				ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
				int i = 0;
				try {
					while ((i = is.read()) != -1) {
						bytestream.write(i);
					}
				} catch (Exception e) {
				}
				byte data_byte[] = bytestream.toByteArray();
				bytestream.close();
				result = new String(data_byte);
				is.close();
				Diary.out("result = " + result);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (conn != null)
				conn.disconnect();
			conn = null;
		}

		return result;
	}
}
