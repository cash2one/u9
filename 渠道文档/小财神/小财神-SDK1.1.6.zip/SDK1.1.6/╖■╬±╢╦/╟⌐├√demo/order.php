<?php
header("Content-type: text/html; charset=utf-8");

###################################################

/**
 *功能：生成订单数字签名
 *版本：1.1。2
 *修改日期：2015-10-08
 */

$order_id		=	'xxxxxxxxxxxx';		//CP自己服务器生成的订单号
 
$product_id		=	'xxxxxxxxxxx';	    //商品ID
 
$price			=	'xxxxxxxxxxxxx';    //商品价格
 
$game_uid		=	'xxxxxxxxxxxxxx';	//游戏自身用户ID
 
$u_id			=	'xxxxxxxxxxxx';		//小财神平台用户ＩＤ
 
 
$game_id		=	'xxxxxxxxxx';		//小财神平台游戏ID
 
/*
 * 这里填写APP的密钥，从管理后台取得
 */
 
$app_secret		="xxxxxxxxxxxxxxxxxxxx";		//这里是小财神平台提供的游戏密钥


###################################################


//获取订单数字签名
$order_sign=getOrderSign($order_id,$product_id,$price,$game_uid,$u_id,$game_id,$app_secret);

//获取订单数字签名的方法
 function getOrderSign($order_id='',$product_id='',$price='0',$game_uid='',$u_id='',$game_id='',$app_secret=''){
    

     //拼接字符串
     $signStr=$order_id."_".$product_id."_".$price."_".$game_uid."_".$u_id."_".$game_id."_".$app_secret;
     
     $order_sign=md5($signStr);
     
     return $order_sign;
 }   

		
		
		
?>