<?php
header("Content-type: text/html; charset=utf-8");

###################################################

/**
 *功能：游戏充值回调文档实例
 *版本：1.1。2
 *修改日期：2015-06-08
 */

###################################################


		$order_id		=	$_REQUEST['order_id'];		//CP自己服务器生成的订单
		
		$product_id		=	$_REQUEST['product_id'];	//商品ID
		
		$price			=	$_REQUEST['price'];			//商品价格
		
		$game_uid		=	$_REQUEST['game_uid'];		//游戏自身用户ID
		
		$u_id			=	$_REQUEST['u_id'];			//小财神平台用户ＩＤ
		
		$xcs_order		=	$_REQUEST['xcs_order'];		//小财神平台订单ID
		
		$game_id		=	$_REQUEST['game_id'];		//小财神平台游戏ID
		
		
		$sign			=	$_REQUEST['sign'];			//校验字符串
		
			

		/*
		 * 这里填写APP的密钥，从管理后台取得
		 */
		$app_secret		="xxxxxxxxxxxxxxxxxxxx";		//这里是小财神平台提供的游戏密钥

		$order_user_id	="xxxxxxxxx";					//根据订单号获取生成该订单的小财神平台用户ID，用以校验是否是当前登录用户充值		


		/*
		 * 校验数据是否合法
		 */
		
		
		//拼接字符串
		$signStr=$order_id."_".$product_id."_".$price."_".$game_uid."_".$u_id."_".$xcs_order."_".$game_id."_".$app_secret;
		
		$CheckSign=md5($signStr);
		
		if($sign==$CheckSign){
			/*
			 * 校验成功
			 */
			if($order_user_id==$u_id){
				/*
				 * 判断充值用户与生成订单的用户是否一致，若一致，则处理用户订单信息，并返回0000；若不一致，则不处理，返回0002
				 */
					
				/*
				 * 这里写处理订单的逻辑
				 */
				
				echo '0000';
			}else{
					 
				echo '0002';


			}

			
			
			
		}else{
			/*
			 * 这里写订单校验失败的逻辑
			 */

			echo '0001';
		}
?>