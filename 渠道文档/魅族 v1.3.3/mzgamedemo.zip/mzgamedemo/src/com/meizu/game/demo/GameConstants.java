package com.meizu.game.demo;

public class GameConstants {

	// TODO 游戏申请的信息，根据自己的进行修改。也可从自己的服务端获取
	public static final String GAME_ID = "1816347";
	public static final String GAME_KEY = "6d1e9f41d57b44d1995efcab6782a311";
}
